INPUT_PLI_CODE_BWP5CJ0 = """ %INCLUDE  ¥BCHGBL;                                                     
                                                                        
 ¥SAVE     MOD(BWP5CJ0)                                                 
           OPTIONS(MAIN);                                               
 %SKIP(5);                                                              
 %INCLUDE  ¥STRCTRB;                                                    
                                                                        
 %PAGE;                                                                 
 /*  ﾌｧｲﾙ ｾﾝｹﾞﾝ  */                                                     
                                                                        
   ¥FILE NAME(DISKR1)                        /* ｼﾞﾄﾞｳﾌﾘｶｴﾏｽﾀｰ ｺｳｼﾝﾏｴ  */
         DD(DISKR1)                                                     
         MACRF(GM)                                                      
         RECFM(FB)                                                      
         MODE(M);                                                       
                                                                        
   ¥FILE NAME(DISKR2)                        /* ｼﾞﾄﾞｳﾌﾘｶｴｷﾎﾝﾃﾞｰﾀ     */ 
         DD(DISKR2)                                                     
         MACRF(GM)                                                      
         RECFM(FB)                                                      
         MODE(M);                                                       
                                                                        
   ¥FILE NAME(DISKW)                         /* ｼﾞﾄﾞｳﾌﾘｶｴﾏｽﾀｰ ｺｳｼﾝｺﾞ  */
         DD(DISKW)                                                      
         MACRF(PM)                                                      
         RECFM(FB)                                                      
         MODE(M);                                                       
                                                                        
   ¥FILE NAME(PRINT)                         /* ｼﾞﾄﾞｳﾌﾘｶｴｷﾎﾝﾃﾞｰﾀ      */
         DD(PRINT)                           /* ﾄｳﾛｸﾘｽﾄ               */
         MACRF(PM)                                                      
         RECFM(FAB)                                                     
         MODE(M);                                                       
                                                                        
   DFT   RANGE(*)  STATIC;                                              
 %PAGE;                                                                 
 /*  ｻﾌﾞﾌﾟﾛｸﾞﾗﾑ  */                                                     
                                                                        
   DCL   BWP5CJ1     ENTRY;                                             
 %PAGE;                                                                 
 /*  CONSTANT  */                                                       
                                                                        
   DCL   C_0         CHAR(1)       INIT('0');                           
   DCL   C_1         CHAR(1)       INIT('1');                           
   DCL   C_2         CHAR(1)       INIT('2');                           
   DCL   C_7         CHAR(1)       INIT('7');                           
   DCL   C_9         CHAR(1)       INIT('9');                           
   DCL   C_E         CHAR(1)       INIT('E');                           
   DCL   C_Y         CHAR(1)       INIT('Y');                           
   DCL   C_BLK       CHAR(1)       INIT(' ');                           
                                                                        
   DCL   KEY_MAX     CHAR(16)      INIT((16)¥HEX('FF'));                
                                                                        
   DCL   C_DABUERR   CHAR(17)      INIT('***ﾏｽﾀ- ﾀﾞﾌﾞﾘｴﾗ- ');           
   DCL   C_SYORIERR  CHAR(17)      INIT('***ｶ-ﾄﾞｼﾖﾘｸﾌﾞﾝｴﾗ-');           
                                                                        
   DCL   P_0         FIXED DEC(1)  INIT(0);                             
   DCL   P_1         FIXED DEC(1)  INIT(1);                             
   DCL   P_22        FIXED DEC(3)  INIT(22);                            
                                                                        
 %PAGE;                                                                 
 /*  TABLE  */                                                          
                                                                        
   DCL 1 TBL_SYORI(3),                                                  
         2 TBL_KUBUN   CHAR(1)      INIT('1','2','9'),                  
         2 TBL_SYURUI  G(2)         INIT(新規Ｇ,                  
                                         変更Ｇ,                  
                                         抹消Ｇ),                 
         2 TBL_COUNTER FIXED DEC(3) INIT((3)0);                         
 %PAGE;                                                                 
 /*  COUNTER  */                                                        
                                                                        
   DCL   CTR_GYOU    FIXED DEC(3)  INIT(0);                             
   DCL   CTR_PAGE    FIXED DEC(3)  INIT(0);                             
   DCL   CTR_ERROR   FIXED DEC(3)  INIT(0);                             
   DCL   CTR_READ    FIXED DEC(5)  INIT(0);                             
   DCL   CTR_WRITE   FIXED DEC(5)  INIT(0);                             
   DCL   CTR_GOUKEI  FIXED DEC(5)  INIT(0);                             
 %PAGE;                                                                 
 /*  MESSAGE AREA  */                                                   
                                                                        
   DCL   MG_EOJ       CHAR(13)      INIT('  BWP5CJ0 EOJ');              
                                                                        
   DCL   MG_ABEND     CHAR(32)                                          
                      INIT('  BWP5CJ0 SYSTEM ABEND,ONCODE = ');         
                                                                        
   DCL 1 MG_UTENERR,                                                    
         2 MG1        CHAR(39)                                          
                      INIT('  BWP5CJ0 ¥UTENSCH ERR RETURN TENBAN = '),  
         2 MG_UTEN    PIC'(3)9',                                        
         2 MG2        CHAR(6)       INIT(',ABEND');                     
   DCL   MG_UTENERR_D CHAR(48)      BASED(ADDR(MG_UTENERR));            
                                                                        
   DCL 1 MG_R_M,                                                        
         2 MG3        CHAR(32)                                          
                      INIT('  BWP5CJ0 READ JIFURI MASTER  = '),         
         2 MG_R_M_KEN PIC'ZZ,ZZ9',                                      
         2 MG4        CHAR(4)       INIT(' KEN');                       
   DCL   MG_R_M_D     CHAR(42)      BASED(ADDR(MG_R_M));                
                                                                        
   DCL 1 MG_R_D,                                                        
         2 MG5        CHAR(32)                                          
                      INIT('  BWP5CJ0 READ KIHON DATA     = '),         
         2 MG_R_D_KEN PIC'ZZ,ZZ9',                                      
         2 MG6        CHAR(4)       INIT(' KEN');                       
   DCL   MG_R_D_D     CHAR(42)      BASED(ADDR(MG_R_D));                
                                                                        
   DCL 1 MG_W_M,                                                        
         2 MG7        CHAR(32)                                          
                      INIT('  BWP5CJ0 WRITE JIFURI MASTER = '),         
         2 MG_W_M_KEN PIC'ZZ,ZZ9',                                      
         2 MG8        CHAR(4)       INIT(' KEN');                       
   DCL   MG_W_M_D     CHAR(42)      BASED(ADDR(MG_W_M));                
 %PAGE;                                                                 
 /*  PARAMETER AREA  */                                                 
                                                                        
   DCL 1 BWP5CJ1_PARM,                                                  
         2 PTR_REC   PTR,                                               
         2 SYORI     CHAR(1),                                           
         2 RNAME     CHAR(30);                                          
 %PAGE;                                                                 
 /*  GETDAYC AREA  */                                                   
   DCL 1 DATE,                                                          
         2 SEIREKI   PIC'(8)9',                                         
         2 CTLSW     CHAR(4),                                           
         2 WAREKI    PIC'(8)9';                                         
 %PAGE;                                                                 
 /*  KEY AREA  */                                                       
                                                                        
   DCL   KEY_MASTER  CHAR(16)      INIT(' ');                           
                                                                        
   DCL 1 KEY_MAS_D   BASED(ADDR(KEY_MASTER)),                           
         2 KEY_M_J   CHAR(7),                                           
         2 KEY_M_N   CHAR(9);                                           
                                                                        
   DCL   KEY_DATA    CHAR(16)      INIT(' ');                           
                                                                        
   DCL 1 KEY_DAT_D   BASED(ADDR(KEY_DATA)),                             
         2 KEY_D_J   CHAR(7),                                           
         2 KEY_D_N   CHAR(9);                                           
 %PAGE;                                                                 
 /*  SAVE AREA  */                                                      
                                                                        
   DCL   SV_ERR_RUI  CHAR(17)      INIT(' ');                           
                                                                        
   DCL   SV_DATE_S   FIXED DEC(9)  INIT(0);                             
 %PAGE;                                                                 
 /*  WORK AREA  */                                                      
                                                                        
   DCL   WK_BCODE    CHAR(15)        INIT(' ');                         
   DCL   WK_SCODE    CHAR(15)        INIT(' ');                         
                                                                        
   DCL   WK_TEN      FIXED DEC(9)    INIT(0);                           
                                                                        
   DCL   I           FIXED BIN(15)   INIT(0);                           
                                                                        
   DCL   BWP5CJ0_RC  FIXED BIN(31,0) INIT(0);                           
 %PAGE;                                                                 
 /*  READ AREA 1  */                                                    
                                                                        
   DCL 1 RD_M,                               /* ｼﾞﾄﾞｳﾌﾘｶｴﾏｽﾀｰ ｺｳｼﾝﾏｴ  */
 %INCLUDE WPZ2C000;                                                     
                                                                        
 %PAGE;                                                                 
 /*  READ AREA 2  */                                                    
                                                                        
   DCL 1 RD_D,                               /* ｼﾞﾄﾞｳﾌﾘｶｴｷﾎﾝﾃﾞｰﾀ      */
 %INCLUDE WPZ3C000;                                                     
                                                                        
   DCL   PIC_AREA     PIC'(3)9'       BASED(ADDR(WPZ3C052));            
   DCL   PIC_WPZ3C010 PIC'(9)9'       BASED(ADDR(WPZ3C010));            
   DCL   PIC_WPZ3C020 PIC'(9)9'       BASED(ADDR(WPZ3C020));            
   DCL   PIC_WPZ3C054 PIC'(7)9'       BASED(ADDR(WPZ3C054));            
   DCL   PIC_WPZ3C060 PIC'(9)9'       BASED(ADDR(WPZ3C060));            
   DCL   PIC_WPZ3C080 PIC'(6)9'       BASED(ADDR(WPZ3C080));            
 %PAGE;                                                                 
 /*  WRITE AREA  */                                                     
                                                                        
   DCL 1 WT,                                 /* ｼﾞﾄﾞｳﾌﾘｶｴﾏｽﾀｰ ｺｳｼﾝｺﾞ  */
 %INCLUDE WPZ2C000;                                                     
                                                                        
 %PAGE;                                                                 
 /*  PRINT AREA  */                                                     
                                                                        
   DCL 1 P_AREA,                                                        
         2 ASA            CHAR(1)  INIT(' '),                           
         2 PA             CHAR(96) INIT(' ');                           
                                                                        
   DCL 1 HD               BASED(ADDR(PA)),                              
         2 PR_SOUFUTEN    PIC'(3)9',                                    
         2 PR_TEN         PIC'(3)9',                                    
         2 PR_TENMEI      G(12),                                        
         2 PR_DATE        PIC'99.99.99',                                
         2 PR_PAGE        PIC'ZZ9';                                     
                                                                        
   DCL 1 MEISAI           BASED(ADDR(PA)),                              
         2 PR_ERROR       CHAR(17),                                     
         2 PR_SYORI       G(2),                                         
         2 PR_JUTAKU      CHAR(8),                                      
         2 PR_KOZINNO     CHAR(11),                                     
         2 PR_SHIMEI      CHAR(20),                                     
         2 PR_SHITEIKOUZA,                                              
           3 PR_BCODE     CHAR(4),                                      
           3 PR_SCODE     CHAR(3),                                      
           3 PR_KAMOKU    CHAR(1),                                      
           3 PR_KOUZANO   CHAR(9),                             16 JST 木        
         2 PR_KINGAKU     PIC'ZZZ,ZZZ,ZZ9',                             
         2 PR_HOUKOKUBI   CHAR(8);                                      
                                                                        
   DCL   ED_JUTAKU        PIC'999/9999'    BASED(ADDR(PR_JUTAKU));      
   DCL   ED_KOZINNO       PIC'999/999/999' BASED(ADDR(PR_KOZINNO));     
   DCL   ED_KOUZANO       PIC'Z/ZZZ/ZZ9'   BASED(ADDR(PR_KOUZANO));     
   DCL   ED_HOUKOKUBI     PIC'99/99/99'    BASED(ADDR(PR_HOUKOKUBI));   
                                                                        
   DCL 1 TOTAL            BASED(ADDR(PA)),                              
         2 PR_READKEN     PIC'ZZ,ZZ9',                                  
         2 PR_WRITEKEN    PIC'ZZ,ZZ9',                                  
         2 PR_KIHON,                                                    
           3 PR_SHINKIKEN PIC'ZZ9',                                     
           3 PR_HENKOUKEN PIC'ZZ9',                                     
           3 PR_MASYOUKEN PIC'ZZ9',                                     
           3 PR_ERRORKEN  PIC'ZZ9',                                     
           3 PR_GOUKEI    PIC'ZZ,ZZ9';                                  
 %PAGE;                                                                 
     /* PROCEDURE                                            *       */ 
                                                                        
   ON ERROR                                                             
     BEGIN;                                                             
     DISPLAY(MG_ABEND || ONCODE);                                       
     CALL PLIDUMP('HB');                                                
     STOP;                                                              
     END;                                                               
 %PAGE;                                                                 
 /**************/                                                       
 /*  INIT RTN  */                                                       
 /**************/                                                       
                                                                        
   ¥GETDAYC PGM(BWP5CJ0)                     /* ｵﾝﾄｳｼﾞﾂ               */
            DAYADDR(DATE)                                               
            DAYID(01)                                                   
            CD(NO)                                                      
            CANCEL(YES);                                                
                                                                        
   SV_DATE_S = SEIREKI;                                                 
                                                                        
   ¥OPEN FILE(DISKR1)                                                   
         TYPE(INPUT);                                                   
                                                                        
   ¥OPEN FILE(DISKR2)                                                   
         TYPE(INPUT);                                                   
                                                                        
   ¥OPEN FILE(DISKW)                                                    
         TYPE(OUTPUT);                                                  
                                                                        
   ¥OPEN FILE(PRINT)                                                    
         TYPE(OUTPUT);                                                  
                                                                        
   PTR_REC = ADDR(RD_D);                                                
   SYORI = C_0;                                                         
   CALL BWP5CJ1(BWP5CJ1_PARM);               /* ｼｮｶｲ ｺｰﾙ              */
                                                                        
   CALL BWP5CJ0_HDPRT;                       /* ﾐﾀﾞｼ PRINT            */
   CALL BWP5CJ0_MGET;                        /* OLDﾏｽﾀｰ GET           */
   CALL BWP5CJ0_DGET;                        /* ｷﾎﾝﾃﾞｰﾀ GET           */
 %PAGE;                                                                 
 /**************/                                                       
 /*  MAIN RTN  */                                                       
 /**************/                                                       
                                                                        
   DO WHILE (KEY_MASTER ^= KEY_MAX |         /* OLDﾏｽﾀｰ ｱﾙｱｲﾀﾞ        */
             KEY_DATA ^= KEY_MAX);           /* ｷﾎﾝﾃﾞｰﾀ ｱﾙｱｲﾀﾞ        */
                                                                        
     IF KEY_MASTER = KEY_DATA                /* ﾏｯﾁﾝｸﾞｷｰ ｲｯﾁｼﾃｲﾙ      */
     THEN                                                               
       DO;                                                              
         SELECT(WPZ3C070);                                              
           WHEN(C_1)                         /* ｼｮﾘｸﾌﾞﾝ ｼﾝｷ           */
             DO;                                                        
             WT = RD_M;                                                 
             CALL BWP5CJ0_MPUT;              /* NEWﾏｽﾀｰ ｼｭﾂﾘｮｸ        */
             SV_ERR_RUI = C_DABUERR;                                    
                                                                        
             ¥PDUMP TOPADDR(RD_M)                                       
                    LNG(150)                                            
                    HEAD('*** OLD MASTER ***')                          
                    TYPE(DUMPT);                                        
                                                                        
             END;                                                       
           WHEN(C_2)                         /* ｼｮﾘｸﾌﾞﾝ ﾍﾝｺｳ          */
             DO;                                                        
             CALL BWP5CJ0_WRITE;             /* NEWﾏｽﾀｰ ｶｷﾀﾞｼ         */
             CALL BWP5CJ0_MPUT;              /* NEWﾏｽﾀｰ ｼｭﾂﾘｮｸ        */
             END;                                                       
           WHEN(C_9) ;                       /* ｼｮﾘｸﾌﾞﾝ ﾏｯｼｮｳ         */
           OTHER ;                                                      
         END;                                                           
                                                                        
       CALL BWP5CJ0_DTPRT;                   /* ﾒｲｻｲ PRINT            */
       CALL BWP5CJ0_MGET;                    /* OLDﾏｽﾀｰ GET           */
       CALL BWP5CJ0_DGET;                    /* ｷﾎﾝﾃﾞｰﾀ GET           */
       END;                                                             
     ELSE                                                               
       DO;                                                              
       IF KEY_MASTER > KEY_DATA              /* ｷﾎﾝﾃﾞｰﾀ ﾉﾐ            */
       THEN                                                             
         DO;                                                            
         IF WPZ3C070 = C_1                   /* ｼｮﾘｸﾌﾞﾝ ｼﾝｷ           */
         THEN                                                           
           DO;                                                          
           CALL BWP5CJ0_WRITE;               /* NEWﾏｽﾀｰ ｶｷﾀﾞｼ         */
           CALL BWP5CJ0_MPUT;                /* NEWﾏｽﾀｰ ｼｭﾂﾘｮｸ        */
           END;                                                         
         ELSE                                /* ｼｮﾘｸﾌﾞﾝ ﾍﾝｺｳ OR ﾏｯｼｮｳ */
           DO;                                                          
           SV_ERR_RUI = C_SYORIERR;                                     
           END;                                                         
                                                                        
         CALL BWP5CJ0_DTPRT;                 /* ﾐﾀﾞｼ PRINT            */
         CALL BWP5CJ0_DGET;                  /* ｷﾎﾝﾃﾞｰﾀ GET           */
         END;                                                           
       ELSE                                  /* OLDﾏｽﾀｰ ﾉﾐ            */
         DO;                                                            
         WT = RD_M;                                                     
         CALL BWP5CJ0_MPUT;                  /* NEWﾏｽﾀｰ ｼｭﾂﾘｮｸ        */
         CALL BWP5CJ0_MGET;                  /* OLDﾏｽﾀｰ GET           */
         END;                                                           
       END;                                                             
   END;                                                                 
 %PAGE;                                                                 
 /*************/                                                        
 /*  END RTN  */                                                        
 /*************/                                                        
                                                                        
   CALL BWP5CJ0_TOTAL;                       /* ｺﾞｳｹｲ PRINT           */
                                                                        
   SYORI = C_9;                                                         
   CALL BWP5CJ1(BWP5CJ1_PARM);               /* ｼｭｳﾘｮｳ ｺｰﾙ            */
                                                                        
   ¥CLOSE FILE(DISKR1);                                                 
                                                                        
   ¥CLOSE FILE(DISKR2);                                                 
                                                                        
   ¥CLOSE FILE(DISKW);                                                  
                                                                        
   ¥CLOSE FILE(PRINT);                                                  
                                                                        
   MG_R_M_KEN = CTR_READ;                                               
   DISPLAY(MG_R_M_D);                                                   
                                                                        
   MG_R_D_KEN = CTR_GOUKEI;                                             
   DISPLAY(MG_R_D_D);                                                   
                                                                        
   MG_W_M_KEN = CTR_WRITE;                                              
   DISPLAY(MG_W_M_D);                                                   
                                                                        
   DISPLAY(MG_EOJ);                                                     
 %PAGE;                                                                 
 /******************/                                                   
 /*  OLDﾏｽﾀｰ READ  */                                                   
 /******************/                                                   
 BWP5CJ0_MGET: PROC;                                                    
                                                                        
   ¥GET FILE(DISKR1)                                                    
        INTO(RD_M);                                                     
                                                                        
   IF AAY30515 = C_E                                                    
   THEN                                                                 
     DO;                                                                
     KEY_MASTER = KEY_MAX;                                              
     END;                                                               
   ELSE                                                                 
     DO;                                                                
     KEY_M_J = STRING(RD_M.WPZ2C010);                                   
     KEY_M_N = SUBSTR(RD_M.WPZ2C020,1,9);                               
     CTR_READ = CTR_READ + P_1;                                         
     END;                                                               
                                                                        
 END BWP5CJ0_MGET;                                                      
 %PAGE;                                                                 
 /******************/                                                   
 /*  ｷﾎﾝﾃﾞｰﾀ READ  */                                                   
 /******************/                                                   
 BWP5CJ0_DGET: PROC;                                                    
                                                                        
   ¥GET FILE(DISKR2)                                                    
        INTO(RD_D);                                                     
                                                                        
   IF AAY30515 = C_E                                                    
   THEN                                                                 
     DO;                                                                
     KEY_DATA = KEY_MAX;                                                
     END;                                                               
   ELSE                                                                 
     DO;                                                                
     KEY_D_J = SUBSTR(WPZ3C010,3);                                      
     KEY_D_N = WPZ3C020;                                                
     CTR_GOUKEI = CTR_GOUKEI + P_1;                                     
     END;                                                               
                                                                        
 END BWP5CJ0_DGET;                                                      
 %PAGE;                                                                 
 /****************/                                                     
 /*  ｼﾝﾏｽﾀｰｺｳｼﾝ  */                                                     
 /****************/                                                     
 BWP5CJ0_WRITE: PROC;                                                   
                                                                        
   WT = '';                                                             
                                                                        
   IF WPZ3C070 = C_1                         /* ｼｮﾘｸﾌﾞﾝ ｼﾝｷ           */
   THEN                                                                 
     DO;                                                                
     STRING(WT.WPZ2C010) = SUBSTR(WPZ3C010,3);                          
     WT.WPZ2C020 = WPZ3C020;                                            
     WT.WPZ2C101 = C_1;                                                 
     WT.WPZ2C120 = WPZ3C080;                                            
     END;                                                               
   ELSE                                      /* ｼｮﾘｸﾌﾞﾝ ﾍﾝｺｳ          */
     DO;                                                                
     WT = RD_M;                                                         
     WT.WPZ2C101 = C_2;                                                 
     END;                                                               
                                                                        
   IF STRING(WPZ3C050) ^= C_BLK                                         
   THEN                                                                 
     DO;                                                                
     IF WPZ3C051 = COB_CBANKCD               /* ｷﾞﾝｺｳｺｰﾄﾞ ﾄｳｺｳ        */
     THEN                                                               
       DO;                                                              
                                                                        
       WT.WPZ2C040 = COB_BANKKN3;                                       
       WK_TEN = PIC_AREA;                                               
                                                                        
       ¥UTENSCH BRNO(WK_TEN)                                            
                DATE(SV_DATE_S);                                        
                                                                        
       IF AAY11002 ^= C_Y                                               
       THEN                                                             
         DO;                                                            
         MG_UTEN = WK_TEN;                                              
         DISPLAY(MG_UTENERR_D);                                         
         SIGNAL ERROR;                                                  
         END;                                                           
                                                                        
       WT.WPZ2C060 = AAY11014;                                          
       END;                                                             
     ELSE                                    /* ｷﾞﾝｺｳｺｰﾄﾞ ﾀｺｳ         */
       DO;                                                              
       WK_BCODE = WPZ3C051;                                             
       WK_SCODE = WPZ3C052;                                             
                                                                        
       ¥BANK TYPE(1)                                                    
             BANK(WK_BCODE)                                             
             BRNCH(WK_SCODE)                                            
             DATE(SV_DATE_S);                                           
                                                                        
       IF AAY22202 = C_Y                                                
       THEN                                                             
         DO;                                                            
         WT.WPZ2C040 = AAY22214;                                        
         WT.WPZ2C060 = AAY22216;                                        
         END;                                                           
       ELSE                                                             
         DO;                                                            
         WT.WPZ2C040 = C_BLK;                                           
         WT.WPZ2C060 = C_BLK;                                           
         END;                                                           
       END;                                                             
                                                                        
     WT.WPZ2C030 = WPZ3C051;                                            
     WT.WPZ2C050 = WPZ3C052;                                            
     WT.WPZ2C071 = WPZ3C053;                                            
     WT.WPZ2C072 = WPZ3C054;                                            
     END;                                                               
                                                                        
   IF WPZ3C040 ^= C_BLK                                                 
   THEN                                                                 
     DO;                                                                
     SYORI = C_1;                                                       
     CALL BWP5CJ1(BWP5CJ1_PARM);             /* ｼｮﾘ ｺｰﾙ               */
     WT.WPZ2C080 = RNAME;                                               
     END;                                                               
                                                                        
   IF WPZ3C060 ^= C_BLK                                                 
   THEN                                                                 
     DO;                                                                
     WT.WPZ2C090 = PIC_WPZ3C060;                                        
     END;                                                               
                                                                        
 END BWP5CJ0_WRITE;                                                     
 %PAGE;                                                                 
 /****************/                                                     
 /*  ﾐﾀﾞｼ PRINT  */                                                     
 /****************/                                                     
 BWP5CJ0_HDPRT: PROC;                                                   
                                                                        
   PR_SOUFUTEN = COB_TENJIMUC;                                          
   PR_TEN = COB_TENJIMUC;                                               
                                                                        
   ¥UTENSCH BRNO(COB_TENJIMUC)                                          
            DATE(SV_DATE_S);                                            
                                                                        
   IF AAY11002 ^= C_Y                                                   
   THEN                                                                 
     DO;                                                                
     MG_UTEN = COB_TENJIMUC;                                            
     DISPLAY(MG_UTENERR_D);                                             
     SIGNAL ERROR;                                                      
     END;                                                               
                                                                        
   PR_TENMEI = AAY11016;                                                
   PR_DATE = WAREKI;                                                    
                                                                        
   CTR_PAGE = CTR_PAGE + P_1;                                           
   PR_PAGE = CTR_PAGE;                                                  
                                                                        
   ASA = C_1;                                                           
   CALL BWP5CJ0_LPUT;                        /* ﾘｽﾄ ｼｭﾂﾘｮｸ            */
                                                                        
   CTR_GYOU = P_0;                                                      
                                                                        
 END BWP5CJ0_HDPRT;                                                     
 %PAGE;                                                                 
 /****************/                                                     
 /*  ﾒｲｻｲ PRINT  */                                                     
 /****************/                                                     
 BWP5CJ0_DTPRT: PROC;                                                   
                                                                        
   IF CTR_GYOU = P_22                                                   
   THEN                                                                 
     DO;                                                                
     CALL BWP5CJ0_HDPRT;                     /* ﾐﾀﾞｼ PRINT            */
     END;                                                               
                                                                        
   ED_JUTAKU = PIC_WPZ3C010;                                            
   PR_JUTAKU = TRANSLATE(PR_JUTAKU,'-','/');                            
                                                                        
   ED_KOZINNO = PIC_WPZ3C020;                                           
   PR_KOZINNO = TRANSLATE(PR_KOZINNO,'-','/');                          
                                                                        
   IF SV_ERR_RUI = C_BLK                     /* ﾏｯﾁﾝｸﾞｹｯｶ ｴﾗｰ ﾃﾞﾊﾅｲ   */
   THEN                                                                 
     DO;                                                                
       DO I = 1 TO 3                                                    
         UNTIL  (WPZ3C070 = TBL_KUBUN(I));                              
       END;                                                             
                                                                        
     PR_SYORI = TBL_SYURUI(I);                                          
     TBL_COUNTER(I) = TBL_COUNTER(I) + P_1;                             
                                                                        
     IF WPZ3C040 ^= C_BLK                                               
     THEN                                                               
       DO;                                                              
       PR_SHIMEI = WPZ3C040;                                            
       END;                                                             
                                                                        
     IF STRING(WPZ3C050) ^= C_BLK                                       
     THEN                                                               
       DO;                                                              
       PR_BCODE = WPZ3C051;                                             
       PR_SCODE = WPZ3C052;                                             
       PR_KAMOKU = WPZ3C053;                                            
       ED_KOUZANO = PIC_WPZ3C054;                                       
       PR_KOUZANO = TRANSLATE(PR_KOUZANO,'-','/');                      
       END;                                                             
                                                                        
     IF WPZ3C060 ^= C_BLK                                               
     THEN                                                               
       DO;                                                              
       PR_KINGAKU = PIC_WPZ3C060;                                       
       END;                                                             
                                                                        
     ED_HOUKOKUBI = PIC_WPZ3C080;                                       
     PR_HOUKOKUBI = TRANSLATE(PR_HOUKOKUBI,'-','/');                    
     END;                                                               
                                                                        
   ELSE                                      /* ﾏｯﾁﾝｸﾞｹｯｶ ｴﾗｰ         */
     DO;                                                                
     PR_ERROR = SV_ERR_RUI;                                             
     CTR_ERROR = CTR_ERROR + P_1;                                       
     SV_ERR_RUI = C_BLK;                                                
     END;                                                               
                                                                        
   IF CTR_GYOU = P_0                                                    
   THEN                                                                 
     DO;                                                                
     ASA = C_2;                                                         
     END;                                                               
   ELSE                                                                 
     DO;                                                                
     ASA = C_0;                                                         
     END;                                                               
                                                                        
   CALL BWP5CJ0_LPUT;                        /*ﾘｽﾄ ｼｭﾂﾘｮｸ             */
                                                                        
   CTR_GYOU = CTR_GYOU + P_1;                                           
                                                                        
 END BWP5CJ0_DTPRT;                                                     
 %PAGE;                                                                 
 /*****************/                                                    
 /*  ｺﾞｳｹｲ PRINT  */                                                    
 /*****************/                                                    
 BWP5CJ0_TOTAL: PROC;                                                   
                                                                        
   PR_READKEN = CTR_READ;                    /* OLDﾏｽﾀｰ ﾖﾐｺﾐ ｹﾝｽｳ     */
   PR_WRITEKEN = CTR_WRITE;                  /* NEWﾏｽﾀｰ ｻｸｾｲ ｹﾝｽｳ     */
                                                                        
   PR_SHINKIKEN = TBL_COUNTER(1);            /* ﾏｯﾁﾝｸﾞｹｯｶ ｼﾝｷ ｹﾝｽｳ    */
   PR_HENKOUKEN = TBL_COUNTER(2);            /* ﾏｯﾁﾝｸﾞｹｯｶ ﾍﾝｺｳ ｹﾝｽｳ   */
   PR_MASYOUKEN = TBL_COUNTER(3);            /* ﾏｯﾁﾝｸﾞｹｯｶ ﾏｯｼｮｳ ｹﾝｽｳ  */
                                                                        
   PR_ERRORKEN = CTR_ERROR;                  /* ﾏｯﾁﾝｸﾞｹｯｶ ｴﾗｰ ｹﾝｽｳ    */
                                                                        
   PR_GOUKEI = CTR_GOUKEI;                   /* ｷﾎﾝﾃﾞｰﾀ ﾖﾐｺﾐ ｹﾝｽｳ     */
                                                                        
   ASA = C_7;                                                           
   CALL BWP5CJ0_LPUT;                        /* ﾘｽﾄ ｼｭﾂﾘｮｸ            */
                                                                        
 END BWP5CJ0_TOTAL;                                                     
 %PAGE;                                                                 
 /***********/                                                          
 /*  PRINT  */                                                          
 /***********/                                                          
 BWP5CJ0_LPUT: PROC;                                                    
                                                                        
   ¥PUT FILE(PRINT)                                                     
        FROM(P_AREA);                                                   
                                                                        
   PA = C_BLK;                                                          
                                                                        
 END BWP5CJ0_LPUT;                                                      
 %PAGE;                                                                 
 /****************/                                                     
 /*  ｼﾝﾏｽﾀｰ PUT  */                                                     
 /****************/                                                     
 BWP5CJ0_MPUT: PROC;                                                    
                                                                        
   ¥PUT FILE(DISKW)                                                     
        FROM(WT);                                                       
                                                                        
   CTR_WRITE = CTR_WRITE + P_1;                                         
                                                                        
 END BWP5CJ0_MPUT;                                                      
 %PAGE;                                                                 
   BWP5CJ0_RC = 0;                                                      
   CALL PLIRETC(BWP5CJ0_RC);                                            
 ¥RETURN;
 """


INPUT_PLI_CODE_BWP5CJ1 = """ %PAGE;                                                                 
 %INCLUDE  ¥BCHGBL;                                                     
                                                                        
 %SKIP(5);                                                              
 ¥SAVE     MOD(BWP5CJ1)                                                 
           PARM(BWP5CJ1_PARM);                                          
 %SKIP(5);                                                              
 %INCLUDE  ¥STRCTRB;                                                    
                                                                        
 %PAGE;                                                                 
                                                                        
   DFT   RANGE(*)  STATIC;                                              
 %PAGE;                                                                 
 /*  CONSTANT  */                                                       
                                                                        
   DCL   C_0         CHAR(1)       INIT('0');                           
   DCL   C_1         CHAR(1)       INIT('1');                           
   DCL   C_9         CHAR(1)       INIT('9');                           
 %PAGE;                                                                 
 /*  TABLE  */                                                          
                                                                        
   DCL   TBL_SUU     FIXED BIN(15) INIT(6);                             
                                                                        
   DCL 1 TBL_HENKAN(6),                                                 
         2 TBL_KIGO  CHAR(6)       INIT('ｶﾌﾞｼｷ.','ｶﾌﾞ.  ',              
                                        'ﾎｳｼﾞﾝ.','ﾎｳ.   ',              
                                        'ﾕｳｹﾞﾝ.','ﾕｳ.   '),             
         2 TBL_LEN   FIXED BIN(15) INIT(6,4,6,3,6,3),                   
         2 TBL_RYAKU CHAR(2)       INIT('ｶ.','ｶ.',                      
                                        'ﾎ.','ﾎ.',                      
                                        'ﾕ.','ﾕ.');                     
 %PAGE;                                                                 
 /*  MESSAGE AREA  */                                                   
                                                                        
   DCL   MG_START    CHAR(15)      INIT('  BWP5CJ1 START');             
                                                                        
   DCL   MG_END      CHAR(13)      INIT('  BWP5CJ1 END');               
                                                                        
   DCL   MG_ABEND    CHAR(32)                                           
                     INIT('  BWP5CJ1 SYSTEM ABEND,ONCODE = ');          
 %PAGE;                                                                 
 /*  PARAMETER AREA  */                                                 
                                                                        
   DCL 1 BWP5CJ1_PARM,                                                  
         2 PTR_REC   PTR,                                               
         2 SYORI     CHAR(1),                                           
         2 RNAME     CHAR(30);                                          
                                                                        
   DCL 1 DM_DT       BASED(PTR_REC),                                    
 %INCLUDE WPZ3C000;                                                     
                                                                        
 %PAGE;                                                                 
 /*  WORK AREA  */                                                      
                                                                        
   DCL   I           FIXED BIN(15)   INIT(0);                           
                                                                        
   DCL   J           FIXED BIN(15)   INIT(0);                           
                                                                        
   DCL   BWP5CJ1_RC  FIXED BIN(31,0) INIT(0);                           
 %PAGE;                                                                 
     /* PROCEDURE                                           *       */  
                                                                        
   ON ERROR                                                             
     BEGIN;                                                             
     DISPLAY(MG_ABEND || ONCODE);                                       
     CALL PLIDUMP('HB');                                                
     STOP;                                                              
     END;                                                               
 %PAGE;                                                                 
 /**************/                                                       
 /*  INIT RTN  */                                                       
 /**************/                                                       
                                                                        
   IF SYORI = C_0                            /* INIT ｼｮﾘ              */
   THEN                                                                 
     DO;                                                                
     DISPLAY(MG_START);                                                 
     END;                                                               
 %PAGE;                                                                 
 /**************/                                                       
 /*  MAIN RTN  */                                                       
 /**************/                                                       
                                                                        
   IF SYORI = C_1                            /* MAIN ｼｮﾘ              */
   THEN                                                                 
     DO;                                                                
     DO I = 1 TO TBL_SUU                                                
       UNTIL  (SUBSTR(WPZ3C040,1,TBL_LEN(I)) = TBL_KIGO(I));            
     END;                                                               
                                                                        
     IF I <= TBL_SUU                                                    
     THEN                                                               
       DO;                                                              
       RNAME = TBL_RYAKU(I);                                            
       J = TBL_LEN(I) + 1;                                              
       SUBSTR(RNAME,3) = SUBSTR(WPZ3C040,J);                            
       END;                                                             
     ELSE                                                               
       DO;                                                              
       RNAME = WPZ3C040;                                                
       END;                                                             
     END;                                                               
 %PAGE;                                                                 
 /*************/                                                        
 /*  END RTN  */                                                        
 /*************/                                                        
                                                                        
   IF SYORI = C_9                            /* END ｼｮﾘ               */
   THEN                                                                 
     DO;                                                                
     DISPLAY(MG_END);                                                   
     END;                                                               
                                                                        
 %PAGE;                                                                 
   BWP5CJ1_RC = 0;                                                      
   CALL PLIRETC(BWP5CJ1_RC);                                            
 ¥RETURN;
 """