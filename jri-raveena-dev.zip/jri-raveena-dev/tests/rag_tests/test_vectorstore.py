"""Test vector store functionality."""
import pytest
from unittest.mock import Mock, patch
from src.knowledge_base.vectorstore import MilvusVectorStore


class TestMilvusVectorStore:
    """Test cases for MilvusVectorStore."""
    
    @pytest.fixture
    def mock_connections(self):
        """Mock Milvus connections."""
        with patch('src.knowledge_base.vectorstore.connections') as mock:
            yield mock
    
    @pytest.fixture
    def mock_collection(self):
        """Mock Milvus Collection."""
        with patch('src.knowledge_base.vectorstore.Collection') as mock:
            yield mock
    
    @pytest.fixture
    def vector_store(self, mock_connections, mock_collection):
        """Create vector store instance for testing."""
        with patch('src.knowledge_base.vectorstore.utility'):
            return MilvusVectorStore(
                host="test_host",
                port=19530,
                collection_name="test_collection",
                dimension=384
            )
    
    def test_insert_slides(self, vector_store):
        """Test slide insertion."""
        slide_names = ["slide_1.png", "slide_2.png"]
        descriptions = ["Description 1", "Description 2"]
        file_name = "test.pptx"
        embeddings = [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]
        
        # Mock the collection methods
        vector_store.collection.insert = Mock()
        vector_store.collection.flush = Mock()
        
        result = vector_store.insert_slides(slide_names, descriptions, file_name, embeddings)
        
        assert result == 2
        vector_store.collection.insert.assert_called_once()
        vector_store.collection.flush.assert_called_once()
    
    def test_search(self, vector_store):
        """Test search functionality."""
        query_embedding = [0.1, 0.2, 0.3]
        
        # Mock search results
        mock_hit = Mock()
        mock_hit.id = "test_id"
        mock_hit.distance = 0.95
        mock_hit.entity = {
            "slide_name": "slide_1.png",
            "description": "Test description",
            "file_name": "test.pptx",
            "slide_number": 1
        }
        
        mock_hits = [mock_hit]
        mock_results = [mock_hits]
        
        vector_store.collection.load = Mock()
        vector_store.collection.search = Mock(return_value=mock_results)
        
        results = vector_store.search(query_embedding, top_k=1)
        
        assert len(results) == 1
        assert results[0]['slide_name'] == "slide_1.png"
        assert results[0]['score'] == 0.95