
"""Test embedding functionality."""
import pytest
import numpy as np
from src.embeddings.embedder import EmbeddingGenerator


class TestEmbeddingGenerator:
    """Test cases for EmbeddingGenerator."""
    
    @pytest.fixture
    def embedder(self):
        """Create embedder instance for testing."""
        return EmbeddingGenerator("sentence-transformers/all-MiniLM-L6-v2")  # Smaller model for testing
    
    def test_single_encoding(self, embedder):
        """Test single text encoding."""
        text = "This is a test sentence."
        embedding = embedder.encode_single(text)
        
        assert isinstance(embedding, list)
        assert len(embedding) == embedder.get_dimension()
        assert all(isinstance(x, float) for x in embedding)
    
    def test_batch_encoding(self, embedder):
        """Test batch text encoding."""
        texts = ["First sentence.", "Second sentence.", "Third sentence."]
        embeddings = embedder.encode_batch(texts)
        
        assert len(embeddings) == len(texts)
        assert all(len(emb) == embedder.get_dimension() for emb in embeddings)
    
    def test_dimension_consistency(self, embedder):
        """Test that embedding dimensions are consistent."""
        text1 = "Short text."
        text2 = "This is a much longer text with more words and content."
        
        emb1 = embedder.encode_single(text1)
        emb2 = embedder.encode_single(text2)
        
        assert len(emb1) == len(emb2) == embedder.get_dimension()
