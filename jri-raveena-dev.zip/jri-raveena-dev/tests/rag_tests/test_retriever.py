"""Test retrieval functionality."""
import pytest
from unittest.mock import Mock
from src.retrieval.retriever import SlideRetriever


class TestSlideRetriever:
    """Test cases for SlideRetriever."""
    
    @pytest.fixture
    def mock_vector_store(self):
        """Create mock vector store."""
        mock_store = Mock()
        mock_store.search.return_value = [
            {
                'id': 'test_id',
                'slide_name': 'slide_1.png',
                'description': 'Test description',
                'slide_number': 1,
                'score': 0.95
            }
        ]
        return mock_store
    
    @pytest.fixture
    def mock_embedder(self):
        """Create mock embedder."""
        mock_embedder = Mock()
        mock_embedder.encode_single.return_value = [0.1, 0.2, 0.3]
        return mock_embedder
    
    @pytest.fixture
    def retriever(self, mock_vector_store, mock_embedder):
        """Create retriever instance for testing."""
        return SlideRetriever(mock_vector_store, mock_embedder)
    
    def test_retrieve_relevant_slides(self, retriever, mock_embedder, mock_vector_store):
        """Test slide retrieval."""
        query = "What are the main points?"
        
        results = retriever.retrieve_relevant_slides(query, top_k=1)
        
        mock_embedder.encode_single.assert_called_once_with(query, normalize=True)
        mock_vector_store.search.assert_called_once_with([0.1, 0.2, 0.3], top_k=1)
        
        assert len(results) == 1
        assert results[0]['slide_name'] == 'slide_1.png'