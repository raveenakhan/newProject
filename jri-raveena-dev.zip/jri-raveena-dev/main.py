import time
import os
import re
import threading
from pathlib import Path
import json
from typing import Any, Dict, List, Tuple, Optional
import gradio as gr
import logging
from config.settings import get_settings
from src.utils.logger import setup_logger
from src.utils.file_handler import FileHandler
from src.utils.image_cache import ImageCacheManager
from src.embeddings.embedder import EmbeddingGenerator
from src.knowledge_base.vector_store import MilvusVectorStore
# from src.knowledge_base.updated_processor import SlideProcessor
from src.knowledge_base.updated_slides_processor import SlideProcessor
from src.knowledge_base.tokenizer import HybridJapaneseEnglishTokenizer
from src.retrieval.retriever import SlideRetriever
from src.knowledge_base.tavily_search import AgenticRAG

from ibm_watsonx_ai import Credentials
from ibm_watsonx_ai.foundation_models import ModelInference

# Setup logging
os.environ["TOKENIZERS_PARALLELISM"] = "false"
settings = get_settings()
log_file = Path(settings.logs_dir) / "app.log"
logger = setup_logger(__name__, settings.log_level, log_file)

# Suppress verbose third-party logs
for lib in ["urllib3", "httpx", "httpcore", "sentence_transformers", "transformers", "torch"]:
    logging.getLogger(lib).setLevel(logging.WARNING)


class PowerPointQASystem:
    """Enhanced PowerPoint & PDF Q&A system with predefined collections for different client groups."""
    
    # Predefined collections for the 3 client groups
    PREDEFINED_COLLECTIONS = {
        "BPR_CONSULTING": {
            "display_name": "BPR Consulting",
            "description": "Business Process Reengineering consulting materials"
        },
        "ENERGY_SECTOR": {
            "display_name": "Energy Sector Consulting", 
            "description": "Energy sector consulting presentations and documents"
        },
        "GENERAL_SECTOR": {
            "display_name": "General Sector",
            "description": "General sector consulting materials"
        }
    }
    
    def __init__(self):
        self.settings = get_settings()
        
        # Initialize components
        self.file_handler = FileHandler()
        self.embedder = EmbeddingGenerator(self.settings.embedding_model_name)
        self.vector_store = MilvusVectorStore()
        self.processor = SlideProcessor(
            self.settings.watsonx_api_key,
            self.settings.watsonx_project_id,
            self.settings.watsonx_url
        )
        self.retriever = SlideRetriever(self.vector_store, self.embedder)

        self.tokenizer = HybridJapaneseEnglishTokenizer()

        # State
        self.base64_images: Dict[str, str] = {}
        self.slide_names: List[str] = []
        self.slide_descriptions: Dict[str, str] = {}
        self.conversation_context: List[str] = [""]
        self.last_reset_time = time.time()
        self.current_file_name: Optional[str] = None

        # Initialize watsonx.ai models
        self.model_id = "mistralai/mistral-medium-2505"

        self.credentials = Credentials(
                url=self.settings.watsonx_url,
                api_key=self.settings.watsonx_api_key,
            )
        
        self.ref_ques_gen_parameters = {
            "decoding_method": "greedy",
            "max_new_tokens": 150,
            "temperature": 0.0
            }

        self.ref_ques_gen_model = ModelInference(
            model_id=self.model_id,
            params=self.ref_ques_gen_parameters,
            credentials=self.credentials,
            project_id=self.settings.watsonx_project_id
        )

        self.expand_query_gen_parameters = {
            "decoding_method": "greedy",
            "max_new_tokens": 800,
            "temperature": 0.0,
            "repetition_penalty": 1.0
        }

        self.expand_query_gen_model = ModelInference(
            model_id=self.model_id,
            params=self.expand_query_gen_parameters,
            credentials=self.credentials,
            project_id=self.settings.watsonx_project_id
        )

        # Initialize image cache manager
        self.image_cache = ImageCacheManager(
            cache_dir=str(Path(self.settings.data_dir) / "image_cache")
        )
        
        # In-memory cache for currently active presentations (optional)
        self.active_images_cache: Dict[str, Dict[str, str]] = {}
        
        logger.info("PowerPoint Q&A System with image caching initialized")
        
        try:
            self.agentic_rag = AgenticRAG(
                watsonx_api_key=self.settings.watsonx_api_key,
                watsonx_project_id=self.settings.watsonx_project_id,
                tavily_api_key=self.settings.tavily_api_key,
                watsonx_url=self.settings.watsonx_url,
                max_search_results=5
            )
            logger.info("AgenticRAG for external search initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize AgenticRAG: {e}")
            logger.warning("External search functionality will not be available")
            self.agentic_rag = None
        
        # Setup auto-reset
        self._setup_auto_reset()
        
        logger.info("PowerPoint & PDF Q&A System with predefined collections initialized successfully")
    
    def _setup_auto_reset(self) -> None:
        """Setup automatic reset thread."""
        def reset_worker():
            while True:
                current_time = time.time()
                if current_time - self.last_reset_time >= self.settings.reset_interval:
                    self._reset_backend()
                time.sleep(60)
        
        reset_thread = threading.Thread(target=reset_worker, daemon=True)
        reset_thread.start()
        logger.info("Auto-reset thread started")
    
    def _reset_backend(self) -> None:
        """Reset backend state."""
        try:
            self.conversation_context = [""]
            self.slide_descriptions = {}
            self.base64_images = {}
            self.slide_names = []
            self.current_file_name = None
            # Note: Don't clear collections as they are predefined
            self.last_reset_time = time.time()
            logger.info("Backend reset completed")
        except Exception as e:
            logger.error(f"Error during backend reset: {e}")
   
    def get_collection_choices(self) -> List[Tuple[str, str]]:
        """Get collection choices for dropdown (display_name, collection_key)."""
        return [(info["display_name"], key) for key, info in self.PREDEFINED_COLLECTIONS.items()]
    
    def get_collection_display_name(self, collection_key: str) -> str:
        """Get display name for a collection key."""
        return self.PREDEFINED_COLLECTIONS.get(collection_key, {}).get("display_name", collection_key)
    
    def get_available_presentations(self, collection_key: Optional[str] = None) -> List[str]:
        """Get list of available presentations for dropdown, optionally filtered by collection."""
        try:
            if collection_key:
                uploaded_ppts = self.vector_store.get_uploaded_ppts_by_collection(collection_key)
            else:
                uploaded_ppts = self.vector_store.get_uploaded_ppts()
            return [ppt['file_name'] for ppt in uploaded_ppts]
        except Exception as e:
            logger.error(f"Error getting presentations: {e}")
            return []
    
    def get_presentation_info(self) -> Dict:
        """Get detailed information about all presentations across all collections."""
        try:
            return self.vector_store.get_all_stats()
        except Exception as e:
            logger.error(f"Error getting presentation info: {e}")
            return {}
    
    def _get_file_type(self, file_path: str) -> str:
        """Determine file type based on extension."""
        extension = Path(file_path).suffix.lower()
        if extension == '.pptx':
            return 'pptx'
        elif extension == '.pdf':
            return 'pdf'
        else:
            return 'unknown'
    
    def _get_images_for_presentations(self, file_names: List[str]) -> Dict[str, str]:
        """
        Load base64 images for the given presentation files.
        Handles both newly uploaded (in memory) and previously uploaded (from disk) files.
        
        Args:
            file_names: List of presentation file names
            
        Returns:
            Dictionary mapping slide_name to base64 image
        """
        combined_images = {}
        
        for file_name in file_names:
            try:
                # CASE 1: Check in-memory active cache (fastest)
                if file_name in self.active_images_cache:
                    logger.info(f"Using active memory cache for {file_name}")
                    combined_images.update(self.active_images_cache[file_name])
                    continue
                
                # CASe 2: Check disk cache (fast)
                cached_images = self.image_cache.load_images(file_name)
                if cached_images:
                    logger.info(f"Using disk cache for {file_name}")
                    combined_images.update(cached_images)
                    # Also add to active cache for next time
                    self.active_images_cache[file_name] = cached_images
                    continue

                # CASE 3: Cache miss - need to convert (slow)
                logger.warning(f"Cache miss for {file_name}, converting images...")

                # Get file path from metadata
                file_path = None
                for collection_key in self.PREDEFINED_COLLECTIONS.keys():
                    if file_name in self.vector_store.collections_metadata.get(collection_key, {}):
                        file_path = self.vector_store.collections_metadata[collection_key][file_name].get('file_path')
                        break
                
                if not file_path or not Path(file_path).exists():
                    logger.error(f"File not found for {file_name}")
                    continue
                
                # Determine file type
                file_type = self._get_file_type(file_name)
                
                # Convert document to images
                if file_type == 'pptx':
                    success, message, image_paths = self.file_handler.convert_ppt_to_images(file_path)
                elif file_type == 'pdf':
                    success, message, image_paths = self.file_handler.convert_pdf_to_images(file_path)
                else:
                    logger.warning(f"Unsupported file type for {file_name}")
                    continue
                
                if success and image_paths:
                    # Convert to base64
                    file_images = self.file_handler.convert_images_to_base64(image_paths)
                    
                    # CACHE THE IMAGES
                    self.image_cache.save_images(
                        file_name=file_name,
                        base64_images=file_images,
                        file_path=file_path
                    )
                    
                    # Add to both caches
                    combined_images.update(file_images)
                    self.active_images_cache[file_name] = file_images
                    
                    logger.info(f"Converted and cached {len(file_images)} images for {file_name}")
                else:
                    logger.warning(f"Failed to convert images for {file_name}: {message}")
                    
            except Exception as e:
                logger.error(f"Error loading images for {file_name}: {e}")
                continue
        
        logger.info(f"Total images loaded: {len(combined_images)}")
        return combined_images
    
    def _generate_reference_questions(self, context: str) -> Dict[str, str]:
        """
        Generate exactly three reference questions for a given chunk.
        Questions can be in English, Japanese, or a mix of both.

        Returns:
            dict with keys: ref_ques_1, ref_ques_2, ref_ques_3
        """
        try:
            prompt = f"""
            You are a skilled data analyst reviewing presentation materials.

            TASK:
            Generate exactly three unique and meaningful questions **in English** that are relevant to the context below.
            Follow these strict rules:
            1. Keep all Japanese terms, keywords, or proper nouns **exactly as they appear** in the context.
            2. Output only one single valid JSON array.
            3. The JSON must contain exactly three full questions.
            4. Do NOT include any extra text, comments, or explanation before or after the JSON.
            5. Each question must be complete, clear, and directly related to the context.

            If you cannot find enough meaningful questions, generate your best attempt.

            Context:
            {context}

            Output: Format strictly as example given below:
            ["Question 1", "Question 2", "Question 3"]
            """

            def _extract_questions(raw_output: str) -> list:
                """Extract and safely parse the JSON array."""
                cleaned = raw_output.strip()
                match = re.search(r'\[.*?\]', cleaned, re.DOTALL)
                if not match:
                    return []
                try:
                    json_str = re.sub(r'[“”]', '"', match.group(0))
                    questions = json.loads(json_str)
                    if isinstance(questions, list):
                        return questions
                except Exception:
                    return []
                return []

            # Try twice if first response is malformed
            for attempt in range(2):
                response = self.ref_ques_gen_model.generate_text(prompt=prompt, guardrails=False).strip()

                questions = _extract_questions(response)
                if isinstance(questions, list) and len(questions) > 0:
                    # Normalize to exactly 3 items
                    if len(questions) > 3:
                        questions = questions[:3]
                    elif len(questions) < 3:
                        questions.extend([""] * (3 - len(questions)))
                    return {
                        "ref_ques_1": questions[0],
                        "ref_ques_2": questions[1],
                        "ref_ques_3": questions[2],
                    }

            # Fallback (no valid output)
            logger.warning("No valid reference questions generated; returning blanks.")
            return {"ref_ques_1": "", "ref_ques_2": "", "ref_ques_3": ""}

        except Exception as e:
            logger.error(f"Error generating reference questions: {e}")
            return {"ref_ques_1": "", "ref_ques_2": "", "ref_ques_3": ""}

    def _extract_slide_number(self, slide_name: str) -> int:
        """
        Extract numeric value from slide name for sorting.
        Examples: "Slide_3" -> 3, "Slide_15.png" -> 15
        """
        try:
            return int(slide_name.split('_')[1].split('.')[0]) if '_' in slide_name else 0
        except (IndexError, ValueError) as e:
            logger.warning(f"Failed to extract slide number from '{slide_name}': {e}")
            raise e

    def _parse_slide_chunks_dynamic(self, slide_name: str, description_text: str) -> List[Dict[str, Any]]:
        """
        Parse slide description into ordered chunks.
        Reference questions are NOT generated here - they're added after overlap.
        """
        chunks = []
        slide_number = self._extract_slide_number(slide_name)

        if not description_text or not description_text.strip():
            chunks.append({
                "chunk_title": "full_slide",
                "description": "",
                "slide_name": slide_name,
                "slide_number": slide_number,
            })
            return chunks

        try:
            desc_str = description_text.strip("```json\n").rstrip("```").strip()
            # Clean all invisible and problematic chars
            desc_str = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', desc_str)
            desc_str = desc_str.replace('\ufeff', '').replace('\u2028', '').replace('\u2029', '')
            desc_str = desc_str.replace(""", '"').replace(""", '"').replace("'", "'").replace("'", "'")
            
            desc_data = json.loads(desc_str)
            title_text = desc_data.get("Title", "")

            # Extract content items in order
            for key, value in desc_data.items():
                if key == "Title" or not value:
                    continue
                
                if isinstance(value, (list, dict)):
                    content = f"[Title: {title_text}] {key}: {json.dumps(value, ensure_ascii=False)}"
                else:
                    content = f"[Title: {title_text}] {key}: {value}"

                chunks.append({
                    "chunk_title": key,
                    "description": content,
                    "slide_name": slide_name,
                    "slide_number": slide_number,
                })

            # Fallback: if no chunks were created
            if not chunks:
                chunks.append({
                    "chunk_title": "full_slide",
                    "description": description_text,
                    "slide_name": slide_name,
                    "slide_number": slide_number,
                })

        except Exception as e:
            logger.error(f"Error parsing slide '{slide_name}': {e}")
            chunks.append({
                "chunk_title": "full_slide",
                "description": description_text,
                "slide_name": slide_name,
                "slide_number": slide_number,
            })

        return chunks
    
    def _add_overlap_to_chunks(self, chunks: List[Dict[str, Any]], 
                           include_cross_slide: bool = True) -> List[Dict[str, Any]]:
        """
        Add overlap from previous and next chunks to each chunk.
        
        Args:
            chunks: List of chunks in sorted order
            include_cross_slide: If True, overlap spans across slides (RECOMMENDED)
                                If False, only overlap within same slide
        
        Returns:
            Chunks with overlap added to description field
        """
        if not chunks:
            logger.warning("No chunks provided for overlap processing")
            return chunks
        
        try:
            logger.info(f"Adding overlap to {len(chunks)} chunks (cross_slide={include_cross_slide})")
            enriched_chunks = []
            
            for i, chunk in enumerate(chunks):
                try:
                    current_slide = chunk.get("slide_number", 0)
                    overlap_parts = []
                    
                    # Add previous chunk context
                    if i > 0:
                        prev_chunk = chunks[i - 1]
                        prev_slide = prev_chunk.get("slide_number", 0)
                        
                        # Only add if same slide OR cross-slide is allowed
                        if include_cross_slide or (prev_slide == current_slide):
                            prev_context = f"[Previous: {prev_chunk.get('chunk_title', 'unknown')}]\n{prev_chunk.get('description', '')}"
                            overlap_parts.append(prev_context)
                    
                    # Add current chunk
                    overlap_parts.append(f"[Current]\n{chunk.get('description', '')}")
                    
                    # Add next chunk context
                    if i < len(chunks) - 1:
                        next_chunk = chunks[i + 1]
                        next_slide = next_chunk.get("slide_number", 0)
                        
                        # Only add if same slide OR cross-slide is allowed
                        if include_cross_slide or (next_slide == current_slide):
                            next_context = f"[Next: {next_chunk.get('chunk_title', 'unknown')}]\n{next_chunk.get('description', '')}"
                            overlap_parts.append(next_context)
                    
                    # Combine all parts
                    full_description = "\n\n".join(overlap_parts)
                    
                    # Create enriched chunk (WITHOUT ref questions - those come later)
                    enriched_chunk = {
                        **chunk,
                        "description": full_description,
                    }
                    
                    enriched_chunks.append(enriched_chunk)
                    
                except Exception as e:
                    logger.error(f"Error processing chunk {i} during overlap: {e}")
                    # Keep original chunk if overlap fails
                    enriched_chunks.append(chunk)
            
            logger.info(f"Successfully added overlap to {len(enriched_chunks)} chunks")
            return enriched_chunks
            
        except Exception as e:
            logger.error(f"Critical error in _add_overlap_to_chunks: {e}")
            # Return original chunks if entire process fails
            return chunks

    def process_document(self, document_file, selected_collection: str, progress=gr.Progress()) -> Tuple[str, gr.Dropdown, gr.Markdown]:
        """Process PowerPoint or PDF file and store slides/pages in the selected collection."""
        # --------------------------------------------------
        # 0. VALIDATION
        # --------------------------------------------------
        if not document_file:
            return "Error: No file uploaded.", gr.Dropdown(), gr.Markdown("No presentations available")

        if not selected_collection:
            return "Error: Please select a collection before uploading.", gr.Dropdown(), gr.Markdown("No collection selected")

        try:
            # Gradio passes a filepath string (because type="filepath")
            file_path_input = Path(document_file)
            file_name = file_path_input.name
            file_type = self._get_file_type(file_name)

            if file_type == 'unknown':
                return "Error: Unsupported file type. Upload .pptx or .pdf.", gr.Dropdown(), gr.Markdown("Unsupported file type")

            # --------------------------------------------------
            # 1. DUPLICATE CHECK
            # --------------------------------------------------
            progress(0.02, desc="Checking existing documents...")

            existing_presentations = self.get_available_presentations(selected_collection)
            if file_name in existing_presentations:
                collection_name = self.get_collection_display_name(selected_collection)
                return (
                    f"The document **{file_name}** is already processed in **{collection_name}**.",
                    gr.Dropdown(
                        choices=existing_presentations,
                        value=existing_presentations,
                        multiselect=True,
                        label=f"Select Documents from {collection_name} ({len(existing_presentations)} available)"
                    ),
                    gr.Markdown(self._format_overview(self.get_presentation_info()))
                )

            # --------------------------------------------------
            # 2. SAVE UPLOADED FILE
            # --------------------------------------------------
            progress(0.05, desc="Saving uploaded file...")

            saved_file_path = self.file_handler.save_uploaded_file(str(file_path_input), file_name)
            logger.info(f"File saved to: {saved_file_path}")

            # --------------------------------------------------
            # 3. CONVERT TO IMAGES
            # --------------------------------------------------
            progress(0.10, desc="Converting document to images...")

            if file_type == 'pptx':
                success, message, image_paths = self.file_handler.convert_ppt_to_images(saved_file_path)
            else:
                success, message, image_paths = self.file_handler.convert_pdf_to_images(saved_file_path)

            if not success:
                return f"Conversion Error: {message}", gr.Dropdown(), gr.Markdown("Conversion failed.")

            # --------------------------------------------------
            # 4. CONVERT IMAGES → BASE64 + CACHE
            # --------------------------------------------------
            progress(0.20, desc="Encoding and caching images...")

            self.base64_images = self.file_handler.convert_images_to_base64(image_paths)
            if not self.base64_images:
                return "Error: No images were generated.", gr.Dropdown(), gr.Markdown("Conversion produced no images.")

            # Cache images
            self.image_cache.save_images(file_name, self.base64_images, saved_file_path)
            self.active_images_cache[file_name] = self.base64_images

            # Store slide order
            self.slide_names = sorted(self.base64_images.keys(), key=lambda x: int(x.split('_')[1].split('.')[0]))

            # --------------------------------------------------
            # 5. SLIDE ANALYSIS (HEAVY) — must be chunked
            # --------------------------------------------------
            progress(0.30, desc="Analyzing slides...")

            total_slides = len(self.slide_names)
            for i, slide_name in enumerate(self.slide_names):
                img_b64 = self.base64_images[slide_name]
                desc = self.processor.analyze_slide_with_vlm(img_b64, slide_name)
                self.slide_descriptions[slide_name] = desc

                # Incremental UI update
                pct = 0.30 + (0.30 * ((i + 1) / total_slides))
                progress(pct, desc=f"Analyzing slide {i+1}/{total_slides}...")

            # --------------------------------------------------
            # 6. PARSE CHUNKS
            # --------------------------------------------------
            progress(0.60, desc="Parsing slide content...")

            chunks = []
            for slide_name in self.slide_names:
                chunks.extend(self._parse_slide_chunks_dynamic(slide_name, self.slide_descriptions[slide_name]))

            chunks = sorted(chunks, key=lambda c: self._extract_slide_number(c.get("slide_name", "")))

            chunks = self._add_overlap_to_chunks(chunks, include_cross_slide=True)

            # --------------------------------------------------
            # 7. GENERATE REFERENCE QUESTIONS (CRITICAL)
            # --------------------------------------------------
            progress(0.70, desc="Preparing data...")

            total_chunks = len(chunks)
            for i, chunk in enumerate(chunks):
                req = self._generate_reference_questions(chunk["description"])
                chunk.update(req)

                # yield to UI
                if i % 2 == 0:
                    pct = 0.70 + (0.10 * (i / total_chunks))
                    progress(pct, desc="Preparing data...")

            # --------------------------------------------------
            # 8. EMBEDDINGS
            # --------------------------------------------------
            progress(0.80, desc="Generating embeddings...")

            # Prepare text lists
            desc_texts = [self.tokenizer.tokenize(c["description"]) for c in chunks]
            ref1_texts = [self.tokenizer.tokenize(c["ref_ques_1"]) for c in chunks]
            ref2_texts = [self.tokenizer.tokenize(c["ref_ques_2"]) for c in chunks]
            ref3_texts = [self.tokenizer.tokenize(c["ref_ques_3"]) for c in chunks]

            # Embed in batches
            desc_embs = self.embedder.encode_batch(desc_texts)
            ref1_embs = self.embedder.encode_batch(ref1_texts)
            ref2_embs = self.embedder.encode_batch(ref2_texts)
            ref3_embs = self.embedder.encode_batch(ref3_texts)

            # Attach embeddings
            for i, c in enumerate(chunks):
                c["description"] = desc_texts[i]
                c["embeddings"] = desc_embs[i]
                c["ref_ques_1_emb"] = ref1_embs[i]
                c["ref_ques_2_emb"] = ref2_embs[i]
                c["ref_ques_3_emb"] = ref3_embs[i]

                # yield to UI
                if i % 2 == 0:
                    pct = 0.80 + (0.10 * (i / total_chunks))
                    progress(pct, desc="Generating embeddings...")

            # --------------------------------------------------
            # 9. UPLOAD TO VECTOR STORE
            # --------------------------------------------------
            progress(0.90, desc="Uploading to database...")

            result = self.vector_store.upload_ppt_to_collection(
                chunks=chunks,
                file_name=file_name,
                collection_key=selected_collection,
                file_path=saved_file_path
            )

            # --------------------------------------------------
            # 10. FINALIZE
            # --------------------------------------------------
            progress(0.99, desc="Finalizing...")

            self.current_file_name = file_name

            presentations = self.get_available_presentations(selected_collection)
            stats = self.get_presentation_info()

            collection_name = self.get_collection_display_name(selected_collection)
            content_type = "slides" if file_type == 'pptx' else "pages"

            status_message = (
                f"✅ {result['message']}\n"
                f"📊 {result['slide_count']} {content_type} processed in **{collection_name}**.\n"
                f"💬 You can now ask questions!"
            )

            updated_dropdown = gr.Dropdown(
                choices=presentations,
                value=presentations,
                multiselect=True,
                label=f"Select Documents from {collection_name} ({len(presentations)} available)"
            )

            overview_text = self._format_overview(stats)

            progress(1.0, desc="Complete!")

            return status_message, updated_dropdown, gr.Markdown(overview_text)

        except Exception as e:
            logger.error(f"Error processing document: {e}")
            return f"Error: {str(e)}", gr.Dropdown(), gr.Markdown("Error occurred")

    def _format_overview(self, stats: Dict) -> str:
        """Format presentation statistics for all collections."""
        if not stats:
            return "No documents available"
        
        overview = f"## ドキュメント概要\n\n"
        
        # Overall stats
        total_ppts = sum(stats.get(collection, {}).get('total_ppts', 0) for collection in self.PREDEFINED_COLLECTIONS.keys())
        total_slides = sum(stats.get(collection, {}).get('total_slides', 0) for collection in self.PREDEFINED_COLLECTIONS.keys())
        
        overview += f"**ドキュメント総数**: {total_ppts}\n"
        overview += f"**ページ/スライド総数**: {total_slides}\n\n"
        
        # Per collection stats
        for collection_key, collection_info in self.PREDEFINED_COLLECTIONS.items():
            collection_stats = stats.get(collection_key, {})
            collection_ppts = collection_stats.get('total_ppts', 0)
            collection_slides = collection_stats.get('total_slides', 0)
            
            overview += f"### 📁 {collection_info['display_name']}\n"
            overview += f"- **ドキュメント数**: {collection_ppts}\n"
            overview += f"- **ページ/スライド数**: {collection_slides}\n"
            
            if collection_stats.get('uploaded_files'):
                overview += f"- **アップロードファイル**:\n"
                for file_name in collection_stats['uploaded_files']:
                    overview += f"  - {file_name}\n"
            overview += "\n"
        
        return overview
    
    def expand_query(self, user_query: str, num_variations: int = 3) -> List[str]:
        """
        Expand user query into multiple semantic variations for better retrieval.
        Works for English/Japanese mixed queries.
        
        Args:
            user_query: Original user question
            num_variations: Number of variations to generate (default: 2)
        
        Returns:
            List of query variations including the original
        """
        try:
            prompt = f"""Generate {num_variations} different ways to ask the same question below.
                    Keep the meaning identical but vary the phrasing, word choice, and structure.
                    Keep Japanese terms exactly as they appear.

                    Rules:
                    1. Output ONLY a JSON array of strings
                    2. Each variation should be a complete, natural question
                    3. Variations should be meaningfully different from each other
                    4. Keep all technical terms, proper nouns, and Japanese words unchanged
                    5. Do NOT include any extra text, comments, or explanation

                    Original question: {user_query}

                    Output format:
                    ["variation 1", "variation 2", "variation 3]
                    """

            response = self.expand_query_gen_model.generate_text(prompt=prompt, guardrails=False).strip()
            logger.info(f"Query expansion response: {response[:200]}...")
            
            # Extract JSON array
            match = re.search(r'\[.*?\]', response, re.DOTALL)
            if match:
                json_str = re.sub(r'[""]', '"', match.group(0))
                variations = json.loads(json_str)
                
                if len(variations) > 0:
                    # Always include original query first
                    all_queries = [user_query] + variations[:num_variations]
                    
                    # Remove duplicates while preserving order
                    seen = set()
                    unique_queries = []
                    for q in all_queries:
                        q_lower = q.lower().strip()
                        if q_lower not in seen and q.strip():
                            seen.add(q_lower)
                            unique_queries.append(q.strip())
                    
                    logger.info(f"Query expanded to {len(unique_queries)} variations")
                    return unique_queries
            
            # Fallback: return original only
            logger.warning("Query expansion failed, using original query only")
            return [user_query]
            
        except Exception as e:
            logger.error(f"Error expanding query: {e}", exc_info=True)
            return [user_query]

    def chat_with_presentation(self, message: str, selected_collection: str, 
                            selected_presentations: List[str], history) -> Tuple[str, List]:
        """Chat with selected presentations from a specific collection (context-aware)."""
        if not message.strip():
            return "", history

        if not selected_collection:
            error_msg = "Please select a collection first."
            history.append({"role": "assistant", "content": error_msg})
            return "", history

        if not selected_presentations:
            collection_name = self.get_collection_display_name(selected_collection)
            error_msg = f"Please select at least one document from **{collection_name}**."
            history.append({"role": "assistant", "content": error_msg})
            return "", history

        try:
            # Build context-aware query
            def build_contextual_query(message: str, history: List[Dict[str, str]], max_turns: int = 3) -> str:
                relevant_history = [h for h in history if h["role"] in ("user", "assistant")][-max_turns * 2:]
                context = ""
                for h in relevant_history:
                    role = "User" if h["role"] == "user" else "Assistant"
                    context += f"{role}: {h['content']}\n"
                full_query = f"{context}User (current): {message}"
                return full_query.strip()

            combined_query = build_contextual_query(message, history)
            # QUERY EXPANSION - Generate variations
            logger.info(f"Original query: {message}")
            query_list = self.expand_query(combined_query, num_variations=4)
            logger.info(f"Query variations: {query_list}")

            # Tokenize and embed
            query_data: list[Dict[str, Any]] = []
            for query in query_list:
                tokenized = self.tokenizer.tokenize(query)
                embedding = self.embedder.encode_single(tokenized)
                query_data.append({
                    "query": query,
                    "tokenized": tokenized,
                    "embedding": embedding,
                    "original_query": message
                })

            # Retrieve relevant slides
            relevant_slides = self.vector_store.search_in_collection(
                selected_collection,
                query_data_list=query_data,
                top_k=3,
                file_names=selected_presentations
            )
            # DEBUG: Check for duplicates
            logger.info("="*60)
            logger.info("SLIDES RETURNED FROM SEARCH:")
            for i, slide in enumerate(relevant_slides):
                logger.info(f"{i+1}. {slide['file_name']} - Slide {slide['slide_number']} - Score: {slide.get('rerank_score', slide.get('score'))}")
            logger.info("="*60)

            # Generate response
            if not relevant_slides:
                collection_name = self.get_collection_display_name(selected_collection)
                response = f"I couldn't find relevant content in the selected documents from **{collection_name}**."
            else:
                file_with_results = list(set([s['file_name'] for s in relevant_slides]))
                # *** CHANGED: Use presentation_images instead of self.base64_images ***
                presentation_images = self._get_images_for_presentations(file_with_results)
                if not presentation_images:
                    logger.warning(f"No images available for presentations: {file_with_results}")

                response = self.processor.generate_answer_with_vision(
                    combined_query,
                    relevant_slides,
                    presentation_images  # *** WAS: self.base64_images ***
                )
                
                slide_refs = []
                for s in relevant_slides:
                    file_ext = Path(s['file_name']).suffix.lower()
                    content_type = "Slide" if file_ext == ".pptx" else "Page"
                    slide_refs.append(f"{content_type} {s['slide_number']} ({s['file_name']})")

                collection_name = self.get_collection_display_name(selected_collection)
                response += f"\n\n📑 *Referenced from **{collection_name}**: {', '.join(slide_refs)}*"

            # Update history
            history.append({"role": "user", "content": message})
            history.append({"role": "assistant", "content": response})

            return "", history

        except Exception as e:
            logger.error(f"Error in chat: {e}")
            history.append({"role": "assistant", "content": f"Error: {str(e)}"})
            return "", history
     
    def delete_presentations(self, selected_collection: str, selected_presentations: List[str]) -> Tuple[str, gr.Dropdown, gr.Markdown]:
        """Delete selected presentations from a specific collection."""
        if not selected_collection:
            return "Please select a collection first.", gr.Dropdown(), gr.Markdown("No collection selected")
            
        if not selected_presentations:
            return "Please select documents to delete.", gr.Dropdown(), gr.Markdown("No change")
        
        try:
            deleted_count = 0
            for file_name in selected_presentations:
                if self.vector_store.delete_ppt_from_collection(selected_collection, file_name):
                    deleted_count += 1

                    # DELETE FROM IMAGE CACHE
                    self.image_cache.delete_cache(file_name)
                    
                    # DELETE FROM ACTIVE CACHE
                    if file_name in self.active_images_cache:
                        del self.active_images_cache[file_name]
                    
                    logger.info(f"Deleted {file_name} and its cached images")
            
            presentations = self.get_available_presentations(selected_collection)
            stats = self.get_presentation_info()
            overview_text = self._format_overview(stats)
            
            collection_name = self.get_collection_display_name(selected_collection)
            updated_dropdown = gr.Dropdown(
                choices=presentations,
                value=presentations,
                multiselect=True,
                label=f"ドキュメントを選択 {collection_name} ({len(presentations)} 利用可能)"
            )
            
            return f"削除済み {deleted_count} ドキュメントから **{collection_name}**.", updated_dropdown, gr.Markdown(overview_text)
            
        except Exception as e:
            logger.error(f"ドキュメントの削除エラー: {e}")
            return f"削除エラー: {str(e)}", gr.Dropdown(), gr.Markdown("Error occurred")
    
    def update_presentation_dropdown(self, selected_collection: str) -> gr.Dropdown:
        """Update presentation dropdown based on selected collection."""
        self.clear_active_cache()
        if not selected_collection:
            return gr.Dropdown(choices=[], value=[], multiselect=True, label="コレクションを最初に選択")
        
        presentations = self.get_available_presentations(selected_collection)
        collection_name = self.get_collection_display_name(selected_collection)
        
        return gr.Dropdown(
            choices=presentations,
            value=presentations,
            multiselect=True,
            label=f"ドキュメントを選択 {collection_name} ({len(presentations)} 利用可能)"
        )
    
    def clear_active_cache(self, file_names: Optional[List[str]] = None):
        """
        Clear in-memory active cache to free up RAM.
        
        Args:
            file_names: Specific files to clear, or None to clear all
        """
        if file_names:
            for file_name in file_names:
                if file_name in self.active_images_cache:
                    del self.active_images_cache[file_name]
            logger.info(f"Cleared active cache for {len(file_names)} files")
        else:
            self.active_images_cache.clear()
            logger.info("Cleared entire active image cache")

    def clear_all(self) -> Tuple[str, List, gr.Dropdown, gr.Markdown]:
        """Clear chat history and UI state, but keep collections data intact."""
        try:
            # Reset local state only
            self.conversation_context = [""]
            self.clear_active_cache()
            
            # Keep presentations in collections, just reload overview
            stats = self.get_presentation_info()
            overview_text = self._format_overview(stats)
            
            # Reset dropdown to empty since no collection is selected
            updated_dropdown = gr.Dropdown(
                choices=[],
                value=[],
                multiselect=True,
                label="コレクションを最初に選択 "
            )
            
            return "チャット履歴が消去されました", [], updated_dropdown, gr.Markdown(overview_text)
        
        except Exception as e:
            logger.error(f"Error clearing chat: {e}")
            return f"Error clearing: {str(e)}", [], gr.Dropdown(), gr.Markdown("Error")
    
    def cleanup(self):
        """Clean up resources including image cache."""
        try:
            # Clear in-memory cache
            self.active_images_cache.clear()
            
            # Optionally clear disk cache (uncomment if needed)
            self.image_cache.clear_all()
            
            self.file_handler.cleanup()
            logger.info("Cleanup completed")
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

    def external_search_simple(self, query: str, history: list) -> tuple:
        """
        Perform external search using AgenticRAG and return in chat format
        """
        if not query.strip():
            return "", history
        
        # Add user message
        history.append({"role": "user", "content": query})
        
        try:
            # Check if AgenticRAG is available
            if self.agentic_rag is None:
                raise Exception("External search is not available. Please check API configuration.")
            
            # Extract conversation history (exclude the just-added user message)
            conversation_history = [
                msg for msg in history[:-1]
                if msg.get("role") in ["user", "assistant"]
            ]
            
            # Use AgenticRAG to search and generate response
            # logger.info(f"Performing external search for: {query}")
            result = self.agentic_rag.query(query, conversation_history)
            
            if result["error"]:
                response_text = f"エラーが発生しました: {result['error']}"
                logger.error(f"Search error: {result['error']}")
            else:
                # Format response with sources
                response_text = result["response"]
                
                # Add sources if available
                if result["sources"]:
                    response_text += "\n\n**📚 情報源:**\n"
                    for idx, source in enumerate(result["sources"], 1):
                        # Truncate preview text for display
                        preview = source['content'][:100] + "..." if len(source['content']) > 100 else source['content']
                        response_text += f"{idx}. [{source['url']}]({source['url']})\n   _{preview}_\n"
                
                # logger.info(f"External search completed with {len(result['sources'])} sources")
            
            # Add assistant response
            history.append({
                "role": "assistant", 
                "content": response_text
            })
            
        except Exception as e:
            logger.error(f"Error in external search: {e}")
            history.append({
                "role": "assistant",
                "content": f"エラーが発生しました: {str(e)}\n\n設定を確認してください。"
            })
        
        return "", history

def create_gradio_app(qa_system: PowerPointQASystem):
    with gr.Blocks(title="社内ナレッジ検索アシスタント") as app:
        gr.Markdown("## 社内ナレッジ検索アシスタント")
        
        # UI state for view control
        view_state = gr.State("home")  # home | chat | external

        # --- HOME VIEW ---
        home_view = gr.Group(visible=True)
        with home_view:
            with gr.Row(equal_height=True):
                with gr.Column(scale=1, min_width=400):
                    gr.Markdown("### 📁 コレクション選択")
                    collection_dropdown = gr.Dropdown(
                        choices=qa_system.get_collection_choices(),
                        label="コレクション",
                        value=None
                    )

                    gr.Markdown("### 📤 ファイルアップロード")
                    file_input = gr.File(
                        label="ドキュメントをアップロード (.pptx, .pdf)",
                        file_types=[".pptx", ".pdf"],
                        type="filepath"
                    )
                    process_btn = gr.Button("📊 ドキュメント処理", variant="primary")
                    status_output = gr.Textbox(label="Status", interactive=False, max_lines=5)
                    
                    gr.Markdown("### 🎯 ドキュメント選択")
                    presentation_dropdown = gr.Dropdown(
                        choices=[],
                        label="コレクションを最初に選択",
                        multiselect=True,
                        value=[]
                    )
                    with gr.Row():
                        refresh_btn = gr.Button("🔄 更新", variant='primary')
                        delete_btn = gr.Button("🗑️ 削除", variant='primary')
                    
                    overview_output = gr.Markdown(
                        value=qa_system._format_overview(qa_system.get_presentation_info())
                    )
                    
                    go_to_chat_btn = gr.Button("💬 Q&A へ移動", variant="primary")
                    external_search_btn = gr.Button("🌐 外部検索へ", variant='secondary')

        # --- CHAT VIEW ---
        chat_view = gr.Group(visible=False)
        with chat_view:
            gr.Markdown("### 💬 ドキュメントQ&A")
            back_to_home_btn = gr.Button("⬅️ コレクションに戻る", variant="primary")
            chatbot = gr.Chatbot(
                label="Q&A",
                height=800,
                type="messages", 
                value=[{"role": "assistant", "content": "ようこそ！質問をどうぞ。"}]
            )
            msg_input = gr.Textbox(show_label=False,placeholder="質問を入力...", lines=1,scale=6)
            send_btn = gr.Button("📤 送信", variant="primary")
            clear_chat_btn = gr.Button("🧹 チャットを消去", variant="secondary")

        # --- EXTERNAL SEARCH VIEW ---
        external_view = gr.Group(visible=False)
        with external_view:
            gr.Markdown("### 🌐 外部検索")
            back_to_home2_btn = gr.Button("⬅️ コレクションに戻る", variant="primary")
            external_chatbot = gr.Chatbot(
                label="Q&A",
                height=800,
                type="messages", 
                value=[{"role": "assistant", "content": "ようこそ！質問をどうぞ。"}]
            )
            external_msg_input = gr.Textbox(show_label=False,placeholder="質問を入力...", lines=1,scale=6)
            search_btn = gr.Button("🔎 検索", variant="primary")
            clear_external_btn = gr.Button("🧹 結果を消去", variant="secondary")
        # --- EVENT HANDLERS ---
        collection_dropdown.change(
            fn=qa_system.update_presentation_dropdown,
            inputs=[collection_dropdown],
            outputs=[presentation_dropdown]
        )
        
        process_btn.click(
            fn=qa_system.process_document,
            # fn=lambda f, c: qa_system.process_document(f, c),
            inputs=[file_input, collection_dropdown],
            outputs=[status_output, presentation_dropdown, overview_output]
        ).then(
            fn=lambda: None,  # clear file input after processing
            inputs=[],
            outputs=[file_input]
        )

        send_btn.click(
            fn=lambda m, c, s, h: qa_system.chat_with_presentation(m, c, s, h),
            inputs=[msg_input, collection_dropdown, presentation_dropdown, chatbot],
            outputs=[msg_input, chatbot]
        )
        msg_input.submit(
            fn=lambda m, c, s, h: qa_system.chat_with_presentation(m, c, s, h),
            inputs=[msg_input, collection_dropdown, presentation_dropdown, chatbot],
            outputs=[msg_input, chatbot]
        )
        
        refresh_btn.click(
            fn=lambda c: (
                qa_system.update_presentation_dropdown(c),
                gr.Markdown(qa_system._format_overview(qa_system.get_presentation_info()))
            ),
            inputs=[collection_dropdown],
            outputs=[presentation_dropdown, overview_output]
        )
        
        delete_btn.click(
            fn=qa_system.delete_presentations,
            inputs=[collection_dropdown, presentation_dropdown],
            outputs=[status_output, presentation_dropdown, overview_output]
        )
        
        # Clear only the chat history, not the entire state
        clear_chat_btn.click(
            fn=lambda: [{"role": "assistant", "content": "ようこそ！質問をどうぞ。"}],
            outputs=[chatbot]
        )
        
        # Clear only the external search results
        clear_external_btn.click(
            fn=lambda: [{"role": "assistant", "content": "ようこそ！質問をどうぞ。"}],
            outputs=[external_chatbot]
        )
        
        # Navigation
        go_to_chat_btn.click(
            fn=lambda: ("chat", gr.update(visible=False), gr.update(visible=True), gr.update(visible=False)),
            inputs=[],
            outputs=[view_state, home_view, chat_view, external_view]
        )

        external_search_btn.click(
            fn=lambda: ("external", gr.update(visible=False), gr.update(visible=False), gr.update(visible=True)),
            inputs=[],
            outputs=[view_state, home_view, chat_view, external_view]
        )

        back_to_home_btn.click(
            fn=lambda: ("home", gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)),
            inputs=[],
            outputs=[view_state, home_view, chat_view, external_view]
        )

        back_to_home2_btn.click(
            fn=lambda: ("home", gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)),
            inputs=[],
            outputs=[view_state, home_view, chat_view, external_view]
        )

        # External search handler - calls the new external_search_simple method
        search_btn.click(
        fn=lambda query, history: qa_system.external_search_simple(query, history),
        inputs=[external_msg_input, external_chatbot],
        outputs=[external_msg_input, external_chatbot]
    )
        
        external_msg_input.submit(
            fn=lambda query, history: qa_system.external_search_simple(query, history),
            inputs=[external_msg_input, external_chatbot],
            outputs=[external_msg_input, external_chatbot]
        )
    
    return app

def main():
    """Main entry point."""
    try:
        qa_system = PowerPointQASystem()
        app = create_gradio_app(qa_system)
        import atexit
        atexit.register(qa_system.cleanup)
        
        # Get authentication credentials from settings
        settings = get_settings()
        auth_credentials = (settings.JRI_ID, settings.JRI_PW) if hasattr(settings, 'JRI_ID') and hasattr(settings, 'JRI_PW') else None
        
        # Launch with authentication
        app.launch(
            auth=auth_credentials,
            server_name="0.0.0.0", 
            server_port=7860, 
            share=False, 
            show_error=True, 
            debug=True
        )
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise


if __name__ == "__main__":
    main()
