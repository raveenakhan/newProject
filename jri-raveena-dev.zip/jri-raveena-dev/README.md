# PowerPoint Q&A System with Vision-Based Retrieval
*A next-generation AI system for querying visual PowerPoint content using multimodal intelligence.*

---

## Features

- **Visual Content Analysis**: Uses VLM to extract comprehensive descriptions from slide images  
- **Hybrid Search**: Semantic search using Milvus vector database and keyword search  
- **Vision-Based Answers**: Generates answers by analyzing relevant slide images directly  
- **Web Interface**: User-friendly Gradio interface for internal and external search  
- **Modular Architecture**: Clean separation of concerns for maintainability  

---

## Architecture
PowerPoint → Images → VLM Analysis → Vector Storage → Hybrid Search → Vision-Based Q&A
---
## Quick Start

1. **Setup Environment**
```bash
   make setup
   make install
```
2. **Configure Environment Variables Edit .env file with your credentials:**
```bash
    WATSONX_API_KEY=your_watsonx_api_key_here
    WATSONX_PROJECT_ID=your_watsonx_project_id_here
    WATSONX_URL=https://us-south.ml.cloud.ibm.com
    MILVUS_HOST=localhost
    MILVUS_PORT=19530
    MILVUS_USER=
    MILVUS_PASSWORD=
    TAVILY_API_KEY=
    JRI_ID="admin"
    JRI_PW="Password"
    LOG_LEVEL=INFO
    RESET_INTERVAL=3600
    COLLECTION_NAME=PowerPointSlides
    DATA_DIR=
    LOGS_DIR=
```
3. **Run the Application**
```bash
   make run
```
4. **Access Web Interface Open http://localhost:7860 in your browser**
## 5. Usage

1. **Upload PowerPoint**  
   Upload a `.pptx` or `.pdf` file through the web interface for a selected collection.

2. **Processing**  
   The system will:
   - Convert slides to images  
   - Analyze content using the Vision-Language Model (VLM)  
   - Store descriptions in a vector database  

3. **Ask Questions**  
   Query the presentation content naturally.

4. **Get Answers**  
   Receive vision-based answers with slide references.

---

## 6. Dependencies

| Component | Description |
|------------|-------------|
| **VLM** | Watson X (`meta-llama/llama-4-maverick-17b-128e-instruct-fp8`) |
| **Vector DB** | Milvus |
| **Embeddings** | `sentence-transformers` (`multilingual-e5-large`) |
| **Web Interface** | Gradio |
| **Document Processing** | LibreOffice, `pdftoppm` |
| **External Search** | Tavilly API Key |

---

## 7. System Requirements

- **Python** 3.8 or higher  
- **LibreOffice** (for PowerPoint conversion)  
- **poppler-utils** (for PDF to image conversion)  
- **Access to Watson X API**  
- **Milvus Vector Database**
