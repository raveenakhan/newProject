"""Configuration module for PowerPoint Q&A system."""
from .settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]