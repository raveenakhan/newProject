"""Configuration settings for the PowerPoint Q&A system."""
import os
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field
from dotenv import load_dotenv


class Settings(BaseSettings):
    """Application settings."""
    
    # Watson X Configuration
    watsonx_api_key: str = Field(..., env="WATSONX_API_KEY")
    watsonx_project_id: str = Field(..., env="WATSONX_PROJECT_ID")
    watsonx_url: str = Field(
        "https://us-south.ml.cloud.ibm.com", 
        env="WATSONX_URL"
    )
    watsonx_model_id: str = Field(..., env="WATSONX_MODEL_ID")
    
    # Milvus Configuration (⚡ no defaults, must be in .env)
    milvus_host: str = Field(..., env="MILVUS_HOST")
    milvus_port: int = Field(..., env="MILVUS_PORT")
    milvus_user: str = Field(..., env="MILVUS_USER")
    milvus_password: str = Field(..., env="MILVUS_PASSWORD")
    
    # Embedding Configuration
    embedding_model_name: str = Field(
        "intfloat/multilingual-e5-large", 
        env="EMBEDDING_MODEL_NAME"
    )
    embedding_dimension: int = Field(1024, env="EMBEDDING_DIMENSION")

    # Reranker Configuration
    reranker_model: str = Field(
        "BAAI/bge-reranker-base", 
        env="RERANKER_MODEL"
    )
    
    # Application Configuration
    collection_name: str = Field("PowerPointSlides", env="COLLECTION_NAME")
    reset_interval: int = Field(3600, env="RESET_INTERVAL")
    log_level: str = Field("INFO", env="LOG_LEVEL")
    JRI_ID : str = Field("admin", env="JRI_ID") 
    JRI_PW : str = Field("admin", env="JRI_PW")
    
    # Paths
    data_dir: str = Field("data", env="DATA_DIR")
    logs_dir: str = Field("logs", env="LOGS_DIR")
    tavily_api_key: str=Field("logs", env="TAVILY_API_KEY")
    
    class Config:
        env_file = ".env"
        case_sensitive = False


_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings singleton."""
    global _settings
    if _settings is None:
        load_dotenv()
        _settings = Settings()
    return _settings