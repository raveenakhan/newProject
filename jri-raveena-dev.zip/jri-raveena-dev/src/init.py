"""PowerPoint Q&A System - Main package."""
__version__ = "1.0.0"