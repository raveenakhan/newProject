"""Embedding modules."""
from .embedder import EmbeddingGenerator

__all__ = ["EmbeddingGenerator"]