"""Embedding generation module."""
from typing import List, Union
import numpy as np
from sentence_transformers import SentenceTransformer
import logging
import os

logger = logging.getLogger(__name__)


class EmbeddingGenerator:
    """Generate embeddings for text using sentence transformers."""
    
    def __init__(self, model_name: str = "intfloat/multilingual-e5-large"):
        self.model_name = model_name
        self.model = None
        self.dimension = None
        self._initialize_model()
    
    def _initialize_model(self) -> None:
        """Initialize the embedding model."""
        try:
            logger.info(f"Loading embedding model: {self.model_name}")
            self.model = SentenceTransformer(self.model_name)
            
            # Verify dimension
            test_embedding = self.model.encode("test")
            self.dimension = len(test_embedding)
            logger.info(f"Embedding model loaded successfully (dimension: {self.dimension})")
            
        except Exception as e:
            logger.error(f"Failed to initialize embedding model: {e}")
            raise
    
    def encode_single(self, text: str, normalize: bool = True) -> List[float]:
        """Encode a single text into embedding."""
        if not self.model:
            raise RuntimeError("Embedding model not initialized")
        
        embedding = self.model.encode(text, normalize_embeddings=normalize)
        return embedding.tolist()
    
    def encode_batch(self, texts: List[str], normalize: bool = True) -> List[List[float]]:
        """Encode multiple texts into embeddings."""
        if not self.model:
            raise RuntimeError("Embedding model not initialized")
        
        embeddings = self.model.encode(texts, normalize_embeddings=normalize)
        return embeddings.tolist()
    
    def get_dimension(self) -> int:
        """Get embedding dimension."""
        return self.dimension