"""Slide processing module."""
from typing import Dict, List, Tuple
import requests
import logging
from ..utils.auth import WatsonXAuth
logger = logging.getLogger(__name__)


class SlideProcessor:
    """Process slides using VLM analysis."""
    
    def __init__(self, api_key: str, project_id: str, base_url: str):
        self.auth = WatsonXAuth(api_key)
        self.project_id = project_id
        self.base_url = base_url
        self.chat_url = f"{base_url}/ml/v1/text/chat?version=2023-05-29"
    
    def analyze_slide_with_vlm(self, base64_image: str, slide_name: str) -> str:
        """Analyze slide content using VLM and return detailed description."""
        body = {
            "messages": [
                {
                    "role": "system",
                    "content": """You are an expert AI assistant specialized in analyzing Japanese PowerPoint slides. 
Your task is to provide a comprehensive description of the slide content containing complex figures that will be used for semantic search.

Please extract and describe:
- All visible text, titles, and headings in Japanese
- A narrative description of the meanings and messages of images, graphs, charts, and diagrams in rather than its appearance or format in English with Japanese keywords
- Business concepts, processes, or frameworks shown in English
- Key insights, conclusions, or takeaways in English
- Any numerical data, statistics, or metrics

Provide a detailed, structured description that captures all the information someone would need to understand and discuss this slide's content in the following json format:
```json
{
    "Title": {The title of the slide},
    "Lead": {Lead paragraph of the slide. Blank if not exist.},
    "Main Content": {Description of main contents including visual contents of the slide. The description must contain all the Japanese keywords(キーワード) in the slide including figures.},
    "Key Insights": {Key insights, conclusions, or takeaways}
}
```"""
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"Please provide a comprehensive description of this PowerPoint slide ({slide_name}):"},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                    ]
                }
            ],
            "project_id": self.project_id,
            "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
            "decoding_method": "greedy",
            "max_tokens": 2000,
            "temperature": 0.1,
            "seed": 42
        }
        
        try:
            response = requests.post(self.chat_url, headers=self.auth.get_auth_headers(), json=body)
            response.raise_for_status()
            
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return content
        except Exception as e:
            logger.error(f"Error analyzing slide with VLM: {e}")
            return f"Error analyzing slide: {str(e)}"
    
    def generate_answer_with_vision(
        self,
        question: str,
        relevant_slides: List[Dict],
        base64_images: Dict[str, str]
    ) -> str:
        """Generate answer using vision model with retrieved slide images."""
        messages = [
            {
                "role": "system",
                "content": """You are a helpful assistant that answers questions about PowerPoint presentations.
You will be provided with relevant slide images and a user question.
Analyze the slide images carefully and provide a clear, accurate answer based on the visual content in Japanese only.
Be specific and reference what you can see in the slides.
必ず日本語で回答すること"""
            },
            {
                "role": "user", 
                "content": [
                    {"type": "text", "text": f"Question: {question}\n\nPlease analyze these relevant slides and answer the question in japanese only:"}
                ]
            }
        ]
        
        # Add relevant slide images
        for slide in relevant_slides:
            slide_name = slide['slide_name']
            
            if slide_name in base64_images:
                base64_image = base64_images[slide_name]
                
                messages[1]["content"].extend([
                    {"type": "text", "text": f"\nSlide {slide['slide_number']} ({slide_name}):"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                ])
        
        body = {
            "messages": messages,
            "project_id": self.project_id,
            "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
            "decoding_method": "greedy",
            "max_tokens": 2000,
            "temperature": 0.0,
            "seed": 42
        }
        
        try:
            response = requests.post(self.chat_url, headers=self.auth.get_auth_headers(), json=body)
            response.raise_for_status()
            
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return content
            
        except Exception as e:
            logger.error(f"Error generating answer with vision model: {e}")
            return f"Error generating answer: {str(e)}"
