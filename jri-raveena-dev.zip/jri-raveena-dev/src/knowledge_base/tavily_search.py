"""
knowledge_base/tavily_search.py

Agentic RAG System with LangGraph, Tavily Web Search, and WatsonX LLM
This module provides external web search capabilities for the QA system.
"""

import os
import logging
from typing import TypedDict, List, Optional
from dotenv import load_dotenv

from langgraph.graph import StateGraph, END
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_ibm import WatsonxLLM

# Load environment variables
load_dotenv()
logger = logging.getLogger(__name__)


class AgentState(TypedDict):
    """State object for the agent workflow"""
    query: str
    conversation_history: Optional[List[dict]]
    search_results: Optional[List[dict]]
    context: Optional[str]
    response: Optional[str]
    error: Optional[str]


class AgenticRAG:
    """
    Agentic RAG system that searches the web and generates responses using LangGraph workflow.
    
    Features:
    - Web search using Tavily
    - Context-aware responses with conversation history
    - Structured workflow with state management
    - Source citation and error handling
    """
    
    def __init__(
        self,
        watsonx_api_key: str,
        watsonx_project_id: str,
        tavily_api_key: str,
        watsonx_url: str = "https://us-south.ml.cloud.ibm.com",
        model_id: str = "meta-llama/llama-3-3-70b-instruct",
        max_search_results: int = 3
    ):
        """
        Initialize the agentic RAG system.
        
        Args:
            watsonx_api_key: IBM Cloud API key
            watsonx_project_id: WatsonX project ID
            tavily_api_key: Tavily API key
            watsonx_url: WatsonX service URL
            model_id: WatsonX model identifier
            max_search_results: Maximum number of search results to retrieve
        """
        self.max_search_results = max_search_results
        
        # Initialize Tavily search tool
        logger.info("Initializing Tavily search tool...")
        self.search_tool = TavilySearchResults(
            max_results=max_search_results,
            api_key=tavily_api_key
        )
        
        # Initialize WatsonX LLM
        logger.info(f"Initializing WatsonX LLM with model: {model_id}")
        self.llm = WatsonxLLM(
            model_id=model_id,
            url=watsonx_url,
            apikey=watsonx_api_key,
            project_id=watsonx_project_id,
            params={
                "decoding_method": "sample",
                "max_new_tokens": 2000,
                "min_new_tokens": 50,
                "temperature": 0.7,
                "top_k": 50,
                "top_p": 0.95
            }
        )
        
        # Build and compile the workflow
        logger.info("Building LangGraph workflow...")
        self.workflow = self._build_workflow()
        self.app = self.workflow.compile()
        logger.info("AgenticRAG system initialized successfully")
    
    def _web_search(self, state: AgentState) -> AgentState:
        """
        Execute web search using Tavily.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with search results
        """
        try:
            query = state["query"]
            logger.info(f"Searching for: {query}")
            
            results = self.search_tool.invoke({"query": query})
            
            state["search_results"] = results
            state["error"] = None
            logger.info(f"Found {len(results)} search results")
            
            return state
        except Exception as e:
            error_msg = f"Search error: {str(e)}"
            logger.error(f"{error_msg}")
            state["error"] = error_msg
            state["search_results"] = []
            return state
    
    def _prepare_context(self, state: AgentState) -> AgentState:
        """
        Format search results into context for the LLM.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with formatted context
        """
        if state.get("error") or not state.get("search_results"):
            state["context"] = "No search results available."
            logger.warning("No search results to prepare")
            return state
        
        context_parts = []
        for idx, result in enumerate(state["search_results"], 1):
            content = result.get("content", "")
            url = result.get("url", "")
            title = result.get("title", "")
            
            context_parts.append(
                f"Source {idx}:\n"
                f"Title: {title}\n"
                f"Content: {content}\n"
                f"URL: {url}"
            )
        
        state["context"] = "\n\n".join(context_parts)
        logger.info(f"Prepared context from {len(state['search_results'])} sources")
        return state
    
    def _generate_response(self, state: AgentState) -> AgentState:
        """
        Generate response using WatsonX LLM with search context and conversation history.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with generated response
        """
        try:
            query = state["query"]
            context = state.get("context", "")
            conversation_history = state.get("conversation_history", [])
            
            # Build conversation context
            history_text = ""
            if conversation_history:
                history_text = "Previous Conversation:\n"
                # Include last 3 exchanges (6 messages)
                for msg in conversation_history[-6:]:
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    history_text += f"{role.capitalize()}: {content}\n"
                history_text += "\n"
            
            # Create prompt
            prompt = f"""You are a helpful AI assistant. Answer the user's question based on the provided web search results and conversation history.

{history_text}Web Search Results:
{context}

Current Question: {query}

Instructions:
- 検索結果に基づき、正確で明確な回答を作成してください。
- 会話履歴の内容を考慮してください。
- 参照がある場合は、出典番号を日本語で明記してください（例：「出典1によると」または「（出典1）」）。
- 検索結果に十分な情報がない場合は、その旨を明記してください。
- 簡潔かつ丁寧に説明してください。
- 質問が日本語の場合は日本語で、英語の場合は英語で回答してください。

Answer:"""
            
            logger.info("Generating response with LLM...")
            response = self.llm.invoke(prompt)
            state["response"] = response
            state["error"] = None
            logger.info("Response generated successfully")
            
        except Exception as e:
            error_msg = f"Generation error: {str(e)}"
            logger.error(f"{error_msg}")
            state["error"] = error_msg
            state["response"] = "Failed to generate response. Please try again."
        
        return state
    
    def _build_workflow(self) -> StateGraph:
        """
        Build the LangGraph workflow with three nodes:
        1. Web search
        2. Context preparation
        3. Response generation
        
        Returns:
            Compiled StateGraph workflow
        """
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("web_search", self._web_search)
        workflow.add_node("prepare_context", self._prepare_context)
        workflow.add_node("generate_response", self._generate_response)
        
        # Define workflow edges
        workflow.set_entry_point("web_search")
        workflow.add_edge("web_search", "prepare_context")
        workflow.add_edge("prepare_context", "generate_response")
        workflow.add_edge("generate_response", END)
        
        return workflow
    
    def query(self, user_query: str, conversation_history: List[dict] = None) -> dict:
        """
        Process a user query through the agentic RAG workflow.
        
        Args:
            user_query: The user's question
            conversation_history: Previous conversation messages (list of dicts with 'role' and 'content')
            
        Returns:
            Dictionary containing:
                - query: Original query
                - response: Generated response
                - sources: List of source URLs and content
                - error: Error message if any
        """
        logger.info(f"Processing query: {user_query[:100]}...")
        
        initial_state = AgentState(
            query=user_query,
            conversation_history=conversation_history or [],
            search_results=None,
            context=None,
            response=None,
            error=None
        )
        
        # Execute workflow
        final_state = self.app.invoke(initial_state)
        
        # Format output
        result = {
            "query": final_state["query"],
            "response": final_state["response"],
            "sources": [
                {
                    "url": r.get("url"),
                    "title": r.get("title", ""),
                    "content": r.get("content", "")[:200]  # Preview only
                }
                for r in (final_state.get("search_results") or [])
            ],
            "error": final_state.get("error")
        }
        
        logger.info(f"Query processed. Sources: {len(result['sources'])}, Error: {result['error']}")
        return result