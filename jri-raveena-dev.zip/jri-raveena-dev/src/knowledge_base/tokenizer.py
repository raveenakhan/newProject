import re
import unicodedata
import MeCab
import logging

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class HybridJapaneseEnglishTokenizer:
    """
    Hybrid tokenizer for Japanese + English text, optimized for embeddings.
    
    Features:
    - Unicode normalization (NFKC)
    - Remove control characters
    - Preserve English words and numbers
    - Japanese tokenization via MeCab
    - Punctuation preserved
    """

    def __init__(self):
        try:
            self.tagger = MeCab.Tagger("-Owakati")
            logger.info("MeCab tokenizer initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize MeCab: {e}")
            raise RuntimeError("MeCab initialization failed") from e

    def normalize_text(self, text: str) -> str:
        """Normalize Unicode and remove control characters."""
        try:
            text = unicodedata.normalize("NFKC", text)
            text = re.sub(r'[\x00-\x1F\x7F]', '', text)  # remove control chars
            return text
        except Exception as e:
            logger.warning(f"Unicode normalization failed: {e}")
            return text

    def protect_english_words(self, text: str) -> str:
        """Add spaces around English/number sequences to preserve them during Japanese tokenization."""
        try:
            text = re.sub(r"([A-Za-z0-9]+)", r" \1 ", text)
            return re.sub(r"\s+", " ", text).strip()
        except Exception as e:
            logger.warning(f"English word protection failed: {e}")
            return text

    def tokenize(self, text: str) -> str:
        """
        Full hybrid pipeline:
        1. Normalize Unicode + remove control chars
        2. Protect English words/numbers
        3. MeCab tokenization
        4. Keep punctuation intact

        Returns:
            str: Space-separated tokenized text ready for embeddings
        """
        if not text:
            return ""

        try:
            text = self.normalize_text(text)
            text = self.protect_english_words(text)

            tokenized = self.tagger.parse(text)
            if not tokenized:
                logger.warning("MeCab returned None or empty string, returning original text")
                return text

            tokens = tokenized.strip().split()
            return " ".join(tokens)

        except Exception as e:
            logger.error(f"Tokenization failed: {e}")
            return text