from sentence_transformers import CrossEncoder
from typing import List, Dict, Any, Optional
from config.settings import get_settings
import logging
import os

logger = logging.getLogger(__name__)


class Reranker:
    def __init__(self) -> None:
        """Initialize CrossEncoder reranker with optional model override"""
        try:
            settings = get_settings()
            logger.info(f"Loading cross-encoder reranker model: {settings.reranker_model}")
            self.reranker = CrossEncoder(settings.reranker_model)
        except Exception as e:
            logger.error(f"Error initializing reranker: {e}", exc_info=True)
            raise
    
    def rerank(
        self, 
        query: str, 
        results: List[Any],
        content_field: str = "description",
        top_k: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Rerank results using CrossEncoder model.
        
        Args:
            query: The search query string
            results: List of result dictionaries
            content_field: Field name containing the text to rerank (default: "description")
            top_k: Optional limit on number of results to return
            
        Returns:
            List of reranked results with added 'rerank_score' field
        """
        try:
            # Quick validation
            if not results or not query or not query.strip():
                logger.warning("Empty query or results provided to reranker")
                return []
            
            # Filter and validate results
            valid_results = []
            for i, result in enumerate(results):
                if not isinstance(result, dict):
                    logger.warning(f"Result at index {i} is not a dict: {type(result)}")
                    continue
                    
                content = result.get(content_field, "").strip()
                if not content:
                    logger.warning(f"Empty content field '{content_field}' at index {i}")
                    continue
                    
                valid_results.append(result)
            
            if not valid_results:
                logger.warning("No valid results found for reranking")
                return []
            
            # Prepare pairs for cross-encoder
            pairs = [(query, result[content_field]) for result in valid_results]
            
            # Batch prediction
            logger.info(f"Reranking {len(pairs)} candidates with cross-encoder...")
            scores = self.reranker.predict(pairs)
            
            # Ensure scores is iterable
            if not hasattr(scores, '__iter__'):
                scores = [scores]
            
            # Add rerank scores to results
            for result, score in zip(valid_results, scores):
                result["rerank_score"] = float(score)
                # Keep original retrieval score for reference
                if "score" in result:
                    result["retrieval_score"] = result["score"]
            
            # Sort by reranker score (descending)
            reranked_results = sorted(
                valid_results, 
                key=lambda x: x.get("rerank_score", -float('inf')),
                reverse=True
            )
            
            reranked_results = reranked_results[:top_k]
            
            if reranked_results:
                logger.info(
                    f"Reranking complete. Top score: {reranked_results[0]['rerank_score']:.4f} "
                    f"(retrieval: {reranked_results[0].get('retrieval_score', 'N/A')})"
                )
            
            return reranked_results

        except Exception as e:
            logger.error(f"Error while reranking: {e}", exc_info=True)
            # Fallback: return original results
            try:
                # Results is annotated as a list; directly build fallback_results
                fallback_results = [r for r in results if isinstance(r, dict) and r.get(content_field)]
                logger.warning(f"Falling back to {len(fallback_results)} unranked results")
                return fallback_results[:top_k] if top_k else fallback_results
            except Exception:
                pass
            return []
