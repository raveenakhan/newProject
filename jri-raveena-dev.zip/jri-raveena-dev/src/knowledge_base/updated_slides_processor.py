"""Slide processing module with retry logic and image concatenation."""
from typing import Dict, List, Optional
import requests
import logging
import time
import base64
import io
from PIL import Image

# Import based on your project structure
from ..utils.auth import WatsonXAuth

logger = logging.getLogger(__name__)


class SlideProcessor:
    """Process slides using VLM analysis with retry logic."""
    
    def __init__(self, api_key: str, project_id: str, base_url: str):
        self.auth = WatsonXAuth(api_key)
        self.project_id = project_id
        self.base_url = base_url
        self.chat_url = f"{base_url}/ml/v1/text/chat?version=2023-05-29"
        
        # Retry configuration
        self.max_retries = 3
        self.retry_delay = 3  # seconds
        
        logger.info(f"SlideProcessor initialized with {self.max_retries} max retries")
    
    def _make_api_call_with_retry(
        self, 
        body: Dict, 
        timeout: int = 60,
        operation: str = "API call"
    ) -> requests.Response:
        """
        Make API call with retry logic.
        
        Args:
            body: Request body
            timeout: Request timeout in seconds
            operation: Description of operation (for logging)
            
        Returns:
            Response object
            
        Raises:
            Exception if all retries fail
        """
        last_error = None
        
        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    wait_time = self.retry_delay * attempt  # Exponential backoff
                    logger.info(f"Retry attempt {attempt}/{self.max_retries} for {operation} (waiting {wait_time}s)")
                    time.sleep(wait_time)
                
                response = requests.post(
                    self.chat_url,
                    headers=self.auth.get_auth_headers(),
                    json=body,
                    timeout=timeout
                )
                response.raise_for_status()
                
                # Success!
                if attempt > 0:
                    logger.info(f"{operation} succeeded on attempt {attempt + 1}")
                
                return response
                
            except requests.exceptions.Timeout as e:
                last_error = e
                logger.warning(f"{operation} timed out (attempt {attempt + 1}/{self.max_retries + 1}, timeout={timeout}s)")
                
            except requests.exceptions.RequestException as e:
                last_error = e
                logger.error(f"{operation} failed with error: {e}")
                # Don't retry on non-timeout errors (like 4xx, 5xx)
                if hasattr(e, 'response') and e.response is not None:
                    status_code = e.response.status_code
                    if 400 <= status_code < 500:
                        # Client error - don't retry
                        break
        
        # All retries failed
        logger.error(f"{operation} failed after {self.max_retries + 1} attempts")
        raise last_error
    
    def analyze_slide_with_vlm(self, base64_image: str, slide_name: str) -> str:
        """Analyze slide content using VLM and return detailed description."""
        body = {
            "messages": [
                {
                    "role": "system",
                    "content": """You are an expert AI assistant specialized in analyzing Japanese PowerPoint slides. 
Your task is to provide a comprehensive description of the slide content containing complex figures that will be used for semantic search.

Please extract and describe:
- All visible text, titles, and headings in Japanese
- A narrative description of the meanings and messages of images, graphs, charts, and diagrams in rather than its appearance or format in English with Japanese keywords
- Business concepts, processes, or frameworks shown in English
- Key insights, conclusions, or takeaways in English
- Any numerical data, statistics, or metrics

IMPORTANT: You must respond with valid JSON only. Do not include any text before or after the JSON.

Provide a detailed, structured description in this exact JSON format:
{
    "Title": "The title of the slide",
    "Lead": "Lead paragraph of the slide. Empty string if not exist.",
    "Main Content": "Description of main contents including visual contents of the slide. The description must contain all the Japanese keywords in the slide including figures.",
    "Key Insights": "Key insights, conclusions, or takeaways"
}"""
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"Please provide a comprehensive description of this PowerPoint slide ({slide_name}):"},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                    ]
                }
            ],
            "project_id": self.project_id,
            "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
            "decoding_method": "greedy",
            "max_tokens": 2000,
            "temperature": 0.1,
            "seed": 42
        }
        
        try:
            response = self._make_api_call_with_retry(
                body, 
                timeout=60,
                operation=f"Analyzing slide {slide_name}"
            )
            
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return content
            
        except Exception as e:
            logger.error(f"Error analyzing slide {slide_name} with VLM: {e}")
            return f"Error analyzing slide: {str(e)}"
    
    def _resize_image(self, image: Image.Image, max_width: int = 1120, max_height: int = 1120) -> Image.Image:
        """画像をリサイズ"""
        height, width = image.height, image.width
        
        width_ratio = max_width / width
        height_ratio = max_height / height
        resize_ratio = min(width_ratio, height_ratio)
        
        new_size = (int(width * resize_ratio), int(height * resize_ratio))
        new_image = image.resize(new_size, Image.LANCZOS)
        
        return new_image
    
    def _concatenate_images_vertically(self, images: List[Image.Image], output_width: int = 1120, output_height: int = 1120) -> Image.Image:
        """画像を縦に結合"""
        total_height = sum(img.height for img in images)
        max_width = max(img.width for img in images)
        
        new_image = Image.new("RGB", (max_width, total_height))
        
        current_height = 0
        for img in images:
            new_image.paste(img, (0, current_height))
            current_height += img.height
        
        new_image = self._resize_image(new_image, output_width, output_height)
        
        return new_image
    
    def _base64_to_pil(self, base64_str: str) -> Image.Image:
        """Base64文字列をPIL Imageに変換"""
        img_data = base64.b64decode(base64_str)
        return Image.open(io.BytesIO(img_data))
    
    def _pil_to_base64(self, image: Image.Image) -> str:
        """PIL ImageをBase64文字列に変換"""
        buffered = io.BytesIO()
        image.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')

    def _analyze_concatenated_slides(
        self,
        question: str,
        relevant_slides: List[Dict],
        concatenated_image_base64: str
    ) -> str:
        """Analyze concatenated slides with single VLM call."""
        
        # Build slide reference information
        slide_refs = "\n".join([
            f"スライド {slide['slide_number']}: {slide['slide_name']}"
            for slide in relevant_slides
        ])
        
        messages = [
            {
                "role": "system",
                "content": """You are a helpful assistant that analyzes PowerPoint slides to answer specific questions.
Carefully examine the concatenated slide images and extract information that is relevant to the user's question.
The image contains multiple slides stacked vertically - analyze each slide section separately.
Describe what you see in each slide: text, diagrams, charts, tables, images, and any visual elements that help answer the question.
必ず日本語で回答すること"""
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"""質問: {question}

以下のスライドが縦に結合されています：
{slide_refs}

これらのスライドから、質問に関連する情報を抽出して、包括的な回答を作成してください。
各スライドの情報を参照する際は、スライド番号を明記してください。"""
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{concatenated_image_base64}"}
                    }
                ]
            }
        ]
        
        body = {
            "messages": messages,
            "project_id": self.project_id,
            "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
            "decoding_method": "greedy",
            "max_tokens": 3000,  # Increased for multiple slides
            "temperature": 0.0,
            "seed": 42
        }
        
        try:
            response = self._make_api_call_with_retry(
                body,
                timeout=90,  # Longer timeout for multiple slides
                operation="Analyzing concatenated slides"
            )
            
            data = response.json()
            analysis = data["choices"][0]["message"]["content"]
            
            logger.info(f"Successfully analyzed {len(relevant_slides)} concatenated slides")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing concatenated slides: {e}")
            return f"スライド分析エラー: {str(e)}"

    def generate_answer_with_vision(
        self,
        question: str,
        relevant_slides: List[Dict],
        base64_images: Dict[str, str]
    ) -> str:
        """Generate answer using single VLM call with concatenated images."""
        if not relevant_slides:
            logger.warning("No relevant slides provided")
            return "質問に関連するスライドが見つかりませんでした。"
        
        logger.info(f"Starting answer generation for question: '{question}'")
        logger.info(f"Processing {len(relevant_slides)} retrieved slides")
        logger.info(f"Available images: {len(base64_images)}")
        
        # Collect PIL images for concatenation
        pil_images = []
        valid_slides = []
        
        for idx, slide in enumerate(relevant_slides, 1):
            slide_name = slide['slide_name']
            
            # Use flexible image matching
            base64_image = self._find_slide_image(slide_name, base64_images)
            
            if base64_image is None:
                logger.warning(f"Image not found for slide: {slide_name}")
                continue
            
            try:
                pil_img = self._base64_to_pil(base64_image)
                pil_images.append(pil_img)
                valid_slides.append(slide)
                logger.info(f"Added slide {idx}/{len(relevant_slides)}: {slide_name}")
            except Exception as e:
                logger.error(f"Error converting image for slide {slide_name}: {e}")
                continue
        
        if not pil_images:
            logger.error("No valid images found for concatenation")
            return "スライドの画像が利用できません。"
        
        # Concatenate images vertically
        logger.info(f"Concatenating {len(pil_images)} images vertically")
        concatenated_image = self._concatenate_images_vertically(pil_images)
        concatenated_base64 = self._pil_to_base64(concatenated_image)
        
        # Single VLM call with concatenated image
        logger.info("Analyzing concatenated slides with single VLM call")
        final_answer = self._analyze_concatenated_slides(
            question=question,
            relevant_slides=valid_slides,
            concatenated_image_base64=concatenated_base64
        )
        
        logger.info("Answer generation complete")
        return final_answer
    
    def _find_slide_image(self, slide_name: str, base64_images: Dict[str, str]) -> Optional[str]:
        """Find slide image with flexible matching."""
        # Try exact match first
        if slide_name in base64_images:
            return base64_images[slide_name]
        
        # Try case-insensitive match
        for key in base64_images.keys():
            if key.lower() == slide_name.lower():
                return base64_images[key]
        
        # Try partial match (e.g., "slide_1.png" matches "slide_1")
        slide_base = slide_name.replace('.png', '').replace('.jpg', '')
        for key in base64_images.keys():
            key_base = key.replace('.png', '').replace('.jpg', '')
            if key_base == slide_base or key_base.lower() == slide_base.lower():
                return base64_images[key]
        
        return None