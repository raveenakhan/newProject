"""Enhanced Milvus vector store implementation with predefined collections for client groups."""
import hashlib
import json
import os
from typing import List, Dict, Any, Optional
from pymilvus import (
    connections, FieldSchema, CollectionSchema, DataType,
    Collection, utility, Function, FunctionType, RRFRanker, AnnSearchRequest
    )
import logging
from datetime import datetime
from config.settings import get_settings
from src.knowledge_base.reranker import Reranker

# Set up logger to match your project structure
logger = logging.getLogger(__name__)


class MilvusVectorStore:
    """Enhanced Milvus vector database operations with predefined collections for client groups."""
    
    def __init__(self, predefined_collections: Optional[Dict[str, Dict]] = None):
        # Load settings from .env
        settings = get_settings()

        self.host = settings.milvus_host
        self.port = settings.milvus_port
        self.user = settings.milvus_user
        self.password = settings.milvus_password
        self.dimension = settings.embedding_dimension
        # Sparse Vector Configuration
        self.analyzer_params = {"tokenizer": {"type": "lindera", "dict_kind": "ipadic"}}
        self.metadata_file = os.path.join(settings.data_dir, "collections_metadata.json")

        self.reranker = Reranker()
        
        # Predefined collections for different client groups
        self.predefined_collections = predefined_collections or {
            "BPR_CONSULTING": {
                "display_name": "BPR Consulting",
                "description": "Business Process Reengineering consulting materials"
            },
            "ENERGY_SECTOR": {
                "display_name": "Energy Sector Consulting", 
                "description": "Energy sector consulting presentations and documents"
            },
            "GENERAL_SECTOR": {
                "display_name": "General Sector Consulting",
                "description": "General sector consulting materials"
            }
        }
        
        # Metadata structure: {collection_key: {file_name: {metadata...}}}
        self.collections_metadata: Dict[str, Dict[str, Dict]] = {}
        
        self._connect()
        self._initialize_predefined_collections()
        self._load_metadata()
    
    def _connect(self) -> None:
        """Connect to Milvus."""
        try:
            connections.connect(
                "default",
                host=self.host,
                port=self.port,
                secure=True,
                user=self.user,
                password=self.password
            )
            logger.info("Milvus connection established")
        except Exception as e:
            logger.error(f"Milvus connection failed: {e}")
            raise
    
    def _initialize_predefined_collections(self) -> None:
        """Initialize all predefined collections in Milvus."""
        try:
            for collection_key in self.predefined_collections.keys():
                collection_name = self._get_milvus_collection_name(collection_key)
                
                if not utility.has_collection(collection_name):
                    logger.info(f"Creating predefined collection: {collection_name}")
                    self._setup_collection(collection_name)
                else:
                    logger.info(f"Predefined collection already exists: {collection_name}")
                    
            logger.info("All predefined collections initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing predefined collections: {e}")
            raise
    
    def _get_milvus_collection_name(self, collection_key: str) -> str:
        """Get the actual Milvus collection name for a collection key."""
        return f"ppt_{collection_key.lower()}"
    
    def _load_metadata(self) -> None:
        """Load collections metadata from file."""
        try:
            # Ensure data directory exists
            os.makedirs(os.path.dirname(self.metadata_file), exist_ok=True)
            
            if os.path.exists(self.metadata_file):
                with open(self.metadata_file, 'r', encoding='utf-8') as f:
                    loaded_metadata = json.load(f)
                
                # Initialize structure for all predefined collections
                for collection_key in self.predefined_collections.keys():
                    if collection_key not in self.collections_metadata:
                        self.collections_metadata[collection_key] = {}
                    
                    # Load existing data if available
                    if collection_key in loaded_metadata:
                        self.collections_metadata[collection_key] = loaded_metadata[collection_key]
                
                logger.info(f"Loaded metadata for {len(self.collections_metadata)} collections")
            else:
                # Initialize empty metadata structure
                for collection_key in self.predefined_collections.keys():
                    self.collections_metadata[collection_key] = {}
                logger.info("No existing metadata file found, initialized empty structure")
        except Exception as e:
            logger.error(f"Error loading metadata: {e}")
            # Initialize empty structure as fallback
            for collection_key in self.predefined_collections.keys():
                self.collections_metadata[collection_key] = {}
    
    def _save_metadata(self) -> None:
        """Save collections metadata to file."""
        try:
            # Ensure data directory exists
            os.makedirs(os.path.dirname(self.metadata_file), exist_ok=True)
            
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.collections_metadata, f, indent=2, ensure_ascii=False)
            logger.info(f"Saved metadata for {len(self.collections_metadata)} collections")
        except Exception as e:
            logger.error(f"Error saving metadata: {e}")
    
    def _create_collection_schema(self) -> CollectionSchema:
        """Create the standard schema for PowerPoint slide collections."""
        return CollectionSchema([
            FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, auto_id=False, max_length=64),
            FieldSchema(name="slide_name", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(
                name="description",
                dtype=DataType.VARCHAR,
                max_length=65000,
                analyzer_params=self.analyzer_params,
                enable_match=True,
                enable_analyzer=True
                ),
            FieldSchema(name="ref_ques_1", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="ref_ques_2", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="ref_ques_3", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="slide_number", dtype=DataType.INT64),
            FieldSchema(name="file_name", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="chunk_title", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="embeddings", dtype=DataType.FLOAT_VECTOR, dim=self.dimension),
            FieldSchema(name="ref_ques_1_embedding", dtype=DataType.FLOAT_VECTOR, dim=self.dimension),
            FieldSchema(name="ref_ques_2_embedding", dtype=DataType.FLOAT_VECTOR, dim=self.dimension),
            FieldSchema(name="ref_ques_3_embedding", dtype=DataType.FLOAT_VECTOR, dim=self.dimension),
            FieldSchema(name="sparse_vector", dtype=DataType.SPARSE_FLOAT_VECTOR)
        ], description="PowerPoint slide descriptions and embeddings")
    
    def _setup_BM25_function(self, schema) -> CollectionSchema:
        """Add BM25 function type to the schema"""
        # Define BM25 function to generate sparse vectors from text
        bm25_function = Function(
            name="bm25",
            function_type=FunctionType.BM25,
            input_field_names=["description"],
            output_field_names="sparse_vector",
        )
        # Add the function to schema
        schema.add_function(bm25_function)
        logger.info("Schema with BM25 function created")
        return schema
    
    def _setup_collection(self, collection_name: str) -> Collection:
        """Setup a new collection."""
        try:
            schema = self._create_collection_schema()
            logger.info("Creating new collection schema")

            schema = self._setup_BM25_function(schema=schema)
            
            logger.info(f"Creating new collection: {collection_name}")
            collection = Collection(collection_name, schema, consistency_level="Strong")
            
            # Create index
            dense_vector_index = {
                'metric_type': 'IP',
                'index_type': 'IVF_FLAT',
                'params': {'nlist': 128}
            }
            sparse_vector_index = {
                'metric_type': 'BM25',
                'index_type': 'SPARSE_INVERTED_INDEX',
                'params': {"drop_ratio_build": 0.2}
            }
            logger.info(f"Creating IVF_FLAT index for {collection_name}")
            collection.create_index("embeddings", dense_vector_index)
            collection.create_index("ref_ques_1_embedding", dense_vector_index)
            collection.create_index("ref_ques_2_embedding", dense_vector_index)
            collection.create_index("ref_ques_3_embedding", dense_vector_index)

            logger.info(f"Creating SPARSE_INVERTED_INDEX for {collection_name}")
            collection.create_index("sparse_vector", sparse_vector_index)

            logger.info(f"Collection {collection_name} setup completed successfully")
            
            return collection
            
        except Exception as e:
            logger.error(f"Error setting up collection {collection_name}: {e}")
            raise
    
    def upload_ppt_to_collection(
        self,
        chunks: List[Dict[str, Any]],
        file_name: str,
        collection_key: str,
        file_path: Optional[str] = None  # *** ADD THIS PARAMETER ***
    ) -> Dict[str, Any]:
        """Upload a PowerPoint file to a specific predefined collection."""
        try:
            if collection_key not in self.predefined_collections:
                raise ValueError(f"Invalid collection key: {collection_key}")
            
            # Check if this file already exists in this collection
            if self.ppt_exists_in_collection(collection_key, file_name):
                existing_metadata = self.collections_metadata[collection_key][file_name]
                logger.info(f"PPT file '{file_name}' already exists in collection '{collection_key}'")
                return {
                    'status': 'exists',
                    'message': f"PPT '{file_name}' already uploaded to {self.predefined_collections[collection_key]['display_name']}",
                    'collection_key': collection_key,
                    'slide_count': existing_metadata['slide_count'],
                    'upload_date': existing_metadata['upload_date']
                }
            
            # Get Milvus collection name and load collection
            milvus_collection_name = self._get_milvus_collection_name(collection_key)
            collection = Collection(milvus_collection_name)
            
            # Insert slide data
            entities = []
            for chunk in chunks:
                slide_id = hashlib.md5(f"{collection_key}_{file_name}_{chunk['slide_name']}_{chunk['chunk_title']}".encode()).hexdigest()

                entities.append({
                    "id": slide_id,
                    "slide_name": chunk["slide_name"],
                    "description": chunk["description"],
                    "chunk_title": chunk["chunk_title"],
                    "slide_number": chunk["slide_number"],
                    "file_name": file_name,
                    "embeddings": chunk["embeddings"],
                    "ref_ques_1": chunk["ref_ques_1"],
                    "ref_ques_2": chunk["ref_ques_2"],
                    "ref_ques_3": chunk["ref_ques_3"],
                    "ref_ques_1_embedding": chunk["ref_ques_1_emb"],
                    "ref_ques_2_embedding": chunk["ref_ques_2_emb"],
                    "ref_ques_3_embedding": chunk["ref_ques_3_emb"]
                })

            if entities:
                collection.insert(entities)
                collection.flush()
  
                # Update metadata
                self.collections_metadata[collection_key][file_name] = {
                    'slide_count': len(entities),
                    'upload_date': datetime.now().isoformat(),
                    'dimension': self.dimension,
                    'file_path': file_path
                }
                
                # Save metadata to file
                self._save_metadata()
                
                inserted_count = len(entities)
                collection_display_name = self.predefined_collections[collection_key]['display_name']
                logger.info(f"Successfully uploaded {inserted_count} chunks from '{file_name}' to collection '{collection_key}'")
                return {
                    'status': 'created',
                    'message': f"Successfully uploaded to {collection_display_name}",
                    'collection_key': collection_key,
                    'slide_count': inserted_count,
                    'upload_date': self.collections_metadata[collection_key][file_name]['upload_date']
                }
            
            return {
                'status': 'error',
                'message': 'No slides to insert'
            }
            
        except Exception as e:
            logger.error(f"Error uploading PPT '{file_name}' to collection '{collection_key}': {e}")
            raise
    
    def ppt_exists_in_collection(self, collection_key: str, file_name: str) -> bool:
        """Check if PPT file already exists in a specific collection."""
        return (collection_key in self.collections_metadata and 
                file_name in self.collections_metadata[collection_key])
    
    def get_uploaded_ppts_by_collection(self, collection_key: str) -> List[Dict[str, Any]]:
        """Get list of uploaded PPT files in a specific collection."""
        if collection_key not in self.collections_metadata:
            return []
        
        ppts = []
        for file_name, metadata in self.collections_metadata[collection_key].items():
            ppts.append({
                'file_name': file_name,
                'collection_key': collection_key,
                'collection_name': self.predefined_collections[collection_key]['display_name'],
                'slide_count': metadata['slide_count'],
                'upload_date': metadata['upload_date'],
                'dimension': metadata.get('dimension', self.dimension)
            })
        return ppts
    
    def get_uploaded_ppts(self) -> List[Dict[str, Any]]:
        """Get list of all uploaded PPT files across all collections."""
        all_ppts = []
        for collection_key in self.predefined_collections.keys():
            all_ppts.extend(self.get_uploaded_ppts_by_collection(collection_key))
        return all_ppts

    def _combine_chunks_by_slide(
        self, 
        candidate_list: List[Dict[str, Any]], 
        score_threshold: float = 0.9
    ) -> List[Dict[str, Any]]:
        """
        Combine multiple high-scoring chunks from the same slide.
        
        Args:
            candidate_list: List of candidate chunks sorted by score
            score_threshold: Combine chunks within this % of top score per slide (default: 0.9)
            
        Returns:
            List of unique slides with combined chunks, all metadata preserved
        """
        from collections import defaultdict
        
        # Group chunks by slide
        slide_groups = defaultdict(list)
        for candidate in candidate_list:
            slide_key = (candidate['file_name'], candidate['slide_number'])
            slide_groups[slide_key].append(candidate)
        
        logger.info(f"Grouping {len(candidate_list)} chunks into {len(slide_groups)} unique slides")
        
        # Combine chunks per slide
        unique_candidates = []
        
        for slide_key, chunks in slide_groups.items():
            # Sort chunks by score (highest first)
            chunks.sort(key=lambda x: x['score'], reverse=True)
            
            top_chunk = chunks[0]  # Keep all metadata from highest scoring chunk
            top_score = top_chunk['score']
            
            # Find chunks with score >= threshold * top_score
            threshold_score = top_score * score_threshold
            relevant_chunks = [c for c in chunks if c['score'] >= threshold_score]
            
            if len(relevant_chunks) > 1:
                # Limit to top 3 chunks to avoid token overflow
                relevant_chunks = relevant_chunks[:3]
                
                # Combine descriptions
                combined_descriptions = []
                chunk_titles = []
                individual_chunks = []  # Store individual chunk details
                
                for chunk in relevant_chunks:
                    combined_descriptions.append(chunk['description'])
                    if chunk.get('chunk_title'):
                        chunk_titles.append(chunk['chunk_title'])
                    
                    # Store individual chunk details
                    individual_chunks.append({
                        'chunk_id': chunk.get('id'),
                        'chunk_title': chunk.get('chunk_title'),
                        'score': chunk.get('score'),
                        'query_matches': chunk.get('query_matches'),
                        'description': chunk.get('description')
                    })
                
                # Update combined fields (all other metadata is preserved automatically)
                top_chunk['description'] = "\n\n---\n\n".join(combined_descriptions)
                top_chunk['chunk_title'] = " + ".join(chunk_titles) if chunk_titles else top_chunk['chunk_title']
                top_chunk['combined_from'] = len(relevant_chunks)
                top_chunk['individual_chunks'] = individual_chunks
                
                logger.info(
                    f"Combined {len(relevant_chunks)} chunks from "
                    f"{slide_key[0]} Slide {slide_key[1]} (scores: {[f'{c['score']:.3f}' for c in relevant_chunks]})"
                )
            else:
                # Single chunk - still add individual_chunks for consistency
                top_chunk['combined_from'] = 1
                top_chunk['individual_chunks'] = [{
                    'chunk_id': top_chunk.get('id'),
                    'chunk_title': top_chunk.get('chunk_title'),
                    'score': top_chunk.get('score'),
                    'query_matches': top_chunk.get('query_matches'),
                    'description': top_chunk.get('description')
                }]
            
            unique_candidates.append(top_chunk)
        
        # Sort combined candidates by score
        unique_candidates.sort(
            key=lambda x: (x['query_matches'], x['score']), 
            reverse=True
        )
        
        logger.info(
            f"After combination: {len(unique_candidates)} unique slides "
            f"(combined {sum(c.get('combined_from', 1) for c in unique_candidates)} original chunks)"
        )
        
        return unique_candidates


    def _rerank_candidates(
        self,
        candidates: List[Dict[str, Any]],
        original_query: str,
        top_k: int
    ) -> List[Dict[str, Any]]:
        """
        Rerank candidates using cross-encoder.
        
        Args:
            candidates: List of candidates to rerank
            original_query: Original user query (not expanded)
            top_k: Number of results to return
            
        Returns:
            Top-k reranked results with all metadata preserved
        """
        if not candidates:
            return []
        
        # Check if reranker is available
        if hasattr(self, 'reranker') and self.reranker:
            logger.info(f"Reranking {len(candidates)} candidates with cross-encoder")
            
            try:
                reranked_results = self.reranker.rerank(
                    query=original_query,
                    results=candidates,
                    content_field="description",
                    top_k=top_k
                )
                return reranked_results
                
            except Exception as e:
                logger.error(f"Reranking failed: {e}, falling back to original ranking")
                return candidates[:top_k]
        else:
            logger.info("No reranker available, using original ranking")
            return candidates[:top_k]


    def search_in_collection(
        self,
        collection_key: str,
        query_data_list: List[Dict[str, Any]],
        top_k: int = 3,
        file_names: Optional[List[str]] = None,
        score_threshold: Optional[float] = 0.9
    ) -> List[Dict[str, Any]]:
        """
        Search within a specific collection using hybrid search with RRF.
        Supports multiple query variations, smart chunk combination, and reranking.
        
        Args:
            collection_key: Collection to search in
            query_data_list: List of dicts with 'query', 'tokenized', 'embedding', 'original_query' keys
            top_k: Number of final results to return
            file_names: Optional list of files to filter by
            score_threshold: Combine chunks within this % of top score (default: 0.9)
            
        Returns:
            List of top-k results after combination and reranking with all metadata
        """
        try:
            if collection_key not in self.predefined_collections:
                logger.warning(f"Invalid collection key: {collection_key}")
                return []

            milvus_collection_name = self._get_milvus_collection_name(collection_key)
            collection = Collection(milvus_collection_name)
            collection.load()

            # Build expression for file filtering
            expr = None
            if file_names:
                escaped_names = [name.replace("'", "\\'") for name in file_names]
                file_list = "', '".join(escaped_names)
                expr = f"file_name in ['{file_list}']"
            
            output_fields = ['slide_name', 'description', 'slide_number', 'file_name', 'chunk_title']
            all_candidates = {}
            
            logger.info(f"Performing hybrid search with {len(query_data_list)} query variations")

            # Multi-query hybrid search
            for idx, query_data in enumerate(query_data_list):
                try:
                    query_embedding = query_data['embedding']
                    tokenized_query = query_data['tokenized']
                    
                    requests = []

                    # Sparse search (BM25)
                    sparse_req = AnnSearchRequest(
                        data=[tokenized_query],
                        anns_field="sparse_vector",
                        param={"metric_type": "BM25"},
                        limit=top_k,
                        expr=expr
                    )
                    requests.append(sparse_req)

                    # Dense search (multiple embedding fields)
                    dense_fields = [
                        "embeddings",
                        "ref_ques_1_embedding",
                        "ref_ques_2_embedding",
                        "ref_ques_3_embedding"
                    ]

                    for field in dense_fields:
                        dense_req = AnnSearchRequest(
                            data=[query_embedding],
                            anns_field=field,
                            param={"metric_type": "IP", "params": {"nprobe": 32}},
                            limit=top_k,
                            expr=expr
                        )
                        requests.append(dense_req)

                    # Hybrid search with RRF
                    raw_results = collection.hybrid_search(
                        reqs=requests,
                        rerank=RRFRanker(k=60),
                        limit=top_k * 10,
                        output_fields=output_fields
                    )

                    hybrid_hits = raw_results[0] if raw_results else []
                    logger.info(f"Query variation {idx+1} found {len(hybrid_hits)} results")
                    
                    # Aggregate results with all metadata
                    for hit in hybrid_hits:
                        doc_id = hit.id
                        ent = hit.entity

                        if doc_id not in all_candidates:
                            all_candidates[doc_id] = {
                                "id": doc_id,
                                "slide_name": ent.get("slide_name"),
                                "description": ent.get("description"),
                                "chunk_title": ent.get("chunk_title"),
                                "slide_number": ent.get("slide_number"),
                                "file_name": ent.get("file_name"),
                                "collection_key": collection_key,
                                "collection_name": self.predefined_collections[collection_key]["display_name"],
                                "score": float(hit.distance),
                                "query_matches": 1
                            }
                        else:
                            all_candidates[doc_id]["score"] += float(hit.distance)
                            all_candidates[doc_id]["query_matches"] += 1
                    
                except Exception as e:
                    logger.error(f"Error processing query variation {idx+1}: {e}")
                    continue
            
            if not all_candidates:
                logger.warning("No results found for any query variation")
                return []
            
            # Sort candidates by score
            candidate_list = list(all_candidates.values())
            candidate_list.sort(
                key=lambda x: (x['query_matches'], x['score']), 
                reverse=True
            )
            
            # Combine chunks by slide (preserves all metadata)
            unique_candidates = self._combine_chunks_by_slide(
                candidate_list, score_threshold)
            
            # Extract original query and rerank
            original_query = query_data_list[0].get(
                'original_query', query_data_list[0]['query'])
            final_results = self._rerank_candidates(
                unique_candidates, original_query, top_k)
            
            logger.info(
                f"Multi-query search pipeline: "
                f"{len(all_candidates)} chunks"
                f"{len(unique_candidates)} unique slides"
                f"{len(final_results)} final results"
            )
            
            return final_results

        except Exception as e:
            logger.error(f"Error searching in collection '{collection_key}': {e}", exc_info=True)
            return []
    
    def delete_ppt_from_collection(self, collection_key: str, file_name: str) -> bool:
        """Delete a PPT file from a specific collection."""
        try:
            if not self.ppt_exists_in_collection(collection_key, file_name):
                logger.warning(f"PPT file '{file_name}' not found in collection '{collection_key}'")
                return False
            
            milvus_collection_name = self._get_milvus_collection_name(collection_key)
            collection = Collection(milvus_collection_name)
            
            # Load the collection before performing delete operation
            collection.load()
            
            # Delete entries with matching file_name
            expr = f"file_name == {repr(file_name)}"
            collection.delete(expr)
            
            # Flush to ensure deletion is persisted
            collection.flush()
            
            # Remove from metadata
            del self.collections_metadata[collection_key][file_name]
            self._save_metadata()
            
            collection_display_name = self.predefined_collections[collection_key]['display_name']
            logger.info(f"Successfully deleted PPT '{file_name}' from collection '{collection_display_name}'")
            return True
        
        except Exception as e:
            logger.error(f"Error deleting PPT '{file_name}' from collection '{collection_key}': {e}")
            return False
    
    def get_collection_stats(self, collection_key: str) -> Dict[str, Any]:
        """Get statistics for a specific collection."""
        try:
            if collection_key not in self.collections_metadata:
                return {'total_ppts': 0, 'total_slides': 0, 'uploaded_files': []}
            
            collection_data = self.collections_metadata[collection_key]
            total_ppts = len(collection_data)
            total_slides = sum(metadata['slide_count'] for metadata in collection_data.values())
            
            return {
                'total_ppts': total_ppts,
                'total_slides': total_slides,
                'uploaded_files': list(collection_data.keys())
            }
            
        except Exception as e:
            logger.error(f"Error getting statistics for collection '{collection_key}': {e}")
            return {'total_ppts': 0, 'total_slides': 0, 'uploaded_files': []}
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Get statistics for all collections."""
        try:
            all_stats = {}
            for collection_key in self.predefined_collections.keys():
                all_stats[collection_key] = self.get_collection_stats(collection_key)
            return all_stats
            
        except Exception as e:
            logger.error(f"Error getting all collection statistics: {e}")
            return {}
    
    def clear_collection(self, collection_key: str) -> None:
        """Clear all data from a specific collection."""
        try:
            if collection_key not in self.predefined_collections:
                logger.warning(f"Invalid collection key: {collection_key}")
                return
            
            milvus_collection_name = self._get_milvus_collection_name(collection_key)
            
            # Clear the collection in Milvus
            if utility.has_collection(milvus_collection_name):
                collection = Collection(milvus_collection_name)
                # Delete all entities
                collection.delete("")
                
            # Clear metadata for this collection
            self.collections_metadata[collection_key] = {}
            self._save_metadata()
            
            collection_display_name = self.predefined_collections[collection_key]['display_name']
            logger.info(f"Cleared collection '{collection_display_name}'")
            
        except Exception as e:
            logger.error(f"Error clearing collection '{collection_key}': {e}")
    
    def clear_all_collections(self) -> None:
        """Clear all data from all predefined collections."""
        try:
            for collection_key in self.predefined_collections.keys():
                self.clear_collection(collection_key)
            
            # Clear metadata file
            if os.path.exists(self.metadata_file):
                os.remove(self.metadata_file)
            
            # Reinitialize empty metadata structure
            for collection_key in self.predefined_collections.keys():
                self.collections_metadata[collection_key] = {}
            
            logger.info("All collections cleared")
            
        except Exception as e:
            logger.error(f"Error clearing all collections: {e}")
            raise
    
    def get_predefined_collections(self) -> Dict[str, Dict]:
        """Get information about predefined collections."""
        return self.predefined_collections.copy()