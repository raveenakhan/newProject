"""File handling utilities."""
import os
import shutil
import tempfile
import time
from pathlib import Path
import base64
import logging
from typing import Dict, List, Tuple, Optional
from pdf2image import convert_from_path
from config.settings import get_settings

logger = logging.getLogger(__name__)


class FileHandler:
    """Handle file operations for PowerPoint processing."""
    
    def __init__(self):
        settings = get_settings()
        
        # Temporary directory for processing
        self.temp_dir = Path(tempfile.mkdtemp())
        self.input_dir = self.temp_dir / "input"
        self.output_dir = self.temp_dir / "output"
        self.input_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)
        
        # ADDED: Permanent storage for uploaded files
        self.storage_dir = Path(settings.data_dir) / "uploaded_files"
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Temporary directory: {self.temp_dir}")
        logger.info(f"Permanent storage: {self.storage_dir}")
    
    def save_uploaded_file(self, temp_file_path: str, file_name: str) -> str:
        """
        Save uploaded file to permanent storage.
        
        Args:
            temp_file_path: Temporary file path from Gradio
            file_name: Original filename
            
        Returns:
            Path to saved file in permanent storage
        """
        try:
            saved_path = self.storage_dir / file_name
            
            # If file already exists, skip copying
            if saved_path.exists():
                logger.info(f"File already exists in storage: {saved_path}")
                return str(saved_path)
            
            # Copy file to permanent storage
            shutil.copy2(temp_file_path, saved_path)
            
            logger.info(f"Saved file to permanent storage: {saved_path}")
            return str(saved_path)
            
        except Exception as e:
            logger.error(f"Error saving file {file_name}: {e}")
            raise
    
    def get_stored_file_path(self, file_name: str) -> Optional[str]:
        """
        Get path to a previously uploaded file.
        
        Args:
            file_name: Name of the file
            
        Returns:
            Full path to file in permanent storage, or None if not found
        """
        file_path = self.storage_dir / file_name
        
        if file_path.exists():
            logger.debug(f"Found stored file: {file_path}")
            return str(file_path)
        
        logger.warning(f"File not found in storage: {file_name}")
        return None
    
    def convert_ppt_to_images(self, pptx_file_path: str) -> Tuple[bool, str, List[str]]:
        """Convert PowerPoint file to images."""
        try:
            # Clear previous outputs
            if self.output_dir.exists():
                shutil.rmtree(self.output_dir)
            self.output_dir.mkdir(exist_ok=True)
            
            pptx_path = Path(pptx_file_path)
            
            if not pptx_path.is_file():
                return False, f"Error: PPTX file '{pptx_path}' not found.", []
            
            # Convert PPTX to PDF using LibreOffice
            pdf_file_path = self.output_dir / (pptx_path.stem + ".pdf")
            convert_command = f'soffice --headless --convert-to pdf "{pptx_path}" --outdir "{self.output_dir}"'
            
            result = os.system(convert_command)
            if result != 0:
                return False, "Error: Failed to convert PPTX to PDF. Make sure LibreOffice is installed.", []
            
            # Wait for file creation
            time.sleep(2)
            
            if not pdf_file_path.is_file():
                return False, "Error: PDF file could not be created.", []
            
            # Convert PDF to PNG images using pdftoppm
            pdftoppm_command = f'pdftoppm -png "{pdf_file_path}" "{self.output_dir}/slide"'
            result = os.system(pdftoppm_command)
            
            if result != 0:
                return False, "Error: Failed to convert PDF to images. Make sure pdftoppm (poppler-utils) is installed.", []
            
            # Rename slide files to consistent format
            slide_files = sorted(self.output_dir.glob("slide-*.png"))
            renamed_files = []
            
            for i, slide_file in enumerate(slide_files, start=0):
                new_name = self.output_dir / f"slide_{i}.png"
                slide_file.rename(new_name)
                renamed_files.append(str(new_name))
            
            if not renamed_files:
                return False, "Error: No slide images were generated.", []
            
            logger.info(f"Successfully converted {len(renamed_files)} slides to images")
            return True, f"Successfully converted {len(renamed_files)} slides to images.", renamed_files
            
        except Exception as e:
            logger.error(f"Error during PPTX conversion: {e}")
            return False, f"Error during conversion: {str(e)}", []
    
    def convert_pdf_to_images(self, pdf_path: str) -> Tuple[bool, str, List[str]]:
        """Convert PDF to images using pdf2image library.
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            Tuple of (success: bool, message: str, image_paths: List[str])
        """
        try:
            # Validate input
            if not os.path.exists(pdf_path):
                return False, f"PDF file not found: {pdf_path}", []
            
            # Create output directory
            output_dir = Path(self.temp_dir) / f"pdf_images_{int(time.time())}"
            output_dir.mkdir(exist_ok=True)
            
            # Convert PDF to images
            # Adjust DPI based on your needs (150 is good balance of quality/size)
            images = convert_from_path(pdf_path, dpi=150)
            
            if not images:
                return False, "No pages found in PDF", []
            
            image_paths = []
            for i, image in enumerate(images, 1):
                # CHANGED: Use slide_X.png format for consistency with PPTX
                image_path = output_dir / f"slide_{i-1}.png"
                image.save(image_path, 'PNG')
                image_paths.append(str(image_path))
            
            logger.info(f"Successfully converted {len(images)} PDF pages to images")
            return True, f"Successfully converted {len(images)} pages", image_paths
            
        except ImportError:
            return False, "pdf2image library not installed. Please install: pip install pdf2image", []
        except Exception as e:
            logger.error(f"Error converting PDF: {e}")
            return False, f"Error converting PDF: {str(e)}", []

    def convert_images_to_base64(self, image_paths: List[str]) -> Dict[str, str]:
        """Convert images to base64 strings."""
        base64_images = {}
        
        for image_path in image_paths:
            try:
                with open(image_path, "rb") as image_file:
                    base64_encoded = base64.b64encode(image_file.read()).decode('utf-8')
                    filename = Path(image_path).name
                    base64_images[filename] = base64_encoded
            except Exception as e:
                logger.error(f"Error converting {image_path} to base64: {e}")
                
        logger.debug(f"Converted {len(base64_images)} images to base64")
        return base64_images
    
    def cleanup(self):
        """Clean up temporary directories."""
        if self.temp_dir and self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            logger.info("Temporary directories cleaned up")