"""Authentication utilities for Watson X."""
import requests
from typing import Dict, Any
import logging, time

logger = logging.getLogger(__name__)


class WatsonXAuth:
    """Handle Watson X authentication."""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.token_url = "https://iam.cloud.ibm.com/identity/token"
        self._token: str = ""
        self._token_expiry_time: float = 0

    
    def get_bearer_token(self) -> str:
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }
        data = {
            "apikey": self.api_key,
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
        }
        try:
            response = requests.post(self.token_url, headers=headers, data=data)
            response.raise_for_status()
            resp_json = response.json()
            self._token = resp_json["access_token"]
            self._token_expiry_time = time.time() + resp_json.get("expires_in", 3600)  # expires_in in seconds
            return self._token
        except Exception as e:
            logger.error(f"Failed to get bearer token: {e}")
            raise Exception(f"Failed to get bearer token: {str(e)}")

    
    def get_auth_headers(self) -> Dict[str, str]:
        if not self._token or time.time() > self._token_expiry_time:
            self.get_bearer_token()
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._token}",
        }