import json
import shutil
from pathlib import Path
from typing import Dict, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class ImageCacheManager:
    """
    Manages cached base64 images for presentations.
    Stores images on disk to avoid repeated conversions.
    """
    
    def __init__(self, cache_dir: str):
        """
        Initialize image cache manager.
        
        Args:
            cache_dir: Directory to store cached images
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self.metadata = self._load_metadata()
        logger.info(
            f"ImageCacheManager initialized with cache dir: {self.cache_dir}")
    
    def _load_metadata(self) -> Dict:
        """Load cache metadata from disk."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading cache metadata: {e}")
                return {}
        return {}
    
    def _save_metadata(self):
        """Save cache metadata to disk."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving cache metadata: {e}")
    
    def _get_cache_path(self, file_name: str) -> Path:
        """Get cache directory path for a specific file."""
        # Sanitize filename for safe directory name
        safe_name = "".join(c for c in file_name if c.isalnum() or c in ('_', '-', '.'))
        return self.cache_dir / safe_name
    
    def is_cached(self, file_name: str) -> bool:
        """Check if images for a file are cached."""
        cache_path = self._get_cache_path(file_name)
        return cache_path.exists() and file_name in self.metadata
    
    def save_images(self, file_name: str, base64_images: Dict[str, str], 
                   file_path: str) -> bool:
        """
        Save base64 images to cache.
        
        Args:
            file_name: Name of the presentation file
            base64_images: Dict mapping slide_name to base64 image
            file_path: Original file path
            
        Returns:
            True if successful, False otherwise
        """
        try:
            cache_path = self._get_cache_path(file_name)
            cache_path.mkdir(parents=True, exist_ok=True)
            
            # Save each image as a separate JSON file
            for slide_name, base64_data in base64_images.items():
                image_file = cache_path / f"{slide_name}.json"
                with open(image_file, 'w') as f:
                    json.dump({"base64": base64_data}, f)
            
            # Update metadata
            self.metadata[file_name] = {
                "file_path": file_path,
                "num_slides": len(base64_images),
                "cached_at": datetime.now().isoformat(),
                "cache_path": str(cache_path)
            }
            self._save_metadata()
            
            logger.info(f"Cached {len(base64_images)} images for {file_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving images to cache for {file_name}: {e}")
            return False
    
    def load_images(self, file_name: str) -> Optional[Dict[str, str]]:
        """
        Load cached images for a file.
        
        Args:
            file_name: Name of the presentation file
            
        Returns:
            Dict mapping slide_name to base64 image, or None if not cached
        """
        try:
            if not self.is_cached(file_name):
                logger.info(f"No cache found for {file_name}")
                return None
            
            cache_path = self._get_cache_path(file_name)
            base64_images = {}
            
            # Load all image files
            for image_file in cache_path.glob("*.json"):
                slide_name = image_file.stem
                with open(image_file, 'r') as f:
                    data = json.load(f)
                    base64_images[slide_name] = data["base64"]
            
            logger.info(f"Loaded {len(base64_images)} cached images for {file_name}")
            return base64_images
            
        except Exception as e:
            logger.error(f"Error loading cached images for {file_name}: {e}")
            return None
    
    def delete_cache(self, file_name: str) -> bool:
        """
        Delete cached images for a specific file.
        
        Args:
            file_name: Name of the presentation file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            cache_path = self._get_cache_path(file_name)
            if cache_path.exists():
                shutil.rmtree(cache_path)
            
            if file_name in self.metadata:
                del self.metadata[file_name]
                self._save_metadata()
            
            logger.info(f"Deleted cache for {file_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error deleting cache for {file_name}: {e}")
            return False
    
    def clear_all(self) -> bool:
        """Clear entire image cache."""
        try:
            if self.cache_dir.exists():
                shutil.rmtree(self.cache_dir)
                self.cache_dir.mkdir(parents=True, exist_ok=True)
            
            self.metadata = {}
            self._save_metadata()
            
            logger.info("Cleared entire image cache")
            return True
            
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
            return False
    
    def get_cache_info(self) -> Dict:
        """Get information about cached files."""
        return {
            "total_files": len(self.metadata),
            "cache_dir": str(self.cache_dir),
            "files": self.metadata
        }