"""Slide retrieval module."""
from typing import List, Dict, Any
from ..embeddings.embedder import EmbeddingGenerator
from ..knowledge_base.vector_store import MilvusVectorStore
from config.settings import get_settings
from src.utils.logger import setup_logger
from ..knowledge_base.tokenizer import HybridJapaneseEnglishTokenizer as Tokenizer
from pathlib import Path

# Setup logger
settings = get_settings()
log_file = Path(settings.logs_dir) / "app.log"
logger = setup_logger(__name__, settings.log_level, log_file)


class SlideRetriever:
    """Retrieve relevant slides for queries."""
    
    def __init__(self, vector_store: MilvusVectorStore, embedder: EmbeddingGenerator):
        self.vector_store = vector_store
        self.embedder = embedder
        self.tokenizer = Tokenizer()
        self.settings = get_settings()
    
    def retrieve_relevant_slides(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Retrieve slides relevant to the query."""
        try:
            # Generate query embedding
            query_embedding = self.embedder.encode_single(query, normalize=True)
            tokenized_query = self.tokenizer.tokenize(combined_query)

            # Search in vector store
            relevant_slides = self.vector_store.search_in_collection(
                query_embedding=query_embedding, tokenized_query=tokenized_query, top_k=top_k)
            
            logger.info(f"Retrieved {len(relevant_slides)} relevant slides for query")
            return relevant_slides
            
        except Exception as e:
            logger.error(f"Error retrieving relevant slides: {e}")
            return []