"""Retrieval modules."""
from .retriever import SlideRetriever

__all__ = ["SlideRetriever"]