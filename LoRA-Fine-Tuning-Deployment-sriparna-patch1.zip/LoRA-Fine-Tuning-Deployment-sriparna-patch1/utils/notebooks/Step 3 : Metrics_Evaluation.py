import pandas as pd
from sklearn.metrics import (
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    average_precision_score,
    roc_auc_score
)


def calculate_metrics_from_file(file_path):
    # Read CSV or Excel dynamically
    if file_path.endswith(".csv"):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)

    # Filter rows that have valid binary classification results
    df_valid = df[df['Result'].isin(['Yes', 'No']) & df['Output'].isin(['Yes', 'No'])]

    y_true = (df_valid['Result'] == 'Yes').astype(int)
    y_pred = (df_valid['Output'] == 'Yes').astype(int)

    
    cm = confusion_matrix(y_true, y_pred)
    TN, FP, FN, TP = cm.ravel()

    # Core metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    specificity = TN / (TN + FP) if (TN + FP) > 0 else 0.0
    mcc = matthews_corrcoef(y_true, y_pred)
    auc_roc_estimated = (recall + specificity) / 2

    # Optional metrics from probabilities
    pr_auc = None
    roc_auc = None
    if 'Output_Prob' in df_valid.columns:
        try:
            y_prob = df_valid['Output_Prob'].astype(float)
            pr_auc = average_precision_score(y_true, y_prob)
            roc_auc = roc_auc_score(y_true, y_prob)
        except Exception as e:
            print(f"Error calculating PR/ROC AUC: {e}")

    # Print all metrics
    print("Confusion Matrix:")
    print(f"TN: {TN}, FP: {FP}")
    print(f"FN: {FN}, TP: {TP}\n")

    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall (Sensitivity): {recall:.4f}")
    print(f"Specificity: {specificity:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"Matthews Correlation Coefficient (MCC): {mcc:.4f}")
    print(f"Estimated AUC-ROC (using Recall + Specificity / 2): {auc_roc_estimated:.4f}")

    if pr_auc is not None and roc_auc is not None:
        print(f"PR AUC (Precision-Recall): {pr_auc:.4f}")
        print(f"ROC AUC: {roc_auc:.4f}")


if __name__ == "__main__":
    file_path = "Metrics for Base Model vs Lora fine tuned models.csv"
    calculate_metrics_from_file(file_path)
