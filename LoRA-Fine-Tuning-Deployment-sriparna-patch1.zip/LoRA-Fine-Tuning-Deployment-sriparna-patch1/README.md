# 🔬 TDE-LIFE: LoRA Fine-Tuning & Classification Pipeline

This repository provides a complete pipeline for fine-tuning foundation models using **LoRA (Low-Rank Adaptation)** and evaluating their performance on a phrase-based classification task. The workflow supports training, inference, and metrics evaluation on structured JSON datasets.

---

## 🧠 Project Overview

The project is divided into three major steps, each implemented via a separate notebook/script:

1. **LoRA Fine Tuning & Deployment**
2. **Testing & Classification**
3. **Metrics Evaluation**

---

## 📁 Folder Structure

```
TDE-LIFE/
├── data/                          # JSON files for training and testing
│   ├── training_data_with_phrases (2).json
│   ├── training_data_split_train.json
│   ├── training_data_split_test (2).json
│   └── training_data_balanced_with_phrases (1).json

├── utils/notebooks/              # All core logic for the pipeline
│   ├── Step 1 : LoRA Fine Tuning & Deployment.ipynb
│   ├── Step 2 : Testing & Classification.ipynb
│   └── Step 3 : Metrics Evaluation.py

├── README.md                     # Project documentation
├── .gitignore
└── requirements.txt              # Python dependencies
```

---

## 📘 Notebook/Script Descriptions

### `Step 1 : LoRA Fine Tuning & Deployment.ipynb`
- Loads a base foundation model.
- Fine-tunes the model using LoRA on instruction-style training data.
- Saves and deploys the fine-tuned model.

### `Step 2 : Testing & Classification.ipynb`
- Loads test dataset.
- Performs inference using the deployed LoRA model.
- Saves predictions for later evaluation.

### `Step 3 : Metrics Evaluation.py`
- Reads test labels and model outputs.
- Computes classification metrics:
  - Accuracy
  - Precision, Recall, Specificity
  - F1 Score
  - Matthews Correlation Coefficient (MCC)
  - PR AUC, ROC AUC (if probabilities available)
- Displays confusion matrix and all evaluation metrics.

---

## 📊 Datasets (`data/`)

- Each file is a JSON containing instructions, inputs, and expected outputs.
- `training_data_with_phrases.json` — Raw dataset with unbalanced phrases.
- `training_data_balanced_with_phrases (1).json` — Pre-processed and balanced.
- `training_data_split_train.json` and `training_data_split_test.json` — Used for training and evaluation respectively.

---

## ⚙️ Installation

```bash
pip install -r requirements.txt
```

Ensure your environment also includes:
- `transformers`
- `scikit-learn`
- `pandas`, `numpy`, `matplotlib`

---

## 🚀 Running the Pipeline

1. **Prepare & Fine-Tune**
   ```bash
   Open utils/notebooks/Step 1 : LoRA Fine Tuning & Deployment.ipynb
   ```

2. **Run Inference**
   ```bash
   Open utils/notebooks/Step 2 : Testing & Classification.ipynb
   ```

3. **Evaluate Results**
   ```bash
   Run utils/notebooks/Step 3 : Metrics Evaluation.py
   ```

---

## 🧪 Notes

- Designed for IBM Granite or other foundation models compatible with LoRA adapters.
- All notebooks assume instruction-style training format (`instruction`, `input`, `output`).
- Metrics script dynamically adjusts if probability column (`Output_Prob`) is present.

---

## 👥 Contributors

- Sriparna Banerjee (bsriparna@ibm.com) & Rakesh Lingubari (rakesh.lingubari@ibm.com)

