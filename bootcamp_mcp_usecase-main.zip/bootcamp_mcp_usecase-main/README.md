# MCP Server Integration with Watsonx Orchestrate

This project demonstrates the integration of **Model Context Protocol (MCP)** with **watsonx Orchestrate Agents**, enabling seamless interaction between users, orchestrator agents, and external tools such as Google Reviews, Google Flights, and Google Finance.

## Table of Contents
- [Architecture Overview](#architecture-overview)
  - [Workflow](#workflow)
- [Project Directory](#project-directory)
- [Getting Started](#getting-started)
  - [Clone Repository](#1-clone-repository)
  - [Create Virtual Environment](#2-create-virtual-environment)
  - [Create env file](#3-create-env-file)
  - [Setup Environment](#4-setup-environment)
- [Use Cases](#use-cases)
- [Run tools in MCP Inspector](#run-tools-in-mcp-inspector)
  - [MCP Inspector Guide](#mcp-inspector-guide)
- [Integrate with Watsonx Orchestrate](#integrate-with-watsonx-orchestrate)
- [Support](#support)

## Architecture Overview

The following diagram illustrates the high-level architecture of the integration:

![Architecture Diagram](./assets/bootcamp_mcp_usecase.png)

### Workflow:

1. **User Query** → The user sends a query via the interface.
2. **Orchestrator Agent (watsonx Orchestrate)** → The query is routed to an orchestrator agent.
3. **Model Context Protocol (MCP)** → The orchestrator agent communicates with the MCP server to invoke tool calls.
4. **External Tools Integration** →
   - Google Reviews
   - Google Flights
   - Google Finance
5. **Tool Response** → Results from the tools are sent back via MCP to the orchestrator agent.
6. **Final Response** → The orchestrator agent processes the tool responses and sends a final response back to the user.

This architecture ensures scalable and modular integration of AI-powered agents with multiple data sources through MCP.

## Project Directory

Click to expand the Project Directory
<details>

```plaintext

bootcamp_mcp_usecase/
│   ├── env_copy
│   ├── README.md
│   ├── tools/
│   │   ├── requirements.txt
│   │   ├── mcp_tools.py
│   │   ├── utils/
│   │   │   ├── google_flights_utils.py
│   │   │   ├── google_finance_utils.py
│   │   │   ├── __init__.py
│   ├── agents/
│   │   ├── master_agent.yaml
│   ├── assets/
│   │   ├── bootcamp_mcp_usecase.png
│   │   ├── mcp_guide/
│   │   │   ├── MCP_Step2.png
│   │   │   ├── MCP_Step3.png
│   │   │   ├── MCP_Step1.png
│   │   │   ├── MCP_Step4.png
│   │   │   ├── MCP_Step5.png
│   │   │   ├── MCP_Step7.png
│   │   │   ├── MCP_Step6.png
```
</details>

## Getting Started

### 1. Clone Repository

```bash
git clone <repository_url>
cd bootcamp_mcp_usecase
```

### 2. Create Virtual Environment

```bash
pipenv shell
```

OR

```bash
python -m venv <your virtual environment name>
```

### 3. Create .env file
Copy the provided env_copy file into a new .env file and update it with your credentials:

```bash
cp env_copy .env
```

### 4. Setup Environment

```bash
pip install -r tools/requirements.txt
```

## Use Cases

1. **Travel Planning** → Query flight details via Google Flights.
2. **Financial Insights** → Retrieve real-time finance data using Google Finance.
3. **Customer Feedback** → Fetch and analyze Google Reviews.

## Run tools in MCP Inspector

You can test and debug your MCP tools using MCP Inspector with FastMCP:

```uv
uv run mcp dev mcp_tools.py
```

### MCP Inspector Guide

**Step 1: Setup Connection**
- Set the following in the MCP Inspector UI:
   * Transport Type: STDIO
   * Command: uv
   * Arguments: run --with mcp mcp run mcp_tools.py
   
   <image src="./assets/mcp_guide/MCP_Step1.png" width=1000/> <br>

- Add the Serp API In Environment Variables:
   * Click on `Environment Variables` to expand it

   <image src="./assets/mcp_guide/MCP_Step2.png" width=1000/>

   * Click on `Add Environment Variable`
   * Add variable name `SERP_API_KEY`
   * Add the API Key value

   <image src="./assets/mcp_guide/MCP_Step3.png" width=1000/> <br>

- Click Connect. A green dot indicates successful connection. <br><br>

**Step 2: List Available Tools**
- Go to the Tools tab
- Click List Tools

   <image src="./assets/mcp_guide/MCP_Step4.png" width=1000/>

- List of available tools will appear.

   <image src="./assets/mcp_guide/MCP_Step5.png" width=1000/> <br><br>

**Step 3: Run a Tool**
- Choose a tool (e.g., google_flights)
- Provide input:

```json
   {
      departure_airport: "IATA Code of the airport departuring from"
      arrival_airport: "IATA Code of the airport arriving to"
      departure_date: "Date of Travel in YYYY-MM-DD format"
   }
   ```

   <image src="./assets/mcp_guide/MCP_Step6.png" width=1000/>

- Click Run Tool (Scroll down a bit if the button is not visible)

   <image src="./assets/mcp_guide/MCP_Step7.png" width=1000/><br><br>

**Additional Notes**
- Use Restart or Disconnect on the sidebar as needed
- Errors will appear in the Error output from MCP server section
- Tabs like Prompts, Sampling, Roots, and Auth allow advanced configuration


## Integrate with Watsonx Orchestrate
1. **Start the orchestrate server**

   ```bash
   orchestrate server start --env-file=.env
   ```

2. **Activate local environment**

   ```bash
   orchestrate env activate local
   ```

3. **Add SerpAPI In local environment**
   ```bash
   orchestrate connections add -a serp_api_connection
   ```

   ```bash
   orchestrate connections configure -a serp_api_connection --env draft --kind key_value --type team
   ```

   ```bash
   orchestrate connections set-credentials -a serp_api_connection --env draft -e SERP_API_KEY=<your serp api key>
   ```
   Note: In the above command, Replace placeholder api key value with your Serp API Key value

4. **Import MCP tool**

   ```bash
   orchestrate toolkits import \
   --kind mcp \
   --name utility_tools \
   --description "MCP server to get the Google Flights" \
   --package-root "tools/" \
   --language python \
   --command '["python", "mcp_tools.py"]' \
   --tools "*" \
   --app-id serp_api_connection
   ```

5. **Agent Import**

   Import the agent using:

   ```bash
   orchestrate agents import -f agents/master_agent.yaml
   ```

6. **Chat Interface**

   Start the interactive chat:

   ```bash
   orchestrate chat start
   ```

## Support

For official documentation and troubleshooting, visit the
👉 [Watsonx Orchestrate ADK GitHub Repository](https://github.com/IBM/ibm-watsonx-orchestrate-adk)

