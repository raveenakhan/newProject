from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
from utils.milvus import milvus_db

import pandas as pd


@tool(name="get_recent_changes", description="Get recent changes done to the machine", permission=ToolPermission.ADMIN)
def get_recent_changes(machine_id: str) -> pd.DataFrame:
    """
    Fetches the most recent changes or incidents related to a given machine ID.

    Args:
        machine_id (str): Unique identifier for the machine.

    Returns:
        pd.DataFrame: A DataFrame containing the top recent incident records 
                      for the specified machine, sorted by timestamp.

    Raises:
        Exception: If there is an error during the Milvus query process.
    """
    try:
        milvus_db_obj = milvus_db()
        recent_changes_df = milvus_db_obj.recent_changes_to_machine_search(machine_id)
        return recent_changes_df
    except Exception as e:
        raise e