
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
from utils.milvus import milvus_db

import pandas as pd


@tool(
    name="get_past_similar_incidents",
    description="Get top 5 past similar incidents based on the error code, machine id & incident description",
    permission=ToolPermission.ADMIN
)
def get_past_similar_incidents(error_code: str, machine_id: str, query: str) -> pd.DataFrame:
    """
    Searches for the top 5 past incidents that are semantically similar to a given incident description,
    filtered by machine ID and error code.

    Args:
        error_code (str): The error code associated with the incident.
        machine_id (str): The unique identifier of the machine involved.
        query (str): A natural language description of the current incident.

    Returns:
        pd.DataFrame: A DataFrame containing similar past incidents along with similarity scores.

    Raises:
        Exception: If the search operation fails or encounters an error.
    """
    try:
        milvus_db_obj = milvus_db()
        similar_incidents_df = milvus_db_obj.past_similar_incidents_search(query, machine_id, error_code)
        return similar_incidents_df
    except Exception as e:
        raise e


