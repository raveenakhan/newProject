from milvus import milvus_db
from config import (
    NEW_LOG_ROWS, BASE_LOG_FILE_PATH, INCIDENT_LOG_FILE_PATH,
    RUN_MODE)
from helper import helper
import os
import shutil


def main():
    """
    Entry point for Code Engine job mode.

    This script runs once per execution to 
    generate new incident log entries using Watsonx,
    appends them to the existing incident CSV file,
    and updates the Milvus collection.
    """
    try:
        print("Initializing Milvus DB and helper...")
        helper_obj = helper()
        helper_obj.fetch_presto_cert()

        # Ensure the incident log exists (copy base version if not)
        if RUN_MODE == "job":
            try:
                # Download latest log file from cos to temp folder
                print(f"Downlading latest log file at {INCIDENT_LOG_FILE_PATH}")
                helper_obj.download_log_file(INCIDENT_LOG_FILE_PATH)

                # Also update the base log file
                print(f"Updating master CSV: {INCIDENT_LOG_FILE_PATH} → {BASE_LOG_FILE_PATH}")
                shutil.copy(INCIDENT_LOG_FILE_PATH, BASE_LOG_FILE_PATH)
                print(f"Base log copied to {INCIDENT_LOG_FILE_PATH}")
            except Exception as e:
                raise RuntimeError(f"Failed to copy base log file: {e}")
        
        milvus_db_obj = milvus_db()
        print("Generating and inserting new incident logs...")
        milvus_db_obj.generate_and_insert_new_logs(INCIDENT_LOG_FILE_PATH)
        
        # Copy the updated temp file back into your document folder
        print(f"Updating master CSV: {INCIDENT_LOG_FILE_PATH} → {BASE_LOG_FILE_PATH}")
        shutil.copy(INCIDENT_LOG_FILE_PATH, BASE_LOG_FILE_PATH)
        
        print(f"Job completed: {NEW_LOG_ROWS} new incident(s) generated and ingested successfully.")
    except Exception as e:
        print(f"Job failed: {str(e)}")


if __name__ == "__main__":
    main()
