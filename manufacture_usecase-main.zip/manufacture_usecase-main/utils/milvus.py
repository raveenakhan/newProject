from pymilvus import Collection, CollectionSchema, utility, FieldSchema, DataType
from ibm_watsonx_ai.foundation_models import ModelInference

from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv
import pandas as pd
import random, json, ast
from datetime import datetime
from config import (
    connect_to_milvus,
    WATSONX_API_KEY,
    WATSONX_PROJECT_ID,
    WATSONX_URL,
    WATSONX_LLM_MODEL,
    EMBEDDING_MODEL_DIMENSION,
    EMBEDDING_MODEL_NAME,
    COLLECTION_NAME,
    TOP_K_PAST_SIMILAR_INCIDENTS,
    TOP_K_MOST_RECENT_INCIDENTS,
    COS_LOG_FILE_KEY,
    NEW_LOG_ROWS
    )

from utils.helper import helper


load_dotenv()

class milvus_db:
    """
    Class to interact with Milvus vector database for incident log storage and search.
    """

    def __init__(self) -> None:
        """
        Initializes the embedding model and sets vector dimension and collection name.
        """
        self.embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
        self.vector_dim = EMBEDDING_MODEL_DIMENSION
        self.collection_name = COLLECTION_NAME
        self.helper_obj = helper()

    def create_collection(self):
        """
        Creates a Milvus collection for incident logs with specified schema.
        Drops the existing collection if it already exists.
        """
        try:
            connect_to_milvus()
            print("Dropping exisitng collection...")
            if utility.has_collection(self.collection_name):
                utility.drop_collection(self.collection_name)

            fields = [
                FieldSchema(name="id",
                            dtype=DataType.INT64,
                            is_primary=True, auto_id=True),
                FieldSchema(name="date",
                            dtype=DataType.VARCHAR, max_length=20),
                FieldSchema(name="time",
                            dtype=DataType.VARCHAR, max_length=20),
                FieldSchema(name="name",
                            dtype=DataType.VARCHAR, max_length=100),
                FieldSchema(name="line",
                            dtype=DataType.VARCHAR, max_length=50),
                FieldSchema(name="machineid",
                            dtype=DataType.VARCHAR, max_length=50),
                FieldSchema(name="machine_type",
                            dtype=DataType.VARCHAR, max_length=100),
                FieldSchema(name="error_code",
                            dtype=DataType.VARCHAR, max_length=50),
                FieldSchema(name="symptoms",
                            dtype=DataType.VARCHAR, max_length=300),
                FieldSchema(name="cause",
                            dtype=DataType.VARCHAR, max_length=500),
                FieldSchema(name="measure",
                            dtype=DataType.VARCHAR, max_length=300),
                FieldSchema(name="vector",
                            dtype=DataType.FLOAT_VECTOR, dim=self.vector_dim),
            ]

            schema = CollectionSchema(fields, description="Incident log with embeddings")
            collection = Collection(name=self.collection_name, schema=schema)

            index_params = {
                "metric_type": "COSINE",
                "index_type": "IVF_FLAT",
                "params": {"nlist": 256},
            }
            collection.create_index(field_name="vector", index_params=index_params)
            print(f"Collection '{self.collection_name}' created successfully")
        except Exception as e:
            print(f"Error creating collection: {e}")    
            raise e

    def ingest_incident_log(self, csv_path: str):
        """
        Ingests a CSV file of incident logs into the Milvus collection after vectorizing the 'cause' column.

        Args:
            csv_path (str): Path to the incident CSV file.
        """
        try:
            connect_to_milvus()
            df = pd.read_csv(csv_path).fillna("")
            df["cause"] = df["cause"].astype(str)
            vectors = self.embedding_model.encode(df["cause"].tolist(), show_progress_bar=True, normalize_embeddings=True)

            collection = Collection(self.collection_name)
            data = [
                df["date"].astype(str).str.lower().tolist(),
                df["time"].astype(str).str.lower().tolist(),
                df["name"].astype(str).str.lower().tolist(),
                df["line"].astype(str).str.lower().tolist(),
                df["machineid"].astype(str).tolist(),
                df["machine_type"].astype(str).str.lower().tolist(),
                df["error_code"].astype(str).tolist(),
                df["symptoms"].astype(str).str.lower().tolist(),
                df["cause"].astype(str).str.lower().tolist(),
                df["measure"].astype(str).str.lower().tolist(),
                vectors.tolist(),
            ]

            collection.insert(data) 
            collection.flush()
            # collection.load()
            print(f"Ingested {len(df)} rows into '{self.collection_name}'.")
        except Exception as e:
            print(f"Error while ingesting incident log: {e}")
            raise RuntimeError(f"Failed to ingest data into Milvus: {e}")

    def past_similar_incidents_search(self,query_text: str = None,machine_type: str = None,error_code: str = None):
        """
        Searches for past incidents either by cosine similarity (on query_text) or
        by exact match filtering (if machine_type or error_code are provided).

        Args:
            query_text (str, optional): Free-text issue description to search by.
            machine_type (str, optional): Machine type to filter by.
            error_code (str, optional): Error code to filter by.

        Returns:
            pd.DataFrame: Matching incident logs, with similarity scores if applicable.
        """
        try:
            connect_to_milvus()
            collection = Collection(self.collection_name)
            collection.load()

            expr_clauses = []
            if machine_type:
                expr_clauses.append(f'machine_type == "{machine_type.lower()}"')
            if error_code:
                expr_clauses.append(f'error_code == "{error_code}"')
            expr = " and ".join(expr_clauses) if expr_clauses else ""

            # Case 1: Filter-only query (no similarity search)
            if expr and not query_text:
                results = collection.query(expr=expr, output_fields=[
                    "machineid", "machine_type", "error_code", "cause",
                    "symptoms", "measure", "date", "time"
                ])
                return pd.DataFrame(results).head(TOP_K_PAST_SIMILAR_INCIDENTS)

            # Case 2: Similarity-based search (with optional filter)
            vector = self.embedding_model.encode([query_text.lower()], normalize_embeddings=True)
            search_params = {
                "metric_type": "COSINE",
                "params": {"nprobe": 32}
            }

            results = collection.search(
                data=vector,
                anns_field="vector",
                param=search_params,
                limit=TOP_K_PAST_SIMILAR_INCIDENTS,
                expr=expr,
                output_fields=[
                    "machineid", "machine_type", "error_code", "cause",
                    "symptoms", "measure", "date", "time"
                ]
            )
            print(results)

            all_hits = []
            for hits in results:
                for hit in hits:
                    record = hit.entity.to_dict()
                    record["similarity_score"] = hit.distance
                    all_hits.append(record)

            return pd.DataFrame(all_hits)
        except Exception as e:
            print(f"Error during search: {e}")
            return pd.DataFrame()



    def recent_changes_to_machine_search(self, machine_id: str):
        """
        Retrieves the most recent incidents for a given machine ID, sorted by date and time.

        Args:
            machine_id (str): Machine identifier for which recent changes are to be retrieved.

        Returns:
            pd.DataFrame: A DataFrame of recent incident entries, sorted by date and time descending.
        """
        try:
            connect_to_milvus()
            collection = Collection(self.collection_name)
            collection.load()

            # Query only relevant fields for the given machine_id
            expr = f'machineid == "{machine_id}"'
            results = collection.query(
                expr=expr,
                output_fields=[
                    "machineid", "machine_type", "error_code", "cause",
                    "symptoms", "measure", "date", "time"
                ]
            )

            if not results:
                return pd.DataFrame()

            df = pd.DataFrame(results)

            # Sort lexicographically using date and time (they are in sortable format)
            df = df.sort_values(by=["date", "time"], ascending=[False, False])

            return df.head(TOP_K_MOST_RECENT_INCIDENTS)

        except Exception as e:
            print(f"Error fetching most recent machine log: {e}")
            return pd.DataFrame()


    def generate_and_insert_new_logs(self, csv_path: str):
        """
        Generates synthetic manufacturing incident logs using Watsonx.ai,
        appends date/time/name, updates the local incident log CSV, and
        inserts the updated log into the Milvus collection.

        Returns:
            list: Newly generated log entries as a list of dictionaries.
        """
        try:
            
            context = self.helper_obj.extract_sampled_incident_context()

            prompt = f"""You are a Japanese machine operator working on a smart factory production line.

                        Generate {NEW_LOG_ROWS} realistic manufacturing incident log entry. Each entry must include:
                        - machineid, machine_type, line, error_code, symptoms, cause, measure

                        Use the following references:

                        1. Example Logs:
                        {context['sampled_logs'].to_dict(orient='records')}

                        2. Machine Information:
                        {context['mapped_machines'][['MachineID', 'MachineType', 'ProductionLine', 'Description', 'MaintenanceLevel', 'OperationalComplexity']].to_dict(orient='records')}

                        3. Error Code Info:
                        {context['selected_error_codes'][['ErrorID', 'Description', 'Severity', 'Category', 'TypicalCause', 'AffectedMachineTypes']].to_dict(orient='records')}

                        Respond ONLY in plain English using standard ASCII characters. 
                        DO NOT include emojis, non-English characters, or formatting symbols. 
                        Strictly respond with the following format and nothing else:
                            [
                            {{
                                "date": "YYYY-MM-DD",
                                "time": "HH:MM",
                                "name": "Japanese Operator Name",
                                "line": LINE,
                                "machineid": "MXXX",
                                "machine_type": "MachineType",
                                "error_code": "EXXX",
                                "symptoms": "Symptom description",
                                "cause": "ErrorCode: Cause description",
                                "measure": "Remedial action"
                            }}
                            ]
                        Do NOT add any explanation, prefix, suffix, formatting, or markdown. Only return a valid Python list of dicts.
                        """
            
            model = ModelInference(
                model_id=WATSONX_LLM_MODEL,
                params={"decoding_method": "sample", "max_new_tokens": 500},
                credentials={"apikey": WATSONX_API_KEY, "url": WATSONX_URL},
                project_id=WATSONX_PROJECT_ID,
            )
            response = model.generate_text(prompt)

            print("LLM Response\n")
            print(response)
            print("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

            # Safely parse LLM response
            try:
                raw_text = response["generated_text"] if isinstance(response, dict) else str(response)
                print("Raw Watsonx response:\n", raw_text)  # <-- Add this
                logs = ast.literal_eval(raw_text.strip())
                if not isinstance(logs, list) or not all(isinstance(log, dict) for log in logs):
                    raise ValueError("LLM output is not a list of dictionaries")
            except Exception as parse_error:
                raise RuntimeError(f"Failed to parse Watsonx output: {parse_error}")

            # Add timestamp and name
            now = datetime.now()
            current_date = now.strftime("%Y-%m-%d")
            current_time = now.strftime("%H:%M")
            japanese_names = [
                "Haruto Sato", "Yuki Nakamura", "Sora Yamamoto", "Aoi Takahashi", "Ren Suzuki",
                "Kaito Tanaka", "Hinata Kobayashi", "Riku Ito", "Yuma Kondo", "Rei Fujimoto",
                "Nao Matsumoto", "Haruki Hasegawa", "Rio Nakajima", "Koharu Watanabe", "Daiki Inoue",
                "Mei Shimizu", "Shohei Ueda", "Mio Hayashi", "Kazuya Morita", "Ayaka Arai",
                "Tsubasa Ishikawa", "Yuto Nishimura", "Rina Sakamoto", "Takumi Okada", "Hina Sasaki",
                "Shun Kimura", "Saki Yamaguchi", "Ryota Kojima", "Noa Ogawa", "Misaki Takagi"
            ]

            for entry in logs:
                entry["date"] = current_date
                entry["time"] = current_time
                entry["name"] = random.choice(japanese_names)

            print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
            print("final Log entry:")
            print(logs)

            new_logs_df = pd.DataFrame(logs)

            # Maintain column order and append to CSV
            existing_df = pd.read_csv(csv_path)
            new_logs_df = new_logs_df[existing_df.columns]
            new_logs_df.to_csv(csv_path, mode="a", header=False, index=False)

            # Upload log file to COS Bucket
            print(f"Updating LOG file in COS Bucket: {csv_path} -> {COS_LOG_FILE_KEY}")
            self.helper_obj.upload_log_file(csv_path)

            # Re-ingest into Milvus
            self.create_collection()
            self.ingest_incident_log(csv_path)
            print("New synthetic log generated and inserted.")

            return logs  # Return the new row(s) added

        except Exception as e:
            raise RuntimeError(f"Failed to generate and insert new logs: {e}")

