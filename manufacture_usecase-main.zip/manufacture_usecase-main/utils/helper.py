import pandas as pd
from dotenv import load_dotenv
import ibm_boto3, os
from ibm_botocore.client import Config

from config import (
    INCIDENT_LOG_FILE_PATH,
    ERROR_CODE_FILE_PATH,
    MACHINE_CODE_FILE_PATH,
    CERT_LOCAL_PATH,
    COS_LOG_FILE_KEY
)

load_dotenv()

class helper:
    def __init__(self) -> None:
        self.credentials = {
                'WATSONX_API_KEY': os.getenv("WATSONX_API_KEY"),
                'IAM_SERVICE_ID': os.getenv("IAM_SERVICE_ID"),
                'ENDPOINT': os.getenv("ENDPOINT"),
                'IBM_AUTH_ENDPOINT': os.getenv("IBM_AUTH_ENDPOINT"),
                'BUCKET': os.getenv("BUCKET")
            }
        self.cos_client = ibm_boto3.client(
            service_name='s3',
            ibm_api_key_id=self.credentials['WATSONX_API_KEY'],
            ibm_service_instance_id=self.credentials['IAM_SERVICE_ID'],
            ibm_auth_endpoint=self.credentials['IBM_AUTH_ENDPOINT'],
            config=Config(signature_version='oauth'),
            endpoint_url=self.credentials['ENDPOINT']
        )

    def extract_sampled_incident_context(self,incident_path: str = INCIDENT_LOG_FILE_PATH,machine_path: str = MACHINE_CODE_FILE_PATH,error_path: str = ERROR_CODE_FILE_PATH,num_samples: int = 5):
        """
        Extracts a rich sample context of machines, errors, and incident logs 
        to support realistic synthetic log generation by LLMs.

        Args:
            incident_path (str): Path to the incident log CSV file.
            machine_path (str): Path to the machine codes CSV file.
            error_path (str): Path to the error codes CSV file.
            num_samples (int): Number of unique error codes to sample.

        Returns:
            dict: Dictionary containing:
                - 'selected_error_codes': DataFrame of error code samples
                - 'mapped_machines': DataFrame of machines linked to those errors
                - 'sampled_logs': Incident logs using those machine-error pairs

        Raises:
            FileNotFoundError: If any input file path is incorrect
            ValueError: If required columns are missing
            RuntimeError: If sampling fails or no matching rows are found
        """
        try:
            incident_df = pd.read_csv(incident_path)
            error_code_df = pd.read_csv(error_path)
            machine_code_df = pd.read_csv(machine_path)
        except FileNotFoundError as fe:
            raise FileNotFoundError(f"One or more files not found: {fe}")
        except Exception as e:
            raise RuntimeError(f"Failed to read input CSVs: {e}")

        # Validate required columns
        required_incident_cols = ["machineid", "error_code"]
        required_machine_cols = ["MachineID", "MachineType", "ProductionLine", "ErrorCodes"]
        required_error_cols = ["ErrorID", "Description", "Severity", "Category", "TypicalCause", "AffectedMachineTypes"]

        for col in required_incident_cols:
            if col not in incident_df.columns:
                raise ValueError(f"Missing column '{col}' in incident log.")
        for col in required_machine_cols:
            if col not in machine_code_df.columns:
                raise ValueError(f"Missing column '{col}' in machine code data.")
        for col in required_error_cols:
            if col not in error_code_df.columns:
                raise ValueError(f"Missing column '{col}' in error code data.")

        try:
            # Step 1: Select random error codes
            selected_error_codes = error_code_df.sample(n=num_samples)
            selected_error_ids = selected_error_codes["ErrorID"].tolist()

            # Step 2: Filter machines that support these error codes
            filtered_machines = machine_code_df[
                machine_code_df["ErrorCodes"].apply(lambda x: any(eid in x for eid in selected_error_ids))
            ]
            mapped_machines = filtered_machines.sample(n=min(num_samples, len(filtered_machines)))

            mapped_machine_ids = mapped_machines["MachineID"].tolist()

            # Step 3: Extract incident logs matching those machine-error pairs
            filtered_incidents = incident_df[
                (incident_df["error_code"].isin(selected_error_ids)) &
                (incident_df["machineid"].isin(mapped_machine_ids))
            ]
            sampled_logs = filtered_incidents.sample(n=min(num_samples, len(filtered_incidents)))

            return {
                "selected_error_codes": selected_error_codes,
                "mapped_machines": mapped_machines,
                "sampled_logs": sampled_logs
            }

        except Exception as e:
            raise RuntimeError(f"Sampling or filtering failed: {e}")


    def fetch_presto_cert(self):
        """
        Downloads the `presto.crt` certificate from IBM Cloud Object Storage
        to the specified local path. Raises an exception if download fails.
        """
        try:
            self.cos_client.download_file(
                Bucket=self.credentials["BUCKET"],
                Key=CERT_LOCAL_PATH,
                Filename=CERT_LOCAL_PATH
            )
            print(f"Certificate downloaded successfully to: {CERT_LOCAL_PATH}")
        except Exception as e:
            print(f"Error while downloading certificate: {e}")
            raise e

    def download_log_file(self, local_path: str):
        """
        Download the log CSV from COS into local_path, overwriting any existing file.
        """
        try:
            self.cos_client.download_file(Bucket=self.credentials["BUCKET"], Key=COS_LOG_FILE_KEY, Filename=local_path)
        except Exception as e:
            print(f"Error while downloading incident log file: {e}")
            raise e 
    
    def upload_log_file(self, local_path: str):
        """
        Upload the local CSV at local_path to COS, overwriting the existing object.
        """
        # Delete old object (optional—upload_file alone will overwrite)
        try:
            self.cos_client.delete_object(Bucket=self.credentials["BUCKET"], Key=COS_LOG_FILE_KEY)
        except Exception as e:
            print(f"Error while deleting the {COS_LOG_FILE_KEY} from the COS Bucket: {e}")
            raise e
        try:
            self.cos_client.upload_file(Filename=local_path, Bucket=self.credentials["BUCKET"], Key=COS_LOG_FILE_KEY)
        except Exception as e:
            print(f"Error while uploading the updated {COS_LOG_FILE_KEY} to the COS Bucket: {e}")
            raise e
