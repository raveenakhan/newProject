from dotenv import load_dotenv

import uvicorn
from fastapi import FastAPI, Form, Query
from typing import Optional
from fastapi.responses import JSONResponse

from utils.milvus import milvus_db
from utils.helper import helper

from config import NEW_LOG_ROWS, INCIDENT_LOG_FILE_PATH

load_dotenv()

app = FastAPI()


@app.post("/ingest")
async def ingest_data(path: str = Form(None)):
    """
    Ingests incident log data from the
    provided CSV path into Milvus collection.

    Returns HTTP 500 if ingestion fails.
    """
    try:
        milvus_db_obj = milvus_db()
        milvus_db_obj.create_collection()

        if not path:
            helper_obj = helper()
            helper_obj.download_log_file(INCIDENT_LOG_FILE_PATH)
            milvus_db_obj.ingest_incident_log(INCIDENT_LOG_FILE_PATH)
        else:
            milvus_db_obj.ingest_incident_log(path)
        return {"message": "Data ingested successfully from provided path."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/search_past_similar_incidents")
async def search_past_similar_incidents(
    query: Optional[str] = Query(None, description="Free-text description for semantic search"),
    machine_type: Optional[str] = Query(None, description="Optional machine type to filter incidents"),
    error_code: Optional[str] = Query(None, description="Optional error code to filter incidents")
):
    """
    Searches for past incidents either by similarity to a free-text query or by filtering with machine ID and error code.

    - If `machine_type` or `error_code` and no free-text query is provided, performs a filtered lookup.
    - Otherwise, performs a semantic similarity search using the query text.

    Returns:
        A list of matching incidents or a 500 error on failure.
    """
    try:
        milvus_db_obj = milvus_db()
        results = milvus_db_obj.past_similar_incidents_search(
            query_text=query, machine_type=machine_type, error_code=error_code
        )
        return results.to_dict(orient="records")
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/search_recent_changes_to_machine")
async def search_recent_changes_to_machine(machine_id: str):
    """
    Searches for the most recent changes related to the given machine ID.
    Returns top 10 incidents or HTTP 500 on error.
    """
    try:
        milvus_db_obj = milvus_db()
        results = milvus_db_obj.recent_changes_to_machine_search(machine_id)
        return results.to_dict(orient="records")
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/generate_new_incidents")
async def generate_new_incidents():
    """
    Generate new incident entries using Watsonx.ai and ingest them into Milvus.
    Also updates the incident log CSV and returns the newly added log(s).

    Returns:
        dict: Message and newly generated incident logs.
    """
    try:
        helper_obj = helper()
        helper_obj.download_log_file(INCIDENT_LOG_FILE_PATH)

        milvus_db_obj = milvus_db()
        new_logs = milvus_db_obj.generate_and_insert_new_logs(INCIDENT_LOG_FILE_PATH)
        return {
            "message": f"{NEW_LOG_ROWS} new incident(s) generated and ingested successfully.",
            "new_logs": new_logs
        }
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# Download the certificate only once at app startup
try:
    helper_obj = helper()
    helper_obj.fetch_presto_cert()
except Exception as e:
    print(f"Startup error: could not fetch certificate: {e}")

# if __name__ == "__main__":
#     uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
