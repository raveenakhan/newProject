# XYZ Motors – AI-Powered Fault Management System

XYZ Motors, a leading car manufacturer, frequently encounters delays in handling equipment malfunctions. These challenges reduce situational awareness, broaden quarantines, and prolong root-cause analysis—ultimately affecting productivity and yield.

---

## Table of Contents

* [Objective](#objective)
* [Business Value](#business-value)
* [Architecture Overview](#architecture-overview)
* [Components and Agents](#components-and-agents)
    * [Master Agent](#1-master-agent)
    * [Machine Agent](#2-machine-agent-wxo-rag)
    * [Error Agent](#3-error-agent-wxo-rag)
    * [Log Agent](#4-log-agent)
  * [User Input](#-user-input)
  * [Cumulative Output](#-cumulative-output)
* [Technologies Used](#-technologies-used)
* [Sample Use-Case Flow](#-sample-use-case-flow)
* [Benefits](#-benefits)
* [Built With](#built-with)
* [Prerequisites](#prerequisites)
  * [Machine Requirements](#machine-requirements)
* [Project Structure](#project-structure)
* [Setup Instructions](#setup-instructions)
* [Environment Configuration](#environment-configuration)
* [Run the Application](#run-the-application)
* [Support](#support)

---

## Objective

This project aims to reduce fault resolution time and improve operational efficiency by deploying cooperating AI agents that:

* Detect faults in real-time
* Provide relevant context and insights
* Predict potential yield loss
* Recommend actionable fixes
* Automatically document each incident

The solution converts hours of manual fault management into a streamlined, data-driven process.

---

## Business Value

* **Reduced Downtime**
  Faster fault isolation and guided troubleshooting shorten repair cycles.

* **Lower Scrap and Rework**
  Accurate genealogy tracking restricts containment to only the impacted batch, minimizing material waste.

* **Knowledge Retention**
  Each incident is auto-documented, preserving institutional knowledge for future reference.

---

## Architecture Overview

The system receives an input (Error Code or Incident with Machine Name) from the user and processes it using Watsonx-based agents. Each agent specializes in a specific domain and contributes to generating a comprehensive answer.

![Architecture_Diagram](assets/ManufacturesUsecase.png)

---

## Components and Agents

### 1. **Master Agent**

* **Role:** Central coordinator.
* **Function:** Aggregates responses from all agents and prepares a well-decorated, final cumulative answer.
* **Output Includes:**

  * Error Description
  * Machine Description
  * Recent Logs
  * Similar Logs (Top 5)
  * Suggested Solution (via LLM)

---

### 2. **Machine Agent** `[WXO RAG]`

* **Function:** Retrieves machine details based on the input machine name.
* **Data Source:** CSV-based **Machines Knowledge-base**
* **Technology:** Watsonx Retrieval-Augmented Generation (RAG)

---

### 3. **Error Agent** `[WXO RAG]`

* **Function:** Looks up error code to fetch the detailed error description.
* **Data Source:** CSV-based **Errors Knowledge-base**
* **Technology:** Watsonx Retrieval-Augmented Generation (RAG)

---

### 4. **Log Agent**

* **Function:** Collects log-related insights from two external tools.

  * 🔧 **Tool-1:** Retrieves most recent log changes
  * 🧠 **Tool-2:** Fetches Top-5 similar logs from historical data

---

## User Input

The user provides:

* An error code or
* A machine name or incident description

---

## Cumulative Output

A structured and intelligent answer is generated containing:

1. **Error Description** (from Error Agent)
2. **Machine Description** (from Machine Agent)
3. **Recent Log Changes** (via Tool-1)
4. **Top-5 Similar Logs** (via Tool-2)
5. **LLM-Based Suggested Fix**

---

## 🔧 Technologies Used

| Component          | Technology               |
| ------------------ | ------------------------ |
| Orchestration      | Watsonx Orchestrate      |
| Retrieval          | WXO RAG (CSV-based RAG)  |
| LLM Inference      | IBM Watsonx.ai / LLM API |
| Log Analysis Tools | Custom Tool-1 & Tool-2   |
| Data Format        | CSV (Knowledge-base)     |

---

## Sample Use-Case Flow

1. User enters: `Error Code - E123` and `Machine Name - DrillX90`
2. Agents fetch respective data:

   * Machine info from Machine Agent
   * Error details from Error Agent
   * Logs from Log Agent
3. Master Agent combines and sends:

   ```
   1. Error: Motor overheating
   2. Machine: DrillX90 - Industrial Drill, 90mm capacity
   3. Recent Logs: RPM spike at 09:31, Cooling fan off
   4. Similar logs: 5 past events (E121, E122...)
   5. LLM Suggestion: Check coolant system, reset motor
   ```

---

##  Benefits

* Faster incident resolution
* Centralized machine and error context
* Insightful log analytics
* AI-powered root cause suggestions

---

## Methods for Deployment

The agent can be set up using either WXO SaaS or the ADK. The following instructions specifically cover the ADK setup.

## Built With

This system is built using [Watsonx Orchestrate Agent Developer Kit (ADK)](https://github.com/IBM/ibm-watsonx-orchestrate-adk).

For more details and setup instructions, refer to the [Watsonx Orchestrate Developer Portal](https://developer.watson-orchestrate.ibm.com/).

---

## Prerequisites

* **Python**: Version 3.11 to 3.13
* **Agent Developer Kit (ADK)**
* **Docker Engine** with `docker-compose` support

  * Recommended container platforms:

    * [Rancher Setup Guide](https://github.com/IBM/ibm-watsonx-orchestrate-adk/blob/main/_docs/recommended-docker-settings/rancher-settings.md)
    * [Colima Setup Guide](https://github.com/IBM/ibm-watsonx-orchestrate-adk/blob/main/_docs/recommended-docker-settings/coilma-settings.md)

### Machine Requirements

* RAM: 16 GB
* CPU: 8 cores
* Disk Space: 25 GB

---

## Project Structure
Click to expand the Project Directory
<details>

```plaintext
MANUFACTURE/
├── Dockerfile
├── Pipfile
├── Pipfile.lock
├── Readme.md
├── agents
│   ├── error_agent.yaml
│   ├── log_agent.yaml
│   ├── machine_agent.yaml
│   └── master_agent.yaml
├── assets
│   └── ManufacturesUsecase.png
├── config.py
├── documents
│   ├── error_codes_updated.csv
│   ├── error_info.yaml
│   ├── final_incident_log_with_machine_type_match.csv
│   ├── machine_codes_updated.csv
│   └── machine_info.yaml
├── entrypoint.sh
├── env_copy
├── main.py
├── opeanapi_spec.json
├── requirements.txt
├── tools
│   ├── get_recent_changes_logs.py
│   └── get_similar_error_logs.py
└── utils
    ├── helper.py
    ├── job_runner.py
    └── milvus.py
```
</details>

---

## Setup Instructions

1. **Create a virtual environment**

   ```bash
   python -m venv venv
   ```

2. **Activate the environment**

   ```bash
   source venv/bin/activate
   ```
3. **Install Requirements**

   ```bash
   pip install -r requirements.txt
   ```
4. **Install the Agent Developer Kit (ADK)**

   ```bash
   pip install ibm-watsonx-orchestrate
   ```

   If needed, upgrade to the latest version:

   ```bash
   pip install --upgrade ibm-watsonx-orchestrate
   ```

   Verify the installation:

   ```bash
   orchestrate --version
   orchestrate --help
   ```

5. **Install Docker and Docker Compose**

   ```bash
   brew install docker
   brew install docker-compose
   ```

6. **Obtain an IBM Entitlement Key**

   * Log in to [My IBM](https://myibm.ibm.com)
   * Navigate to **View Library** > **Add a new key**
   * Copy your entitlement key

---

## Environment Configuration

Create a `.env` file in your root directory with the following content:

```env
WO_DEVELOPER_EDITION_SOURCE=myibm
WO_ENTITLEMENT_KEY=<your-entitlement-key>
WATSONX_APIKEY=<your-watsonx-api-key>
WATSONX_SPACE_ID=<your-space-id>
```

**Note**: Ensure that the deployment SPACE ID is linked to the associated Watson Machine Learning instance.

---

## Run the Application

1. **Start the Orchestrate Server**

   ```bash
   orchestrate server start --env-file=.env
   ```

2. **Activate the Local Environment**

   ```bash
   orchestrate env activate local
   ```

3. **(Optional) Import Tool Example**

   ```bash
   orchestrate tools import -k python -f tools/greetings.py
   ```

4. **Import Knowledge Bases**

   For the knowledge base, we will be using the following files. You can add them either using the command below or by uploading them through the WXO interface.

   1. **For Error Agent**: Use the following file → [error\_codes\_updated.csv](documents/error_codes_updated.csv)
   2. **For Machine Agent**: Use the following file → [machine\_codes\_updated.csv](documents/machine_codes_updated.csv)
   3. **For Log Agent**: Use the following file → [incident\_logs\_updated.csv](documents/final_incident_log_with_machine_type_match.csv)

   The command below loads the files through the corresponding YAML configuration files.

   ```bash
   orchestrate knowledge-bases import -f documents/error_info.yaml
   orchestrate knowledge-bases import -f documents/machine_info.yaml
   ```

5. **Import Agents**

   Load agents in the following order:

   ```bash
   orchestrate agents import -f agents/error_agent.yaml
   orchestrate agents import -f agents/machine_agent.yaml
   orchestrate agents import -f agents/master_agent.yaml
   ```

6. **Launch the Chat Interface**

   ```bash
   orchestrate chat start
   ```

7. **Updating the Knowledge Base [Only if you're facing problems]**

   If you encounter any issues with the knowledge base, refer to the steps below .
   ```
   Example- 
   orchestrate knowledge-bases patch -n <name of the Knowlege base you want to update> -f <path the Knowledge Base file that you want to update>
   ```
   ```
   orchestrate knowledge-bases patch -n machine_info -f documents/machine_info.yaml 
   ```
---

## Support

For technical guidance, refer to the official [Watsonx Orchestrate ADK GitHub Repository](https://github.com/IBM/ibm-watsonx-orchestrate-adk).

---

