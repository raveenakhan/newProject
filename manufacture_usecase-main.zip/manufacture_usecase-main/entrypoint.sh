#!/bin/sh

if [ "$RUN_MODE" = "job" ]; then
    echo "Running in job mode: Executing log generator"
    python utils/job_runner.py
else
    echo "Running in API mode: Starting FastAPI server"
    uvicorn main:app --host 0.0.0.0 --port 8000
fi
