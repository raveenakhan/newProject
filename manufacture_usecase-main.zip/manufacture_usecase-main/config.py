from pymilvus import connections, utility
from pymilvus.exceptions import MilvusException
import time, os
from dotenv import load_dotenv

load_dotenv()

MILVUS_HOST = os.getenv("MILVUS_HOST")
MILVUS_PORT = os.getenv("MILVUS_PORT")
MILVUS_USERNAME = os.getenv("MILVUS_USERNAME")
MILVUS_PASSWORD = os.getenv("MILVUS_PASSWORD")
MILVUS_PEM_PATH = os.getenv("MILVUS_PEM_PATH")

COLLECTION_NAME = os.getenv("COLLECTION_NAME")

WATSONX_API_KEY = os.getenv("WATSONX_API_KEY")
WATSONX_PROJECT_ID = os.getenv("WATSONX_PROJECT_ID")
WATSONX_URL = os.getenv("WATSONX_URL")

WATSONX_LLM_MODEL = "mistralai/mistral-small-3-1-24b-instruct-2503"

EMBEDDING_MODEL_NAME = "BAAI/bge-large-en-v1.5"   # "all-MiniLM-L6-v2"
EMBEDDING_MODEL_DIMENSION = 1024
TOP_K_PAST_SIMILAR_INCIDENTS = 5
TOP_K_MOST_RECENT_INCIDENTS = 4

NEW_LOG_ROWS = 1

RUN_MODE = os.getenv("RUN_MODE", "api")

BASE_LOG_FILE_PATH = "documents/final_incident_log_with_machine_type_match.csv"

INCIDENT_LOG_FILE_PATH = "/tmp/final_incident_log_with_machine_type_match.csv"

ERROR_CODE_FILE_PATH = "documents/error_codes_updated.csv"
MACHINE_CODE_FILE_PATH = "documents/machine_codes_updated.csv"

CERT_LOCAL_PATH = "presto.crt"

COS_LOG_FILE_KEY = "final_incident_log_with_machine_type_match.csv"


def connect_to_milvus(max_retries:int=3, retry_delay:int=5, backoff_factor:float=1.5):
    """
    Establish connection to Milvus with retry logic
    Args:
        max_retries (int): Maximum number of connection attempts
        retry_delay (int): Initial delay between retries in seconds
        backoff_factor (float): Multiplier for delay after each failed attempt
    """
    current_delay = retry_delay
    last_exception = None
    for attempt in range(max_retries):
        try:
            # Add delay before retry attempts (not before first attempt)
            if attempt > 0:
                print(f"Waiting {current_delay} seconds before retry...")
                time.sleep(current_delay)
                current_delay *= backoff_factor  # Exponential backoff
            print(f"Connection attempt {attempt + 1}/{max_retries}")
            print(f"Connecting to: {MILVUS_HOST}:{MILVUS_PORT}")
            # Attempt connection
            connections.connect(
                alias="default",
                host=MILVUS_HOST,
                port=MILVUS_PORT,
                user=MILVUS_USERNAME,
                password=MILVUS_PASSWORD,
                server_pem_path=MILVUS_PEM_PATH,
                server_name=MILVUS_HOST,
                secure=True)
            # Test the connection by listing collections
            collections = utility.list_collections()
            print("Successfully connected to Milvus")
            print(f"Available collections: {collections}")
            return True
        except MilvusException as e:
            print(f"Milvus connection failed (attempt {attempt + 1}): {e}")
            last_exception = e
        except Exception as e:
            print(f"Unexpected error (attempt {attempt + 1}): {e}")
            last_exception = e
    # If we get here, all attempts failed
    print(f"All {max_retries} connection attempts failed")
    print("Please check:")
    print("Network connectivity to the Milvus server")
    print(f"Firewall settings (port{MILVUS_PORT})")
    print("Username and password credentials")
    print("SSL certificate path and validity")
    raise last_exception
