# Japan Pillar - Instructlab - CoP
The repository contains the code &amp; steps to initialize and work on various aspects of instructlab.


Steps to perform Model Quantization:
1. Clone the llama.cpp repository - `https://github.com/ggerganov/llama.cpp.git`
llama.cpp is used to perform the model quantization
2. Change director to llama.cpp-> `cd llama.cpp`
3. Install the requirements -> `pip install -r requirements.txt`
4. Download the original model (you want to quantize) from huggingface using `snapshot_download`
5. Convert the original model from hf format to GGUF format
6. Quantize the model - `! ./llama.cpp/quantize original_model_path+name.gguf quantized_model_path_name.gguf quant_scheme`

Troubleshooting-
Run the commands in terminal if not running in notebook cell.
