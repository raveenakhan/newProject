import gradio as gr
import os
from dotenv import load_dotenv, set_key
from datetime import datetime, date
from langgraph_code import LangGraph_Agents
from crewai_code.businessreportgen.src.businessreportgen import crewai_main

def set_env_variables(var_name, var_value):
    try:
        dotenv_path = ".env"
        os.environ[var_name] = var_value  # Set in session
        set_key(dotenv_path, var_name, var_value)  # Store persistently
        print(f"Set {var_name} to {var_value} in .env file")
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def generate_report(company_name, report_level, agentic_framewrok):
    if not company_name.strip():
        return "Error: 会社名は空欄にできません。有効な名前を入力してください。",None
    
    try:
        report_level = report_level.lower()
        agentic_framewrok = agentic_framewrok.lower()
        
        if agentic_framewrok == "langgraph":
            triggerDataAndTime = datetime.now().strftime("%Y%m%d_%H%M%S")
            start_time = datetime.now()
            report = LangGraph_Agents.get_langgraph_report(company_name, report_level)
            
            file_path = f"output_report/langgrpah_report/{company_name}/{report_level}/{company_name}_{triggerDataAndTime}.md"
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(report)
            end_time = datetime.now()
            duration = end_time - start_time
            print(f"\nLangGraph: {company_name} {report_level} Report Generation -> Process started at {start_time}")
            print(f"\nLangGraph: {company_name} {report_level} Report Generation -> Process completed at {end_time}")
            print(f"\nLangGraph: {company_name} {report_level} Report Generation -> Total duration: {duration}")
        else:
            # set env variables
            set_env_variables(var_name="COMPANY_NAME_FOR_REPORT", var_value=company_name)
            set_env_variables(var_name="TIER_LEVEL", var_value=report_level)
            set_env_variables(var_name="COMPANY_COPYRIGHTS", var_value="IBM AND " + company_name)
            load_dotenv()
            
            file_path = crewai_main.kickoff()
            with open(file_path, "r") as file:
                report = file.read()

        return report, file_path
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def get_report_headings(report_level):
    # Define headings for each report level
    report_headings = {
    "Basic": ["Basic Information", "Company History", "Products & Services", "Organisation & Personnel"],
    "Medium": ["Basic Information", "Company History", "Products & Services", "Organisation & Personnel"
               , "Financials", "Market & Competitive Environment", "Business Strategy", "Technology & Innovation"],
    "Comprehensive": ["Basic Information", "Company History", "Products & Services", "Organisation & Personnel"
                      , "Financials", "Market & Competitive Environment", "Business Strategy", "Technology & Innovation", "Risks"
                      , "Customers & Brand", "Social Responsibility", "Growth Potential & Future Outlook"]
                      }
    
    return "\n".join(report_headings.get(report_level, []))

# Function to update report output dynamically when typing company name
def update_report_output(company_name):
    return f"## {company_name} のレポート\n\nこれはサンプル レポートです。" if company_name else "## レポートはここに表示されます!"

def main():
    try:
        custom_css = """
            #markdown-box {
                border: 2px solid #e0e7ff;  /* Border color */
                border-radius: 8px;  /* Rounded corners */
                background-color: #e0e7ff;  /* Light background */
                margin-top: 0;
            }
            #report-label {
                margin-bottom: -10px;
                padding-bottom: 0;
                padding-right:2pc;
                border: 2px solid #e0e7ff;  /* Border color */
                border-radius: 8px;  /* Rounded corners */
                background-color: #e0e7ff;  /* Light background */
            }
            """
        theme = gr.themes.Soft()
        with gr.Blocks(theme=theme, css=custom_css) as demo:
            with gr.Row():
                gr.Markdown("<h2 style='text-align: center; color: #6366f1; background-color: #e0e7ff;'>スマートレポートジェネレーター</h2>", elem_id="markdown_heading")
            with gr.Row():
                with gr.Column():
                    agentic_toggle_button = gr.Radio(
                        ["LangGraph", "CrewAI"], 
                        label="エージェントフレームワークを選択", 
                        value="LangGraph",  # Default selected value
                        interactive=True  # Allow interaction
                    )
                    # lang_toggle_button = gr.Radio(
                    #     ["Japanese", "English"], 
                    #     label="言語を選択", 
                    #     value="Japanese",  # Default selected value
                    #     interactive=True  # Allow interaction
                    # )
                    # search_engine_api_key = gr.Textbox(label = "検索エンジンのAPIキーを入力してください")
                    company_name_textbox = gr.Textbox(label = "会社名を入力してください:", )
                    report_level_radio_btn = gr.Radio(["Basic", "Medium", "Comprehensive"], label="レポートレベルを選択", value="Basic")
                    output_report_level_text = gr.Textbox(label="レポートに含まれるもの", lines=17, value=get_report_headings("Basic"))
                    generate_report_button = gr.Button("レポートを生成する")
                with gr.Column():
                    gr.Markdown("<h3 style='color: #6366f1;'>企業情報レポート</h3>", elem_id="report-label")
                    report_output = gr.Markdown(show_copy_button=True, height=630, elem_id="markdown-box")
                    download_button = gr.File(label="レポートをダウンロード")
            with gr.Accordion():
                gr.Markdown("<h3 style='text-align: left; color: #6366f1;'>Developed by IBM Client Engineering, Banking Team</h3>")

            # Event handlers
            company_name_textbox.input(update_report_output, inputs=company_name_textbox, outputs=report_output)
            report_level_radio_btn.select(get_report_headings, inputs=report_level_radio_btn, outputs=output_report_level_text)
            generate_report_button.click(generate_report, 
                                        inputs=[company_name_textbox, 
                                                report_level_radio_btn, 
                                                agentic_toggle_button,
                                                # lang_toggle_button
                                                ], 
                                        outputs=[report_output, download_button])
        return demo
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

if __name__ == "__main__":
    try:
        demo = main()
        demo.launch(auth=['test', 'demoapp'] , server_port=8000)
    except Exception as e:
        print(f"Error during startup: {e}")








