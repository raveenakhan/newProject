# from pydantic import BaseModel
# from tavily import TavilyClient
# from IPython.display import Image
# from langgraph.prebuilt import create_react_agent
# from ibm_watsonx_ai.foundation_models import Model
# from langchain_google_community import GoogleSearchAPIWrapper
# from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

import os, operator, json, time, re
from dotenv import load_dotenv
from langchain_ibm import WatsonxLLM
from langchain_core.tools import Tool
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, START, END
from langchain_community.utilities import GoogleSerperAPIWrapper
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, AnyMessage, ChatMessage

load_dotenv()

# Load credentials
serper_api_key = os.environ["SERPER_API_KEY"]
watsonx_api_key = os.getenv("WATSONX_API_KEY")
watsonx_url = os.getenv("WATSONX_URL")
watsonx_project_id = os.getenv("WATSONX_PROJECT_ID")

# Establish search tool
search_tool = GoogleSerperAPIWrapper(serper_api_key=serper_api_key)

# Get the LLM
def get_model(model_name):
    try:
        parameters = {
        "decoding_method": "sample",
        "temperature":0.3,
        "max_new_tokens": 16000,
        "min_new_tokens": 0,
        "stop_sequences": ["<EOC>"],
        "random_seed": 1234,
        "repetition_penalty": 1
    }
        llm  = WatsonxLLM(
        model_id=model_name,
        apikey=watsonx_api_key,
        url=watsonx_url,
        project_id=watsonx_project_id,
        params=parameters,
    )
        return llm
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

cache = {}

def cached_search(query):
    try:
        if query in cache:
            return cache[query]  # ✅ Return cached result instead of making a new request
        else:
            result = search_tool.run(query)
            # result = google_search_tool.run(query)
            cache[query] = result
            return result
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

# Establish the agent nodes
class AgentState(TypedDict):
    company_name: str
    report_level: str
    # language: str
    company_basic_info: Annotated[List[str], operator.add]
    financial_info: Annotated[List[str], operator.add]
    tech_accomplishment_info: Annotated[List[str], operator.add]
    brand_info: Annotated[List[str], operator.add]
    sustainability_info: Annotated[List[str], operator.add]
    future_growth_info: Annotated[List[str], operator.add]
    report: str

def make_system_prompt(company_name):
    try:
        common_prompt = """When extracting information, ensure the following:
                    1. **Prioritize Reliable Sources:** Use only:
                        - Official reports (company website, SEC filings, annual reports).
                        - Reputable business sources (Bloomberg, Reuters, Forbes).
                        - Credible industry analyses and market research.
                    2. **Concise Yet Insightful Data:** Focus on key facts without unnecessary detail. Avoid excessive numbers, minor events, or trivial statistics.
                    3. **Verifiable Citations:** Include URLs for sourced data.
                    4. **Structured JSON Output:** 
                        ```json
                        {{"queries": ["Query_1", "Query_2", "Query_3"]}}
                        ```
                        ```json
                        {{"sources":["Link_1", "Link_2", "Link_3"]}}
                        ```
                    5. **Completion Indicator:** Append `<EOC>` at the end of the JSON response.
                    """

        prompt = {
            "company_info_prompt": f"""<s> [INST]You are a business analyst conducting a strategic research report on {company_name}. 

            Generate **high-level queries** focusing on:
                - **Core Details:** 
                    - Company name, founding year, location, key executives.
                    - Industry, business model, major subsidiaries.
                - **Key Milestones:** 
                    - Significant events, product breakthroughs, major partnerships.
                - **Offerings & Market Presence:** 
                    - Flagship products/services, competitive positioning.

            {common_prompt}
            [/INST]""",

            "financial_info_prompt": f"""<s> [INST]You are a financial analyst extracting critical insights about {company_name}. 

            Generate **concise financial queries** covering:
                - **Financial Health:** 
                    - Revenue, net profit, key financial metrics.
                    - Market value, stock performance (if applicable).
                - **Investment & Growth:** 
                    - Major funding rounds, top investors, strategic investments.
                - **Competitive Positioning:** 
                    - Industry benchmarks, key rivals, profitability trends.

            {common_prompt}
            [/INST]""",

            "tech_accomplishment_info_prompt": f"""<s> [INST]You are a technology research analyst assessing {company_name}'s **innovation & digital strategy**. 

            Generate **targeted queries** on:
                - **Patents & Intellectual Property:** 
                    - Notable patents, proprietary technologies.
                - **Tech Stack & Digital Infrastructure:** 
                    - Core platforms (AI, cloud, software tools).
                - **Innovation Leadership:** 
                    - R&D focus, disruptive technologies, key tech-driven strategies.

            {common_prompt}
            [/INST]""",

            "brand_info_prompt": f"""<s> [INST]You are a brand analyst evaluating {company_name}'s **market reputation & branding strategies**. 

            Generate **essential branding queries** covering:
                - **Brand Positioning & Perception:** 
                    - Market reputation, consumer sentiment.
                - **Major Branding Milestones:** 
                    - Rebrands, high-impact campaigns, sponsorships.
                - **Competitive Brand Standing:** 
                    - Brand strength vs. competitors.

            {common_prompt}
            [/INST]""",

            "sustainability_info_prompt": f"""<s> [INST]You are a sustainability expert analyzing {company_name}'s **ESG & sustainability efforts**. 

            Generate **focused sustainability queries** on:
                - **Green Initiatives & Goals:** 
                    - Carbon neutrality, waste reduction.
                - **Corporate Social Responsibility (CSR):** 
                    - Diversity programs, social impact.
                - **Regulatory Compliance:** 
                    - ESG ratings, sustainability certifications.

            {common_prompt}
            [/INST]""",

            "future_outlook_growth_info_prompt": f"""<s> [INST]You are a business strategist forecasting {company_name}'s **growth & future market positioning**. 

            Generate **succinct strategic queries** covering:
                - **Expansion Plans:** 
                    - New products, market expansion, acquisitions.
                - **Financial & Market Outlook:** 
                    - Revenue projections, emerging opportunities.
                - **Key Industry Risks:** 
                    - Market disruptions, competitive challenges.

            {common_prompt}
            [/INST]"""
        }
        return prompt
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}
    
def report_prompt(company_name, report_level, 
                  company_basic_info="", 
                  financial_info="", 
                  tech_accomplishment_info="", 
                  brand_info="", 
                  sustainability_info="", 
                  future_growth_info=""):
    try:
        output_prompt = f"""
        - **Ensure the report is exceptionally detailed and accurate.** No critical information should be omitted.
        - If any **important** information is missing, supplement it with verified details from **credible sources**.
        - **Cite sources separately** with correct and accessible reference links.
        - The report must be written in **Japanese**.
        - Append an `<EOC>` token at the end to indicate completion.

        ### **EXPECTED MARKDOWN OUTPUT FORMAT**  
        The report must strictly follow this **structured markdown format**, adjusting based on the **report level**:

        ```markdown
        # BUSINESS REPORT - {company_name}
        
        ## 1. 会社概要
        - **会社名:** 
        - **本社所在地:** 
        - **設立年:** 
        - **創業者:** 
        - **業界:** 
        - **組織構造:** 
        - **公式ウェブサイト & SNS:**
        
        ## 2. 企業の歴史
        - **主要なマイルストーン:**
        
        ## 3. 製品・サービス
        - **提供する製品・サービス:**
        - **将来の計画:**
        
        ## 4. 財務情報 (適用可能な場合)
        - **年間・四半期収益:**
        - **利益・損失:**
        - **株価・市場価値:**
        - **主要投資家・資金調達情報:**
        
        ## 5. 技術とイノベーション (適用可能な場合)
        - **特許・知的財産:**
        - **使用技術 & インフラ:**
        - **研究開発 (R&D) への取り組み:**
        
        ## 6. ブランド・市場評判 (適用可能な場合)
        - **市場での評価:**
        - **顧客フィードバックとレビュー:**
        - **メディア報道:**
        
        ## 7. 持続可能性とCSR (適用可能な場合)
        - **環境対策・CO2削減:**  
        - **企業の社会的責任 (CSR) 活動:**  
        - **グリーン認証と規制遵守:**  
        
        ## 8. 将来の展望と成長戦略 (適用可能な場合)
        - **今後の戦略的計画:**  
        - **市場拡大、合併・買収計画:**  
        - **成長予測:**  
        
        ## 9. 情報ソース
        - **参考リンク:**
        
        *<EOC>*
        ```
        """

        if report_level == "basic":
            report_prompt = f"""<s> [INST]You are an expert report writer.  
            Use **all** the provided information to write a **detailed and structured** report about {company_name}.  
            **No information should be skipped.**  

            - **Report Purpose:** This will be presented to company executives, so the quality must be impeccable.  
            - **Ensure complete coverage of the company overview and history.**  
            - **Utilize all provided information:**  

                ---------------------
                {company_basic_info}
                ---------------------
            {output_prompt}
            [/INST]"""

        elif report_level == "medium":
            report_prompt = f"""<s> [INST]You are an expert report writer.  
            Use **all** the provided information to write a **detailed and structured** report about {company_name}.  
            **No information should be skipped.**  

            - **Report Purpose:** This will be presented to company executives, so the quality must be impeccable.  
            - **Ensure complete coverage of financial details and technological aspects.**  
            - **Utilize all provided information:**  

                ---------------------------
                {company_basic_info}
                ---------------------------
                {financial_info}
                ---------------------------
                {tech_accomplishment_info}
                ---------------------------
            {output_prompt}
            [/INST]"""

        elif report_level == "comprehensive":
            report_prompt = f"""<s> [INST]You are an expert report writer.  
            Use **all** the provided information to write a **detailed and structured** report about {company_name}.  
            **No information should be skipped.**  

            - **Report Purpose:** This will be presented to company executives, so the quality must be impeccable.  
            - **Ensure the report covers every key aspect: financials, technology, brand, sustainability, and future outlook.**  
            - **Utilize all provided information:**  

                ---------------------------
                {company_basic_info}
                ---------------------------
                {financial_info}
                ---------------------------
                {tech_accomplishment_info}
                ---------------------------
                {brand_info}
                ---------------------------
                {sustainability_info}
                ---------------------------
                {future_growth_info}
                ---------------------------
            {output_prompt}
            [/INST]"""

        return report_prompt
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def company_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        company_info_prompt = make_system_prompt(state["company_name"])["company_info_prompt"] 
        response = model.invoke([SystemMessage(content=company_info_prompt)])

        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)
        
        print("company_basic_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)
        
        company_basic_info = state.get('company_basic_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            company_basic_info.append(search_results)
        
        company_basic_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            company_basic_info.append(s)
        return {"company_basic_info":company_basic_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def financial_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        financial_info_prompt = make_system_prompt(state["company_name"])["financial_info_prompt"] 
        response = model.invoke([SystemMessage(content=financial_info_prompt)])
        
        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)
        
        print("financial_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)

        financial_info = state.get('financial_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            financial_info.append(search_results)
        financial_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            financial_info.append(s)
        return {"financial_info":financial_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}
    
def tech_accomplishment_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        tech_accomplishment_info_prompt = make_system_prompt(state["company_name"])["tech_accomplishment_info_prompt"] 
        response = model.invoke([SystemMessage(content=tech_accomplishment_info_prompt)])
    
        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)

        print("tech_accomplishment_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)

        tech_accomplishment_info = state.get('tech_accomplishment_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            tech_accomplishment_info.append(search_results)
        tech_accomplishment_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            tech_accomplishment_info.append(s)
        return {"accomplishment_info":tech_accomplishment_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def brand_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        brand_info_prompt = make_system_prompt(state["company_name"])["brand_info_prompt"] 
        response = model.invoke([SystemMessage(content=brand_info_prompt)])
        
        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)
    
        print("brand_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)

        brand_info = state.get('brand_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            brand_info.append(search_results)
        brand_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            brand_info.append(s)
        return {"brand_info":brand_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def sustainability_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        sustainability_info_prompt = make_system_prompt(state["company_name"])["sustainability_info_prompt"] 
        response = model.invoke([SystemMessage(content=sustainability_info_prompt)])
        
        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)
        
        print("sustainability_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)

        sustainability_info = state.get('sustainability_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            sustainability_info.append(search_results)
        sustainability_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            sustainability_info.append(s)
        return {"sustainability_info":sustainability_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def future_growth_info_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        future_outlook_growth_info_prompt = make_system_prompt(state["company_name"])["future_outlook_growth_info_prompt"] 
        response = model.invoke([SystemMessage(content=future_outlook_growth_info_prompt)])
        
        pattern = r"json\s*({.*?})\s*"
        matches = re.findall(pattern, response, re.DOTALL)
        if len(matches) >= 2: 
            queries_dict = json.loads(matches[0]) # First JSON (queries) 
            sources_dict = json.loads(matches[1]) # Second JSON (sources)
        
        print("future_growth_info")
        print(response)
        print("Queries Dictionary:")
        print(queries_dict)
        print("\nSources Dictionary:")
        print(sources_dict)

        future_growth_info = state.get('future_growth_info', [])
        for q in queries_dict['queries']:
            search_results = cached_search(q)
            future_growth_info.append(search_results)
        future_growth_info.append("Reference links:\n")
        for s in sources_dict['sources']:
            future_growth_info.append(s)
        return {"future_growth_info":future_growth_info}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}

def report_writer_node(state:AgentState):
    try:
        model = get_model(model_name="mistralai/mistral-large")
        if state["report_level"] == "basic":
            report_gen_prompt = report_prompt(state['company_name'], 
                                            # state["language"], 
                                            state["report_level"], 
                                            state['company_basic_info'])
        elif state["report_level"] == "medium":
            report_gen_prompt = report_prompt(state['company_name'], 
                                            # state["language"],
                                            state["report_level"],
                                            state['company_basic_info'], 
                                            state['financial_info'], 
                                            state['tech_accomplishment_info'])
        elif state["report_level"] == "comprehensive":
            report_gen_prompt = report_prompt(state['company_name'], 
                                            # state["language"], 
                                            state["report_level"], 
                                            state['company_basic_info'], 
                                            state['financial_info'], 
                                            state['tech_accomplishment_info'], 
                                            state['brand_info'], 
                                            state['sustainability_info'], 
                                            state['future_growth_info'])

        # user_message = HumanMessage(content = f"Write a detailed report about the company {state['company_name']}.")
        messages = [SystemMessage(content=report_gen_prompt)]
        response = model.invoke(messages)
        return {"report":response}
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}
    
def get_langgraph_report(company_name, report_level):
    print("\nLangGraph report generation started\n")
    try:
        builder = StateGraph(AgentState)

        if report_level == "basic":
            builder.add_node("company_info", company_info_node)
            builder.add_node("report_writer", report_writer_node)
            # Add Edge
            builder.add_edge("company_info", "report_writer")
            # Remove set_entry_point("company_info") and instead set multiple entry points
            builder.set_entry_point("company_info")
        elif report_level == "medium":
            builder.add_node("company_info", company_info_node)
            builder.add_node("finance_info", financial_info_node)
            builder.add_node("tech_achievement_info", tech_accomplishment_info_node)
            builder.add_node("report_writer", report_writer_node)
            # Run company_info, financial_info, and tech_accomplishment_info in parallel
            builder.add_edge(START, "company_info")
            builder.add_edge("company_info", "finance_info")
            builder.add_edge("finance_info", "tech_achievement_info")
            builder.add_edge("tech_achievement_info", "report_writer")
            
        elif report_level == "comprehensive":
            builder.add_node("company_info", company_info_node)
            builder.add_node("finance_info", financial_info_node)
            builder.add_node("tech_achievement_info", tech_accomplishment_info_node)
            builder.add_node("brand_value_info", brand_info_node)
            builder.add_node("csr_info", sustainability_info_node)
            builder.add_node("future_info", future_growth_info_node)
            builder.add_node("report_writer", report_writer_node)
            # ✅ Run all major nodes in parallel
            builder.add_edge(START, "company_info")
            builder.add_edge("company_info", "finance_info")
            builder.add_edge("finance_info", "tech_achievement_info")
            builder.add_edge("tech_achievement_info", "brand_value_info")
            builder.add_edge("brand_value_info", "csr_info")
            builder.add_edge("csr_info", "future_info")
            builder.add_edge("future_info", "report_writer")

        # ✅ Define the end node
        builder.add_edge("report_writer", END)

        # Compile the graph
        graph = builder.compile()

        # Generate and save the graph visualization
        graph_flow_img = graph.get_graph().draw_png()

        image_path = os.path.join("langgraph_code/graph_flow_image", "graph_flow.png")
        os.makedirs(os.path.dirname(image_path), exist_ok=True)

        with open(image_path, "wb") as img_file:
            img_file.write(graph_flow_img)

        # Stream results
        report_text = ""
        for s in graph.stream(AgentState(company_name=company_name, report_level=report_level)):
            if "report_writer" in s:
                report_text = s.get('report_writer')
                report_text = report_text.get('report')
                
        match = re.search(r"# BUSINESS REPORT.*", report_text, re.DOTALL)
        if match:
            report_content = match.group(0) # Extract the matched markdown content
            print(report_content)
        else:
            match = re.search(r"# ビジネスレポート.*", report_text, re.DOTALL)
            if match:
                report_content = match.group(0) # Extract the matched markdown content
                print(report_content)
        report_content = report_content.replace("<EOC>","")
        report_content = report_content.replace("(適用可能な場合)","")
        return report_content
    except Exception as e:
        print(f"Error: {e}")
        return {f"Error: {e}"}