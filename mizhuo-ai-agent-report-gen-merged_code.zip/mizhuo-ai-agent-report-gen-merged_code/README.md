# MIZUHO - AGENTIC REPORT GENERATION
## Introduction:
AI Agentic Workflow to generate business reports for specific company. This solution explores the two most popular frameworks:
1. <b>Crew.AI</b> --> Crew AI is a framework designed to facilitate the collaboration of role-based AI agents. Each agent in Crew AI is assigned specific roles and goals, allowing them to operate as a cohesive unit. This framework is ideal for building sophisticated multi-agent systems such as multi-agent research teams. Crew AI supports flexible task management, autonomous inter-agent delegation, and customizable tools.
2. <b>LangGraph</b> --> LangGraph is an open-source framework designed by Langchain to build stateful, multi-actor applications using LLMs. Inspired by the long history of representing data processing pipelines as directed acyclic graphs (DAGs), LangGraph treats workflows as graphs where each node represents a specific task or function. This graph-based approach allows for fine-grained control over the flow and state of applications, making it particularly suitable for complex workflows that require advanced memory features, error recovery, and human-in-the-loop interactions. LangGraph integrates seamlessly with LangChain, providing access to a wide range of tools and models, and supports various multi-agent interaction patterns.

## Architecture:
![alt text](image.png)

## Setup Steps:
A. Get Google Serper API Key Environment variable (Search Engine to get information from web):
1. Visit the website: https://serper.dev/
2. Sign Up (if you do not have an account) or Sign in (If you have an account)
3. From the left hand side menu, click on API Key.
4. Copy the API KEY and paste it in the env file.

B. Code Setup:
1. Create a virtual environment.
`python -m venv <virtual_env_name>`
2. Activate the virtual environment.
`source <virtual_env_name>\bin\activate`
3. Install dependencies via requirements.txt
`pip install -r requirements.txt`
4. Launch the application: 
`python3 main.py`

#### Note: The setup steps provided are for MacOS. Please follow the windows command if using Windows OS.
---
---
## Troubleshooting:
If you observe any of the below issues in the backend:
1. HTTPError: 400 Client Error: Bad Request for url
2. Rate Limit exceeded

#### `Reason: The Google Serper API Key has exhausted the daily credit limit of 2500 queries.`

#### `Solution: Change the Serper API Key to a new one.`
---


Developed by:
 - Raveena Khan (raveena.khan@ibm.com)
 - Paarttipaabhalaji Manohar (Paarttipaabhalaji.M@ibm.com)