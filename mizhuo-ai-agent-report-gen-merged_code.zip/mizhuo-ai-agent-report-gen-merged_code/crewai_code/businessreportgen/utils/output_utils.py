from datetime import datetime
import os
import re
from dotenv import load_dotenv

class OutputUtils:

    def __init__(self, company_name=None):
        load_dotenv()
        print("Outpututils init", company_name)
        self.company_name = company_name
        self.triggerDataAndTime = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir =os.getenv("OUTPUT_DIR_PSEUDOCODE")
        self.output_dir_name_plantuml = os.getenv("OUTPUT_DIR_NAME_PLANTUML")
        self.tier_level = os.getenv("TIER_LEVEL")

    def write_to_file(output_dir_name_plantuml :str,
                      company_name :str,
                      triggerDataAndTime :str, 
                      data :str, 
                      horizontal_line : bool):
        directory_path=f"""{output_dir_name_plantuml}/{company_name}/{triggerDataAndTime}"""
        filename=f"""{company_name}_{triggerDataAndTime}.md"""
        os.makedirs(directory_path, exist_ok=True)
        file_path = os.path.join(directory_path, filename)

        with open(file_path, 'a', encoding='utf-8') as f:
            f.write(data + '\n' + '\n')
            if(horizontal_line):
                f.write("---" + '\n')
            f.close
        return file_path

    def output_normalizer(self, output, task_name):
        # print(f"Inserting the {task_name} details into the report...")
        # Pattern matches any text starting with <!-- and ending with -->
        company_copyrights=os.getenv("COMPANY_COPYRIGHTS")
        pattern_01 = r'<!--.*?-->'
        pattern_02 = r'```markdown\n(.*?)```'
        pattern_03 = r'```[\w]*\n(.*?)```'
        
        # Function to process each match
        def preserve_content(match):
            # Return the content between fences
            return match.group(1)

        # re.DOTALL flag makes . match newlines as well
        result_remove_comment = re.sub(pattern_01, '', output, flags=re.DOTALL)

        if(task_name in ["company_history_task","milestone_visualizaer_task"] ):
            file_path = OutputUtils.write_to_file(output_dir_name_plantuml=self.output_dir_name_plantuml, 
                                                  company_name=self.company_name,
                                                  triggerDataAndTime=self.triggerDataAndTime, 
                                                  data=result_remove_comment, 
                                                  horizontal_line=bool(1))
        else:  
            # Replace matching patterns, preserving content
            result_remove_markdownFence = re.sub(pattern_02, preserve_content, result_remove_comment, flags=re.DOTALL)

            result_remove_markdownFence_002 = re.sub(pattern_03, preserve_content, result_remove_markdownFence, flags=re.DOTALL) 
            # TIRE_LEVEL="Basic"
            # TIRE_LEVEL="Medium"
            # TIRE_LEVEL="Comprehensive"

            if((task_name == "certifications_and_goals_task" and self.tier_level=="Comprehensive") or (task_name == "key_milestones_task" and self.tier_level=="Basic") 
                or (task_name == "industry_impact_task"and self.tier_level=="Medium")):
                result_remove_markdownFence_002=result_remove_markdownFence_002+f"\n\n---\n\nCopyright (c) 2024-2025 IBM and {self.company_name} All rights reserved."
            
            file_path = OutputUtils.write_to_file(output_dir_name_plantuml=self.output_dir_name_plantuml, 
                                                  company_name=self.company_name, 
                                                  triggerDataAndTime=self.triggerDataAndTime, 
                                                  data=result_remove_markdownFence_002, 
                                                  horizontal_line=bool(1))
        return file_path
