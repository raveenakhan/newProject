import os, asyncio, time
from pydantic import BaseModel
from crewai.flow.flow import Flow, listen, start, router, and_, or_
# from crewai.project import after_kickoff

from dataclasses import dataclass
from typing import List
from crewai_code.businessreportgen.utils.output_utils import OutputUtils
from datetime import datetime, date

# Importing all the required crews
from crewai_code.businessreportgen.src.businessreportgen.crews.company_information.company_information import CompanyInformation
from crewai_code.businessreportgen.src.businessreportgen.crews.financial_analysis.financial_analysis import FinancialAnalysis
from crewai_code.businessreportgen.src.businessreportgen.crews.techinfra_innovation.techinfra_innovation import TechinfraInnovation
from crewai_code.businessreportgen.src.businessreportgen.crews.accomplishment_details.accomplishment_details import AccomplishmentDetails
from crewai_code.businessreportgen.src.businessreportgen.crews.sustainability_environmental_responsibility.sustainability_environmental_responsibility import SustainabilityEnvironmentalResponsibility

@dataclass
class TaskOutputDataClass:
    description: str
    name: str
    expected_output: str
    raw: str
    summary: str

class BusinessReportState(BaseModel):
    company_name: str = ''
    company_copyrights_name: str = ''
    company_business_report: str = ''
    company_information_report: List[TaskOutputDataClass] = []
    financial_analysis_report: List[TaskOutputDataClass] = []
    accomplishment_analysis_report: List[TaskOutputDataClass] = []
    technology_infra_analysis_report: List[TaskOutputDataClass] = []
    sustainability_environmet_responsability_analysis_report: List[TaskOutputDataClass] = []
    tier_level: str = ''

class BusinessReportFlow(Flow[BusinessReportState]):
    @start()
    def fetching_company_name(self):
        print("Fetching Company name...")
        self.state.company_name = os.getenv("COMPANY_NAME_FOR_REPORT")
        self.state.company_copyrights_name = os.getenv("COMPANY_COPYRIGHTS")
        self.state.tier_level = os.getenv("TIER_LEVEL")

    def get_common_inputs(self):
        """Helper method to generate common inputs with company_name"""
        return {'company_name': self.state.company_name, 'current_year':date.today().year}

    @router(fetching_company_name)
    def determine_tier_agents(self):
        tier_level = self.state.tier_level
        if tier_level == 'basic':
            return "Basic"
        elif tier_level == 'medium':
            return "Medium"
        elif tier_level == 'comprehensive':
            return "Comprehensive"
        else:
            print(f"Unknown tire level: {tier_level}")
            return []
    
    @listen("Basic")
    async def basic_level_report(self, ):
        print("Generating company information report...")
        company_info_result = (
            await CompanyInformation()
            .crew()
            .kickoff_async(inputs=self.get_common_inputs())
        )
        self.state.company_information_report = company_info_result.tasks_output

    @listen("Medium")
    async def mid_level_report(self, ):
        print("Starting parallel report generation for Medium Level...")
        # Create all tasks first
        company_info_task = CompanyInformation().crew().kickoff_async(
            inputs=self.get_common_inputs()
        )
        financial_task = FinancialAnalysis().crew().kickoff_async(
            inputs=self.get_common_inputs()
        )
        accomplishment_task = AccomplishmentDetails().crew().kickoff_async(
            inputs=self.get_common_inputs()
        )

        # Execute all tasks concurrently
        results = await asyncio.gather(
            company_info_task,
            financial_task,
            accomplishment_task
        )

        # Assign results
        self.state.company_information_report = results[0].tasks_output
        self.state.financial_analysis_report = results[1].tasks_output
        self.state.accomplishment_analysis_report = results[2].tasks_output

    @listen("Comprehensive")
    async def Comprehensive_Level_report(self, ):
        print("Starting parallel report generation for Comprehensive-Level...")
        # Create all tasks first
        tasks = [
            CompanyInformation().crew().kickoff_async(
                inputs=self.get_common_inputs()
            ),
            FinancialAnalysis().crew().kickoff_async(
                inputs=self.get_common_inputs()
            ),
            AccomplishmentDetails().crew().kickoff_async(
                inputs=self.get_common_inputs()
            ),
            TechinfraInnovation().crew().kickoff_async(
                inputs=self.get_common_inputs()
            ),
            SustainabilityEnvironmentalResponsibility().crew().kickoff_async(
                inputs=self.get_common_inputs()
            )
        ]

        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks)

        # Assign results using list unpacking
        (ci, fa, aa, ti, ser) = results
        self.state.company_information_report = ci.tasks_output
        self.state.financial_analysis_report = fa.tasks_output
        self.state.accomplishment_analysis_report = aa.tasks_output
        self.state.technology_infra_analysis_report = ti.tasks_output
        self.state.sustainability_environmet_responsability_analysis_report = ser.tasks_output

    @listen(or_(basic_level_report, mid_level_report, Comprehensive_Level_report))
    async def Report_Generation(self):
        Obj_OutputUtils = OutputUtils(company_name=self.state.company_name)
        self.final_report = []

        tier = self.state.tier_level
        reports_to_include = []

        if tier == 'basic':
            reports_to_include = [self.state.company_information_report]
        elif tier == 'medium':
            reports_to_include = [
                self.state.company_information_report,
                self.state.financial_analysis_report,
                self.state.accomplishment_analysis_report
            ]
        elif tier == 'comprehensive':
            reports_to_include = [
                self.state.company_information_report,
                self.state.financial_analysis_report,
                self.state.accomplishment_analysis_report,
                self.state.technology_infra_analysis_report,
                self.state.sustainability_environmet_responsability_analysis_report
            ]
        else:
            print(f"Unknown tier level: {tier}")
            return

        # Flatten the reports
        self.final_report = [item for report in reports_to_include for item in report]

        if self.final_report:
            from tqdm import tqdm
            final_result_len = len(self.final_report)
            with tqdm(total=final_result_len, 
                    desc=f"Business Report Generation for {self.state.company_name}", 
                    unit=" Tasks") as pbar:
                # Process all tasks without artificial delay
                for task in self.final_report:
                    task_data = {
                        "name": task.name,
                        "raw": task.raw
                    }
                    file_path = Obj_OutputUtils.output_normalizer(
                        output=task_data['raw'],
                        task_name=task_data['name']
                    )
                    pbar.update(1)
            return file_path
        else:
            print("Final business reports are empty, please check inputs.")
            return "Final business reports are empty, please check inputs."

async def async_main():
    try:
        start_time = datetime.now()
        business_report_gen_flow = BusinessReportFlow()
        file_path = await business_report_gen_flow.kickoff_async()
        end_time = datetime.now()
        duration = end_time - start_time
        print(f"\nProcess started at {start_time}")
        print(f"Process completed at {end_time}")
        print(f"Total duration: {duration}")
        return file_path
    except Exception as e:
        print(f"Error in async_main: {str(e)}")
        raise

def kickoff():
    try:
        time.sleep(5)
        print("\nCrewAI report generation started\n")
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            file_path = loop.run_until_complete(async_main())
            return file_path
    except Exception as e:
        print(f"Error in kickoff: {str(e)}")
        raise
    finally:
        try:
            loop.close()
        except:
            pass

def plot():
    poem_flow = BusinessReportFlow()
    poem_flow.plot()