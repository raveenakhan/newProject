import os
from dotenv import load_dotenv
from crewai import LLM

class watsonxConfig():
    load_dotenv()
    apikey = os.getenv("WATSONX_API_KEY")
    base_url = os.getenv("WATSONX_URL")
    projId = os.getenv("WATSONX_PROJECT_ID")
    model = os.getenv("MODEL")
    max_tokens=int(os.getenv("MAX_TOKENS"))
    temperature=float(os.getenv("TEMPERATURE"))
    top_p=float(os.getenv("TOP_P"))
    seed=int(os.getenv("SEED"))
    country=os.getenv("COUNTRY")
    locale=os.getenv("LOCALE")
    location=os.getenv("LOCATION")
    language = os.getenv("LANGUAGE")
    

    #embedding_model_configurations
    embedding_model_watsonx = os.getenv("WATSONX_EMBEDDER_MODEL_ID")

    #crewai_memory_configurations
    crewai_storage_dir = os.getenv("CREWAI_STORAGE_DIR")

    #Localization_Japanese
    prompt_file_japanese = os.getenv("PROMPT_FILE_JAPANESE")
    # print('in watsonxconfig class',prompt_file_japanese)

    #Localization_English
    prompt_file_english = os.getenv("PROMPT_FILE_ENGLISH")
    # print('in watsonxconfig class',prompt_file_english)

    #Agent Execution Config
    max_iter=int(os.getenv("MAX_ITERATIONS"))
    max_rpm=int(os.getenv("MAX_RPM"))


    # Determine provider from model prefix
    if model.startswith("watsonx/"):
        # Configuration for watsonx provider
        llm_config = LLM(
            model=model,
            api_key=apikey,
            base_url=base_url,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            seed=seed
        )
    elif model.startswith("watsonx_text/"):
        # Configuration for watsonx_text provider (no API credentials)
        llm_config = LLM(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            seed=seed
        )
    else:
        raise ValueError(f"Unsupported model provider for: {model}")