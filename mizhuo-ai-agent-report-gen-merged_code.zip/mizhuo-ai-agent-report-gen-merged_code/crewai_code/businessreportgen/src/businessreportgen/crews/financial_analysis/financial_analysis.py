import os
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SerperDevTool
from crewai_code.businessreportgen.src.businessreportgen.watsonx_llm import watsonxConfig
from crewai.utilities import I18N

# If you want to run a snippet of code before or after the crew starts, 
# you can use the @before_kickoff and @after_kickoff decorators
# https://docs.crewai.com/concepts/crews#example-crew-class-with-decorators


# Initialize the tool for internet searching capabilities
SerperDev_Tool = SerperDevTool(country=watsonxConfig.country, locale=watsonxConfig.locale)

@CrewBase
class FinancialAnalysis():
    """FinancialAnalysis crew"""

    def __init__(self):
        pass

    # Learn more about YAML configuration files here:
    # Agents: https://docs.crewai.com/concepts/agents#yaml-configuration-recommended
    # Tasks: https://docs.crewai.com/concepts/tasks#yaml-configuration-recommended
    
    prompt_file=None
    watsonxConfig.language = os.getenv("LANGUAGE")
    
    if watsonxConfig.language == 'ja':
        agents_config = 'config/agents_jp.yaml'
        tasks_config = 'config/tasks_jp.yaml'

        # Initialize I18N --> Japanese
        prompt_file=watsonxConfig.prompt_file_japanese

    else:
        agents_config = 'config/agents.yaml'
        tasks_config = 'config/tasks.yaml'
        
         # Initialize I18N --> English
        prompt_file=watsonxConfig.prompt_file_english
    
    i18n = I18N(prompt_file=prompt_file)


    @agent
    def financial_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['financial_agent'],
            llm=watsonxConfig.llm_config,
			prompt_file=self.prompt_file,
			i18n=self.i18n,
            max_iter=watsonxConfig.max_iter,
            max_rpm=watsonxConfig.max_rpm,
            verbose=True
        )
    
    # Tasks for Financial Agent
    @task
    def revenue_analysis_task(self) -> Task:
        return Task(
            config=self.tasks_config['revenue_analysis_task'],
            tools=[SerperDev_Tool],
            # async_execution=True,
            verbose=True
        )

    @task
    def financial_ratios_task(self) -> Task:
        return Task(
            config=self.tasks_config['financial_ratios_task'],
            tools=[SerperDev_Tool],
            # async_execution=True,
            verbose=True
        )

    @task
    def funding_and_valuation_task(self) -> Task:
        return Task(
            config=self.tasks_config['funding_and_valuation_task'],
            tools=[SerperDev_Tool],
            # async_execution=True,
            verbose=True
        )

    @task
    def market_trends_task(self) -> Task:
        return Task(
            config=self.tasks_config['market_trends_task'],
            tools=[SerperDev_Tool],
            # async_execution=True,
            verbose=True
        )

    @task
    def competitive_financial_analysis_task(self) -> Task:
        return Task(
            config=self.tasks_config['competitive_financial_analysis_task'],
            tools=[SerperDev_Tool],
            verbose=True
        )

    @crew
    def crew(self) -> Crew:
        """Creates the FinancialAnalysis crew"""
        # To learn how to add knowledge sources to your crew, check out the documentation:
        # https://docs.crewai.com/concepts/knowledge#what-is-knowledge

        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
            # process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
        )
