import requests, os
from jaconv import z2h
from typing import Dict, Any, List, Optional, Union

from html_extraction import HTML_RAG
from utils.milvus import milvus_db
from config import FAQ_COLLECTION_NAME


class build_rag:
    def __init__(self) -> None:
        self.milvus_obj = milvus_db()
        self.html_rag_obj = HTML_RAG()

    def get_bearer_token(self, api_key: str) -> str:
        """
        Get a bearer token from IBM Cloud IAM using the provided
        Watsonx API key.
        """
        token_url: str = os.getenv("IBM_AUTH_ENDPOINT")
        headers: Dict[str, str] = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json"
        }
        data: Dict[str, str] = {
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
            "apikey": api_key
        }

        response = requests.post(token_url, headers=headers, data=data)
        token: Optional[str] = response.json().get('access_token', None)
        if not token:
            raise Exception("Failed to retrieve access token.")
        return token

    def query_rag(
        self,
        question: str,
        use_faq: bool,
        use_docs: bool
    ) -> Union[Dict[str, Any], str, None]:
        """
        Query the RAG system using FAQ and/or document sources.

        Args:
            question: The user's question
            use_faq: Whether to use FAQ collection
            use_docs: Whether to use document collection

        Returns:
            Dictionary with answer and metadata, error string, or None
        """
        try:
            question = z2h(question.strip(), kana=True, digit=True, ascii=True)

            if use_docs and not use_faq:
                chunks: Union[List[Dict[str, Any]], Dict[str, Any]] = self.html_rag_obj.QandA(question)
                # generate answer with sources
                result: Dict[str, Any] = self.html_rag_obj.generate_answer_with_sources(
                    query=question,
                    doc_results=chunks if isinstance(chunks, list) else []
                )
                return result

            elif use_faq and not use_docs:
                faq_hit: List[Dict[str, Any]] = self.milvus_obj.query_faq_milvus(question, FAQ_COLLECTION_NAME)
                print("faq hit is:", faq_hit)

                if faq_hit:
                    best_hit: Dict[str, Any] = faq_hit[0]  # get first match from list

                    matched_question: str = best_hit.get("question", "")
                    answer: str = best_hit.get("answer", "")
                    score: float = best_hit.get("score", 0.0)
                    source: Optional[str] = best_hit.get("source")
                    file_path: Optional[str] = best_hit.get("file_path")

                    if not answer:
                        answer = "（FAQに回答が見つかりませんでした）"
                    print(f"[FAQ Score] {score:.3f} for: {matched_question}")

                    if score >= 0.8:  # cosine similarity threshold
                        print(f"よくある質問より:\n\nQ: {matched_question}\nA: {answer}")
                        return {
                            "question": matched_question,
                            "answer": answer,
                            "source": source,
                            "file_path": file_path
                        }
                    else:
                        return "⚠️ よくある質問に類似するものが見つかりませんでした。"
                else:
                    return "⚠️ よくある質問に関連情報が見つかりませんでした。"

            elif use_docs and use_faq:
                # Get chunks from both sources
                faq_chunks = self.milvus_obj.query_faq_milvus(question,
                                                              FAQ_COLLECTION_NAME)
                faq_result: Optional[Dict[str, Any]] = None
                if faq_chunks:
                    faq_result = faq_chunks[0]  # get first match from list

                docs_chunks: Union[List[Dict[str, Any]], Dict[str, Any]] = self.html_rag_obj.QandA(question)

                # Fix the debug print - it was using faq_chunks length twice
                faq_count = 1 if faq_result else 0
                docs_count = len(docs_chunks) if isinstance(docs_chunks, list) else 0
                print(f"Retrieved {faq_count} FAQ chunks and {docs_count} document chunks")

                result = self.html_rag_obj.generate_answer_with_sources(
                    query=question,
                    faq_results=faq_result,
                    doc_results=docs_chunks if isinstance(docs_chunks, list) else []
                )
                return result

        except Exception as e:
            print("Failed to answer:", str(e))
            return None
