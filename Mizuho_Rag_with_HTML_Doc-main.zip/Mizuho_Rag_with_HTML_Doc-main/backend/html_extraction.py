from bs4 import BeautifulSoup, Comment
import hashlib, re, glob, os, json
from urllib.parse import urljoin
from tqdm import tqdm
import numpy as np
from typing import List, Dict, Any, Optional, Union, Tuple

# For semantic chunking
from langchain_text_splitters import RecursiveCharacterTextSplitter

from pymilvus import utility, Collection

# for watsonx.ai
from ibm_watsonx_ai import Credentials
from ibm_watsonx_ai.foundation_models import ModelInference
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams
from sentence_transformers import SentenceTransformer

from hybrid_retriever import HybridSearchRetriever
from reranker import CrossEncoderReranker
from utils.milvus import milvus_db
from config import (
    WATSONX_APIKEY, WATSONX_PROJECTID, WATSONX_URL,
    HTML_EMBEDDING_MODEL_NAME, HTML_EMBEDDING_MODEL_DIMENSION,
    WATSONX_LLM_MODEL, HTML_TOP_K, HTML_COLLECTION_NAME
)


class HTML_RAG:
    embedding_model: str
    embedding_dimensions: int

    def __init__(self) -> None:
        self.embedding_model = HTML_EMBEDDING_MODEL_NAME
        self.embedding_dimensions = int(HTML_EMBEDDING_MODEL_DIMENSION)

    def process_html_document(
        self, 
        html_content: str, 
        url: Optional[str] = None, 
        file_path: Optional[str] = None
    ) -> Union[List[Dict[str, str]], Dict[str, Any]]:
        """Process HTML content and extract structured data with source attribution"""
        try:
            soup: BeautifulSoup = BeautifulSoup(html_content, 'html.parser')

            # Remove script, style elements and comments
            for element in soup(["script", "style"]):
                element.decompose()

            comments: List[Comment] = soup.find_all(string=lambda text: isinstance(text, Comment))

            for comment in comments:
                comment.extract()

            # Extract structured content with metadata
            document_parts: List[Dict[str, str]] = []

            # Use filename as a fallback source identifier
            source_identifier: Optional[str] = url
            if not source_identifier and file_path:
                source_identifier = os.path.basename(file_path)

            # Process headings & content
            for heading in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
                heading_text: str = heading.get_text(strip=True)
                heading_id: str = heading.get('id', '')

                # Get content until next heading
                content: List[str] = []
                for sibling in heading.next_siblings:
                    if sibling.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                        break
                    if sibling.name and sibling.get_text(strip=True):
                        content.append(sibling.get_text(strip=True))

                if content:
                    content_text: str = ' '.join(content)
                    source_id: str = f"{heading_id}" if heading_id else hashlib.md5(heading_text.encode()).hexdigest()
                    source_link: str = urljoin(url, f"#{heading_id}") if url and heading_id else source_identifier or ""

                    document_parts.append({
                        "heading": heading_text,
                        "content": content_text,
                        "source_id": source_id,
                        "source_url": source_link,
                        "html_tag": heading.name,
                        "file_path": file_path or ""
                    })

            # Process content not under heading
            main_content = soup.find('main') or soup.find('body')
            if main_content:
                paragraphs = main_content.find_all(['p', 'div', 'section', 'article'])
                for p in paragraphs:
                    p_text: str = p.get_text(strip=True)
                    if p.parent.name not in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] and p.get_text(strip=True):
                        if p.get('id'):
                            p_id: str = p.get('id')
                        else:
                            p_id = hashlib.md5(p_text.encode()).hexdigest()[:50]
                        source_link = urljoin(url, f"#{p_id}") if url and p.get('id') else source_identifier or ""
   
                        document_parts.append({
                            "heading": "",
                            "content": p.get_text(strip=True),
                            "source_id": p_id,
                            "source_url": source_link,
                            "html_tag": p.name,
                            "file_path": file_path or ""
                        })

            return document_parts
        except Exception as e:
            print(f"Error processing HTML document: {e}")
            return {"answer": "An error occurred while generating the answer.", "source": [], "error": str(e)}

    def semantic_chunk_document(
        self, 
        document_parts: List[Dict[str, str]], 
        chunk_size: int = 1000, 
        chunk_overlap: int = 100
    ) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
        """Use LangChain's semantic chunking for better content division"""
        try:
            text_splitter: RecursiveCharacterTextSplitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                length_function=len,
            )

            chunks: List[Dict[str, Any]] = []

            for part in document_parts:
                text: str = part["content"]

                # skip empty content
                if not text.strip():
                    continue
                # split text into chunks
                texts: List[str] = text_splitter.split_text(text)

                for chunk_text in texts:
                    chunks.append({
                        "text": str(chunk_text),
                        "heading": part["heading"],
                        "source_id": part["source_id"],
                        "source_url": part["source_url"],
                        "file_path": part.get("file_path", ""),
                        "char_count": len(chunk_text)
                    })

            return chunks

        except Exception as e:
            print(f"Error during chunking HTML document: {e}")
            return {
                "answer": "An error occurred while generating the answer.",
                "source": [],
                "error": str(e)
            }

    def get_watsonx_embeddings(self, texts: List[str]) -> Optional[List[List[float]]]:
        """Get embeddings from watsonx.ai"""
        try:
            embeddings: List[List[float]] = []
            batch_size: int = 50

            model: SentenceTransformer = self.get_embedding_model()

            for i in range(0, len(texts), batch_size):
                batch_texts: List[str] = texts[i:i+batch_size]
                batch_embeddings: List[List[float]] = []

                for text in batch_texts:
                    result = model.encode(text)
                    if 'embeddings' in result and result['embeddings']:
                        batch_embeddings.append(result['embeddings'][0])
                    else:
                        # Fallback to zero vector if embedding fails
                        batch_embeddings.append([0.0] * 1024)  # dimension of embedding model used

                embeddings.extend(batch_embeddings)
            return embeddings
        except Exception as e:
            print(f"Error in get_watsonx_embedding: {e}")
            return None

    def watsonx_llm(self) -> Optional[ModelInference]:
        """Initialize watsonx.AI LLM"""
        try:
            model_params: Dict[str, Any] = {
                GenParams.DECODING_METHOD: "sample",
                GenParams.MAX_NEW_TOKENS: 4000,
                GenParams.MIN_NEW_TOKENS: 0,
                GenParams.TEMPERATURE: 0.4,
                GenParams.TOP_P: 1.0,
                GenParams.TOP_K: 50
            }
            
            credentials: Credentials = Credentials(url=WATSONX_URL, api_key=WATSONX_APIKEY)

            llm: ModelInference = ModelInference(
                model_id=WATSONX_LLM_MODEL,
                params=model_params,
                credentials=credentials,
                project_id=WATSONX_PROJECTID,
            )
            return llm
        except Exception as e:
            print(f"Error in initializing LLM: {e}")
            return None

    def get_embedding_model(self) -> Union[SentenceTransformer, str]:
        """Get the embedding model instance"""
        try:
            embedding_model: SentenceTransformer = SentenceTransformer(self.embedding_model)
            return embedding_model
        except Exception as e:
            return f"Error while initializing the embedding model: {e}"
    
    def generate_answer_with_sources(
        self, 
        query: str, 
        faq_results: Optional[Union[List[Dict[str, Any]], Dict[str, Any]]] = None, 
        doc_results: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """Generate answer with source attribution using WatsonX.AI for document-only and combined scenarios"""
        try:
            llm: Optional[ModelInference] = self.watsonx_llm()

            if not faq_results and not doc_results:
                return {
                    "query": query,
                    "answer": "関連する情報が見つかりませんでした。",
                    "source": "",
                    "file_path": ""
                }

            context_parts: List[str] = []
            sources: List[str] = []
            file_paths: List[str] = []

            # Process FAQ results
            if faq_results:
                if isinstance(faq_results, list):
                    for i, faq in enumerate(faq_results):
                        if isinstance(faq, dict):
                            faq_question: str = faq.get("question", "")
                            faq_answer: str = faq.get("answer", "")
                            if faq_question and faq_answer:
                                context_parts.append(f"FAQ {i+1}:\nQ: {faq_question}\nA: {faq_answer}")
                                if "FAQ" not in sources:
                                    sources.append("FAQ")
                elif isinstance(faq_results, dict):
                    faq_question = faq_results.get("question", "")
                    faq_answer = faq_results.get("answer", "")
                    if faq_question and faq_answer:
                        context_parts.append(f"FAQ:\nQ: {faq_question}\nA: {faq_answer}")
                        sources.append("FAQ")

            # Process document results
            if doc_results:
                if not isinstance(doc_results, list):
                    print(f"Expected list for doc_results but got {type(doc_results)}: {doc_results}")
                    doc_results = []

                for i, result in enumerate(doc_results):
                    if not isinstance(result, dict):
                        print(f"Invalid doc result at index {i}: {result} (type: {type(result)})")
                        continue

                    text_content: str = result.get("text", "")
                    heading: str = result.get("heading", "")
                    source_url: str = result.get("source_url", "")
                    file_path: str = result.get("file_path", "")

                    if text_content:
                        doc_info: str = f"Document {i+1}:"
                        if heading:
                            doc_info += f"\nHeading: {heading}"
                        if source_url:
                            doc_info += f"\nSource URL: {source_url}"
                        if file_path:
                            doc_info += f"\nFile Path: {file_path}"
                        doc_info += f"\nContent: {text_content}"
                        context_parts.append(doc_info)

                        if source_url and source_url not in sources:
                            sources.append(source_url)
                        if file_path and file_path not in file_paths:
                            file_paths.append(file_path)

            if not context_parts:
                return {
                    "query": query,
                    "answer": "関連する情報が見つかりませんでした。",
                    "source": "",
                    "file_path": ""
                }

            context: str = "\n\n".join(context_parts)

            # Prompt setup
            common_prompt_input: str = """You are an AI assistant that answers questions accurately based on the context provided below.

                                    [Instructions]:
                                    1. Use only the information contained in the context below when providing your answer.
                                    2. Consider information from both the FAQ and the document to provide the most appropriate and comprehensive answer.
                                    3. If the answer cannot be derived from the context, clearly state that.
                                    4. Return your response as a valid JSON object containing only the three keys: \"query\", \"answer\", \"source\" and \"file_path\".
                                    5. Do not include any explanations or formatting other than the JSON.
                                    6. Write your output in Japanese."""

            prompt_output: str = f"""[Output]:
                            If the answer is derived, follow below format:
                            ```
                            {{
                            \"query\": \"{query}\",
                            \"answer\": \"Provide a concise answer in Japanese here\",
                            \"source\": \"Relevant source_url\",
                            \"file_path\": \"Relevant file_path\"
                            }}
                            ```

                            If the answer cannot be derived from the context, respond in the following format:
                            ```
                            {{
                            \"query\": \"{query}\",
                            \"answer\": \"回答に必要な情報が不足しています。\",
                            \"source\": \"\",
                            \"file_path\": \"\"
                            }}
                            ```

                            [Answer]:
                            """

            prompt: str = f"""{common_prompt_input}

                            [Input]:
                            Context: {context}
                            Sources: {', '.join(sources)}
                            File Paths: {', '.join(file_paths)}
                            Question: {query}

                            {prompt_output}
                            """

            # Call the LLM
            if llm is None:
                return {
                    "query": query,
                    "answer": "LLMの初期化に失敗しました。",
                    "source": "",
                    "file_path": ""
                }

            response: str = llm.generate_text(prompt)

            # Parse the LLM response safely
            extracted_data: Dict[str, Any] = {
                "query": query,
                "answer": "フォーマットされた回答が取得できませんでした。",
                "source": "",
                "file_path": ""
            }

            # json extraction logic
            pattern = re.compile(
                r'\{\s*"query":\s*(.+?)\s*"answer":\s*(.+?)\s*"source":\s*(.+?)\s*"file_path":\s*(.+?)\s*\}',
                re.DOTALL)
        
            for match in pattern.finditer(response):
                # Clean up and store values
                extracted_data = {
                    "query": query,
                    "answer": match.group(2).strip().replace('"',''),
                    "source": match.group(3).strip().strip('"').replace('"', '').replace(',', ''),
                    "file_path": match.group(4).strip().strip('"').replace('"', '').replace(',', '')
                }

            print(extracted_data)
            return extracted_data

        except Exception as e:
            print(f"Error in generate_answer_with_sources method: {e}")
            print(f"FAQ results type: {type(faq_results)}")
            print(f"Doc results type: {type(doc_results)}")

            return {
                "query": query,
                "answer": "An error occurred while generating the answer.",
                "source": "",
                "file_path": "",
                "error": str(e)
            }
        
    def build_html_rag_system(self, html_folder: str, collection_name: str, override: bool) -> None:
        """Build complete RAG system from folder of HTML files"""
        try:
            # Check if the collection already exists.
            if (not utility.has_collection(collection_name)) or override:
                milvus_obj: milvus_db = milvus_db()

                # Setup milvus
                print("Setting up Milvus collection...")
                collection: Collection = milvus_obj.create_milvus_html_collection(collection_name, self.embedding_dimensions)

                # process HTML files
                html_files: List[str] = glob.glob(os.path.join(html_folder, "**/*.html"), recursive=True)
                print(f"Found {len(html_files)} HTML files")

                all_chunks: List[Dict[str, Any]] = []

                # process each HTML file
                for file_path in tqdm(html_files, desc="Processing HTML files"):
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            html_content: str = f.read()
                        
                        # process html
                        document_parts = self.process_html_document(html_content, file_path=file_path)
                        
                        # Skip if document_parts is an error dict
                        if isinstance(document_parts, dict) and "error" in document_parts:
                            print(f"Skipping {file_path} due to processing error")
                            continue

                        # chunk document
                        chunks = self.semantic_chunk_document(document_parts)
                        
                        # Skip if chunks is an error dict
                        if isinstance(chunks, dict) and "error" in chunks:
                            print(f"Skipping {file_path} due to chunking error")
                            continue

                        # Normalize text fields to strings
                        for chunk in chunks:
                            if isinstance(chunk["text"], list):
                                chunk["text"] = " ".join(chunk["text"])
                            elif not isinstance(chunk["text"], str):
                                chunk["text"] = str(chunk["text"])

                        all_chunks.extend(chunks)

                        # process in batches to avoid memory issues
                        if len(all_chunks) >= 100:
                            # get embeddings
                            texts: List[str] = [chunk["text"] for chunk in all_chunks]
                            embeddings: Optional[List[List[float]]] = self.get_watsonx_embeddings(texts)
                            if embeddings:
                                milvus_obj.insert_into_html_milvus(collection, all_chunks, embeddings)
                            all_chunks = []  # Reset for next batch
                    except Exception as e:
                        print(f"Error processing {file_path}: {e}")
                        
                # process remaining chunks
                if all_chunks:
                    texts = [chunk["text"] for chunk in all_chunks]
                    embeddings = self.get_watsonx_embeddings(texts)
                    if embeddings:
                        milvus_obj.insert_into_html_milvus(collection, all_chunks, embeddings)
                print(f"HTML collection {collection_name} created successfully.")
            else:
                print(f"Collection {collection_name} already exists!")

            print("RAG system built successfully!")
        except Exception as e:
            print(f"Error in build_html_rag_system method: {e}")
            raise e
        
    def QandA(self, query: str, top_k: int = HTML_TOP_K) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
        """Answer question using the RAG system"""
        try:
            embedding_model = self.get_embedding_model()
            if isinstance(embedding_model, str):
                return {
                    "answer": "Embedding model initialization failed.",
                    "sources": [],
                    "error": embedding_model
                }

            retriever: HybridSearchRetriever = HybridSearchRetriever(HTML_COLLECTION_NAME, embedding_model=embedding_model)
            retrieved_docs = retriever.retrieve(query, top_k)

            # Check if retriever returned an error string
            if isinstance(retrieved_docs, str):
                print(f"Retriever error: {retrieved_docs}")
                return {
                    "answer": "An error occurred during document retrieval.",
                    "sources": [],
                    "error": retrieved_docs
                }
            
            # Ensure retrieved_docs is a list
            if not isinstance(retrieved_docs, list):
                print(f"Unexpected retriever result type: {type(retrieved_docs)}")
                return {
                    "answer": "Invalid retrieval results format.",
                    "sources": [],
                    "error": f"Expected list, got {type(retrieved_docs)}"
                }

            reranker: CrossEncoderReranker = CrossEncoderReranker()
            reranked_docs = reranker.rerank(query, retrieved_docs) if retrieved_docs else []

            # Check if reranker returned an error string
            if isinstance(reranked_docs, str):
                print(f"Reranker error: {reranked_docs}")
                # Fall back to original retrieved docs if reranking fails
                reranked_docs = retrieved_docs if isinstance(retrieved_docs, list) else []
            
            return reranked_docs
            
        except Exception as e:
            print(f"Error getting document chunks: {e}")
            return []
        
    def convert_np(self, obj: Any) -> float:
        """Convert np.float64 to float for JSON serialization"""
        if isinstance(obj, np.float64):
            return float(obj)
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
