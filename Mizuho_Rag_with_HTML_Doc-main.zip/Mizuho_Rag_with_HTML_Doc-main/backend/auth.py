from __future__ import annotations

import secrets
from typing import Dict

from fastapi import Response, Request, HTTPException
from config import USERNAME, PASSWORD

SESSION_COOKIE_NAME: str = "session_id"
VALID_SESSIONS: Dict[str, str] = {}


def login_user(data: Dict[str, str], response: Response) -> Dict[str, str]:
    if data["username"] == USERNAME and data["password"] == PASSWORD:
        session_id: str = secrets.token_hex(16)
        VALID_SESSIONS[session_id] = data["username"]
        response.set_cookie(
            key=SESSION_COOKIE_NAME,
            value=session_id,
            httponly=True,
            samesite="Lax",
            secure=False,            # → set True in production
        )
        return {"message": "ログイン成功"}
    raise HTTPException(status_code=401, detail="Invalid credentials")


def logout_user(response: Response, request: Request) -> Dict[str, str]:
    session_id: str | None = request.cookies.get(SESSION_COOKIE_NAME)
    if session_id:
        VALID_SESSIONS.pop(session_id, None)
        response.delete_cookie(SESSION_COOKIE_NAME)
    return {"message": "ログアウト成功"}


def get_current_user(request: Request) -> str:
    session_id: str | None = request.cookies.get(SESSION_COOKIE_NAME)
    if session_id in VALID_SESSIONS:
        return VALID_SESSIONS[session_id]
    raise HTTPException(status_code=401, detail="認証されていません")
