import os
import time
from typing import Optional
from dotenv import load_dotenv
from pymilvus import utility, connections
from pymilvus.exceptions import MilvusException

load_dotenv()

# Environment variables with type hints
WATSONX_APIKEY: Optional[str] = os.getenv("WATSONX_APIKEY")
WATSONX_PROJECTID: Optional[str] = os.getenv("WATSONX_PROJECTID")
WATSONX_URL: Optional[str] = os.getenv("WATSONX_URL")

SECRET_KEY: str = os.getenv("SECRET_KEY", "defaultsecret")
USERNAME: str = os.getenv("USERNAME", "admin")
PASSWORD: str = os.getenv("PASSWORD", "password123")

WATSONX_LLM_MODEL: str = "mistralai/mistral-medium-2505"

HTML_EMBEDDING_MODEL_NAME: str = "intfloat/multilingual-e5-large"
HTML_EMBEDDING_MODEL_DIMENSION: int = 1024
RERANKER_MODEL: str = "BAAI/bge-reranker-large"

FAQ_EMBEDDING_MODEL_NAME: str = "intfloat/multilingual-e5-large"
FAQ_EMBEDDING_MODEL_DIMENSION: int = 1024

MILVUS_PORT: Optional[str] = os.getenv("MILVUS_PORT")
MILVUS_PEM_PATH: Optional[str] = os.getenv("MILVUS_PEM_PATH")
MILVUS_HOST: Optional[str] = os.getenv("MILVUS_HOST")
MILVUS_USERNAME: Optional[str] = os.getenv("MILVUS_USERNAME")
MILVUS_PASSWORD: Optional[str] = os.getenv("MILVUS_PASSWORD")

CERT_LOCAL_PATH: str = 'presto.crt'

# Default system folders
HTML_FOLDER: str = "data/html_docs"
HTML_COLLECTION_NAME: str = "mizuho_html_docs"
HTML_TOP_K: int = 5

FAQ_FOLDER: str = "data/faq_docs"
FAQ_COLLECTION_NAME: str = "mizuho_faq_collection"

# Allowed file extensions
ALLOWED_HTML_EXTENSIONS: list[str] = ['.html', '.htm']
ALLOWED_FAQ_EXTENSIONS: list[str] = ['.csv']  # Only CSV files allowed for FAQ

# Dynamic folder paths (can be updated via endpoints)
_current_html_folder: str = HTML_FOLDER
_current_faq_folder: str = FAQ_FOLDER


def set_html_folder_path(folder_path: str) -> None:
    """Set the current HTML folder path"""
    global _current_html_folder
    _current_html_folder = folder_path


def get_html_folder_path() -> str:
    """Get the current HTML folder path"""
    return _current_html_folder


def set_faq_folder_path(folder_path: str) -> None:
    """Set the current FAQ folder path"""
    global _current_faq_folder
    _current_faq_folder = folder_path


def get_faq_folder_path() -> str:
    """Get the current FAQ folder path"""
    return _current_faq_folder


def connect_to_milvus(
        max_retries: int = 3,
        retry_delay: int = 3,
        backoff_factor: float = 1.5
) -> bool:
    """
    Establish connection to Milvus with retry logic

    Args:
        max_retries (int): Maximum number of connection attempts
        retry_delay (int): Initial delay between retries in seconds
        backoff_factor (float): Multiplier for delay after each failed attempt
        
    Returns:
        bool: True if connection successful, raises exception if all attempts fail
    """
    current_delay: float = retry_delay
    last_exception: Optional[Exception] = None

    for attempt in range(max_retries):
        try:
            # Add delay before retry attempts (not before first attempt)
            if attempt > 0:
                print(f"Waiting {current_delay} seconds before retry...")
                time.sleep(current_delay)
                current_delay *= backoff_factor  # Exponential backoff

            print(f"Connection attempt {attempt + 1}/{max_retries}")
            print(f"Connecting to: {MILVUS_HOST}:{MILVUS_PORT}")

            # Attempt connection
            connections.connect(
                alias="default",
                host=MILVUS_HOST,
                port=MILVUS_PORT,
                user=MILVUS_USERNAME,
                password=MILVUS_PASSWORD,
                server_pem_path=MILVUS_PEM_PATH,
                server_name=MILVUS_HOST,  # Use actual hostname instead of localhost
                secure=True
            )

            # Test the connection by listing collections
            collections: list[str] = utility.list_collections()
            print("Successfully connected to Milvus")
            print(f"Available collections: {collections}")

            return True

        except MilvusException as e:
            print(f"Milvus connection failed (attempt {attempt + 1}): {e}")
            last_exception = e

        except Exception as e:
            print(f"Unexpected error (attempt {attempt + 1}): {e}")
            last_exception = e

    # If we get here, all attempts failed
    print(f"All {max_retries} connection attempts failed")
    print("Please check:")
    print("Network connectivity to the Milvus server")
    print("Firewall settings (port 26719)")
    print("Username and password credentials")
    print("SSL certificate path and validity")
    if last_exception:
        raise last_exception
    # This should never be reached, but included for completeness
    return False
