from qa_chain import build_rag
from typing import Dict, Any, Union


class call_rag:
    build_rag_obj: build_rag

    def __init__(self) -> None:
        self.build_rag_obj = build_rag()

    def handle_question(
        self,
        question: str,
        use_faq: bool,
        use_docs: bool
    ) -> Union[Dict[str, Any], str, None]:
        """
        Handle user questions by routing to the appropriate RAG system.

        Args:
            question: The user's question string
            use_faq: Whether to use FAQ collection for answers
            use_docs: Whether to use document collection for answers

        Returns:
            Dictionary with answer and metadata, error string, or None
        """
        if not question.strip():
            return {"answer": "質問を入力してください。"}

        if not use_faq and not use_docs:
            return {"answer": "データソースを選択してください。"}

        answer = self.build_rag_obj.query_rag(
            question, 
            use_faq=use_faq, 
            use_docs=use_docs
        )
        return answer
