import os
from sentence_transformers import CrossEncoder
from typing import List, Dict, Any, Tuple, Union

from config import RERANKER_MODEL


class CrossEncoderReranker:
    reranker: CrossEncoder
    
    def __init__(self) -> None:
        """Initialize CrossEncoder reranker"""
        self.reranker = CrossEncoder(RERANKER_MODEL)
    
    def rerank(
        self, 
        query: str, 
        results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Rerank results using CrossEncoder model.
        
        Args:
            query: The search query string
            results: List of result dictionaries containing 'text' field
            
        Returns:
            List of reranked results with added 'rerank_score' field
        """
        try:
            if not results:
                print("Results are empty in Reranker")
                return []  # Return empty list instead of string
            
            # Validate that results is a list and contains dictionaries
            if not isinstance(results, list):
                print(f"Expected list but got {type(results)}: {results}")
                return []
            
            # Filter out any non-dict items and validate structure
            valid_results: List[Dict[str, Any]] = []
            for i, result in enumerate(results):
                if isinstance(result, dict) and "text" in result:
                    valid_results.append(result)
                else:
                    print(f"Invalid result at index {i}: {result}")
            
            if not valid_results:
                print("No valid results found for reranking")
                return []
            
            # prepare pairs for reranking
            pairs: List[Tuple[str, str]] = [
                (query, result["text"]) for result in valid_results
            ]

            # get scores from CrossEncoder
            scores: List[float] = self.reranker.predict(pairs)

            # add scores to results
            for i, score in enumerate(scores):
                valid_results[i]["rerank_score"] = float(score)

            # sort by reranker score (descending)
            reranked_results: List[Dict[str, Any]] = sorted(
                valid_results, 
                key=lambda x: x["rerank_score"], 
                reverse=True
            )
            return reranked_results
            
        except Exception as e:
            print(f"Error while reranking: {e}")
            # Return the original results if reranking fails, or empty list if results is invalid
            if isinstance(results, list):
                return results
            else:
                return []
