import numpy as np
from rank_bm25 import BM25Okapi
import fugashi
from utils.milvus import milvus_db
from typing import Any, List, Dict, Optional, Union, Sequence, Tuple

class HybridSearchRetriever:
    def __init__(
        self,
        collection_name: str,
        embedding_model: Any,
        vector_weight: float = 0.7,
        top_k: int = 5
    ) -> None:
        """Initialize hybrid search retriever with Milvus and BM25."""
        self.milvus_obj: milvus_db = milvus_db()
        self.collection = self.milvus_obj.load_html_collection(collection_name)
        self.embedding_model: Any = embedding_model
        self.vector_weight: float = vector_weight
        self.bm25_weight: float = 1 - vector_weight
        self.top_k: int = top_k

        # prepare corpus for BM25
        self.collection.flush()
        results: List[Dict[str, Any]] = self.collection.query(
            expr="id>0",
            output_fields=["text", "id"]
        )
        self.corpus: List[str] = [doc["text"] for doc in results]
        self.doc_ids: List[Any] = [doc["id"] for doc in results]
        tokenized_corpus: List[List[str]] = [
            self.tokenize_japanese(doc) for doc in self.corpus
        ]
        self.bm25: BM25Okapi = BM25Okapi(tokenized_corpus)

    def flatten_id(self, doc_id: Union[str, List[Any], Tuple[Any, ...]]
                  ) -> Union[str, Tuple[Any, ...]]:
        """Flatten single-element lists to scalars, convert longer lists to tuples."""
        while isinstance(doc_id, list) and len(doc_id) == 1:
            doc_id = doc_id[0]
        if isinstance(doc_id, list):
            doc_id = tuple(doc_id)
        return doc_id

    def get_embeddings(self, texts: Sequence[str]
                       ) -> Optional[List[List[float]]]:
        """Get embeddings using the embedding model."""
        try:
            embeddings: List[List[float]] = []
            batch_size: int = 50
            for i in range(0, len(texts), batch_size):
                batch_texts: Sequence[str] = texts[i : i + batch_size]
                for text in batch_texts:
                    result = self.embedding_model.encode(text)
                    if hasattr(result, "tolist"):
                        embeddings.append(result.tolist())
                    else:
                        embeddings.append(result)  # assume list[float]
            return embeddings
        except Exception as e:
            print(f"Error in get_embeddings: {e}")
            return None

    def tokenize_japanese(self, text: str) -> List[str]:
        """Tokenize Japanese text with fugashi."""
        tokenizer: fugashi.Tagger = fugashi.Tagger()
        return [word.surface for word in tokenizer(text)]

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None
    ) -> Union[List[Dict[str, Any]], str]:
        """Retrieve documents using hybrid search (vector + BM25)."""
        try:
            if top_k is None:
                top_k = self.top_k

            # Vector search
            emb_list = self.get_embeddings([query])
            if not emb_list:
                return []
            query_embedding: List[float] = emb_list[0]
            vector_search_params: Dict[str, Any] = {
                "metric_type": "L2",
                "params": {"nprobe": 10},
            }
            vector_results = self.collection.search(
                data=[query_embedding],
                anns_field="embeddings",
                param=vector_search_params,
                limit=top_k,
                output_fields=[
                    "text", "heading", "source_id", "source_url", "file_path"
                ]
            )

            # BM25 search
            tokenized_query: List[str] = self.tokenize_japanese(query)
            bm25_scores = self.bm25.get_scores(tokenized_query)
            top_bm25_indices = np.argsort(bm25_scores)[::-1][:top_k]
            top_bm25_ids: List[Any] = [self.doc_ids[i] for i in top_bm25_indices]
            bm25_results: List[Dict[str, Any]] = self.collection.query(
                expr=f"id in {top_bm25_ids}",
                output_fields=[
                    "id", "text", "heading", "source_id", "source_url", "file_path"
                ]
            )

            # Combine results
            combined: Dict[Any, Dict[str, Any]] = {}
            for hit in vector_results[0]:
                did = self.flatten_id(hit.id)
                combined[did] = {
                    "text": hit.entity.get("text"),
                    "heading": hit.entity.get("heading"),
                    "source_id": hit.entity.get("source_id"),
                    "source_url": hit.entity.get("source_url"),
                    "file_path": hit.entity.get("file_path"),
                    "score": hit.score * self.vector_weight
                }

            for idx, doc in enumerate(bm25_results):
                did = self.flatten_id(doc["id"])
                bm25_score: float = float(bm25_scores[top_bm25_indices[idx]])
                if did in combined:
                    combined[did]["score"] += bm25_score * self.bm25_weight
                else:
                    combined[did] = {
                        "text": doc["text"],
                        "heading": doc["heading"],
                        "source_id": doc["source_id"],
                        "source_url": doc["source_url"],
                        "file_path": doc["file_path"],
                        "score": bm25_score * self.bm25_weight
                    }

            sorted_results: List[Dict[str, Any]] = sorted(
                combined.values(),
                key=lambda x: x["score"],
                reverse=True
            )
            return sorted_results[:top_k]
        except Exception as e:
            print(f"Error in hybrid search: {e}")
            return f"Error in hybrid search: {e}"
