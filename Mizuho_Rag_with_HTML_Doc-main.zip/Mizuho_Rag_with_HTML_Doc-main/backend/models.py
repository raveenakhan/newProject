from pydantic import BaseModel


class LoginRequest(BaseModel):
    username: str
    password: str


class QuestionRequest(BaseModel):
    question: str
    use_faq: bool = False
    use_docs: bool = True


class CreateCollectionRequest(BaseModel):
    folder_path: str


class FilePathRequest(BaseModel):
    path: str
