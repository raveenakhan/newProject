from typing import List, Dict, Any, Optional, AsyncIterator
from pymilvus import utility, connections
import os
import shutil
import zipfile
import uvicorn
import asyncio
from pathlib import Path
from fastapi import (
    FastAPI, Request, Response, Depends, HTTPException,
    UploadFile, File, Form
)
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from auth import login_user, logout_user, get_current_user
from rag_chain import call_rag
from models import LoginRequest, QuestionRequest, FilePathRequest
from utils.milvus import milvus_db
from utils.helper import helper
from html_extraction import HTML_RAG
from config import (
    FAQ_COLLECTION_NAME, FAQ_FOLDER, HTML_COLLECTION_NAME, HTML_FOLDER,
    MILVUS_PEM_PATH, set_html_folder_path, set_faq_folder_path,
    connect_to_milvus
)

# ──────────────────────────────
# FastAPI lifespan with Milvus connection
# ──────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Enhanced lifespan for Code Engine deployment"""
    print("Starting application lifespan…")
    try:
        # Download Presto cert with retry logic
        max_retries = 3
        for attempt in range(max_retries):
            try:
                helper().fetch_presto_cert()
                break
            except Exception as e:
                if attempt == max_retries - 1:
                    print(f"Failed to fetch certificate after {max_retries} attempts: {e}")
                    app.state.milvus_connected = False
                    app.state.milvus_alias = None  # Set to None on failure
                    yield
                    return
                print(f"Certificate fetch attempt {attempt + 1} failed, retrying...")
                await asyncio.sleep(2)
        
        # Establish Milvus connection
        print("Establishing Milvus connection...")
        connect_to_milvus()
        app.state.milvus_connected = True
        app.state.milvus_alias = "default"  # Set the alias here
        
        # Initialize collections
        await initialize_collections()
        print("Collections initialized successfully")
        
    except Exception as exc:
        print(f"Startup error: {exc!r}")
        app.state.milvus_connected = False
        app.state.milvus_alias = None  # Set to None on failure
    
    yield
    
    # Cleanup
    try:
        connections.disconnect("default")
        app.state.milvus_connected = False
        app.state.milvus_alias = None  # Clear alias on shutdown
        print("Milvus connection closed successfully")
    except Exception as e:
        print(f"Error closing Milvus connection: {e}")

app: FastAPI = FastAPI(lifespan=lifespan)

# Dependency to check Milvus connection
def get_milvus_connection(request: Request):
    """Dependency to ensure Milvus connection is available"""
    if not getattr(request.app.state, 'milvus_connected', False):
        raise HTTPException(
            status_code=503, 
            detail="Milvus connection not available"
        )
    # Return the alias
    return getattr(request.app.state, 'milvus_alias')

# ──────────────────────────────
# CORS – explicit origins only
# ──────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "https://mizuho-rag-frontend.1y5k0z9wus7p.us-south.codeengine.appdomain.cloud",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ──────────────────────────────
# Collection initialisation
# ──────────────────────────────

def initialize_faq_collection(folder_path: str, override: bool) -> None:
    """Create / populate the FAQ collection in Milvus."""
    try:
        print(f"Initializing FAQ collection with folder «{folder_path}»")
        if not utility.has_collection(collection_name=FAQ_COLLECTION_NAME) or override:
            milvus = milvus_db()
            milvus.create_milvus_faq_collection(coll_name=FAQ_COLLECTION_NAME)
            faq_docs: List[Dict[str, Any]] = milvus.load_faq_csv(folder_path)
            milvus.insert_in_faq_collection(coll_name=FAQ_COLLECTION_NAME, docs=faq_docs)
            print(f"FAQ collection «{FAQ_COLLECTION_NAME}» created and populated")
        else:
            print(f"Collection «{FAQ_COLLECTION_NAME}» already exists")
    except Exception as exc:
        print(f"FAQ init error: {exc!r}")
        raise

def initialize_html_collection(html_folder: str, override: bool) -> None:
    """Build the HTML RAG index / collection."""
    try:
        print(f"Initializing HTML collection from «{html_folder}»")
        HTML_RAG().build_html_rag_system(html_folder, HTML_COLLECTION_NAME, override)
        print("HTML RAG system initialized successfully")
    except Exception as exc:
        print(f"HTML init error: {exc!r}")
        raise

async def initialize_collections() -> None:
    """(Re)build both collections using existing connection."""
    print("Initializing FAQ RAG…")
    initialize_faq_collection(FAQ_FOLDER, override=False)
    print("Initializing HTML RAG…")
    initialize_html_collection(HTML_FOLDER, override=False)

# ──────────────────────────────
# Health-check
# ──────────────────────────────

@app.get("/health")
def health_check(request: Request) -> Dict[str, Any]:
    """Return deployment / Milvus status."""
    try:
        milvus_connected = getattr(request.app.state, 'milvus_connected', False)
        collections_list: List[str] = utility.list_collections() if milvus_connected else []
        cert_exists: bool = os.path.isfile(MILVUS_PEM_PATH)
        
        return {
            "status": "healthy" if milvus_connected else "unhealthy",
            "pwd": os.getcwd(),
            "cert_location": MILVUS_PEM_PATH,
            "cert_exists": cert_exists,
            "milvus_connected": milvus_connected,
            "milvus_alias": getattr(request.app.state, 'milvus_alias', None),
            "available_collections": collections_list,
        }
    except Exception as exc:
        print("Health check error:", exc)
        return {
            "status": "unhealthy",
            "error": str(exc),
            "milvus_connected": False,
            "milvus_alias": None,
        }

# ──────────────────────────────
# Auth
# ──────────────────────────────

@app.post("/login")
def login(data: LoginRequest, response: Response) -> Dict[str, Any]:
    """Authenticate user and return token / cookies."""
    try:
        return login_user(data.dict(), response)
    except Exception:
        raise HTTPException(status_code=401, detail="Login failed")

@app.post("/logout")
def logout(request: Request, response: Response) -> Dict[str, str]:
    """Invalidate user session."""
    try:
        return logout_user(response, request)
    except Exception:
        raise HTTPException(status_code=500, detail="Logout failed")

# ──────────────────────────────
# RAG question endpoint
# ──────────────────────────────

@app.post("/question")
def question(
    data: QuestionRequest,
    user: Dict[str, Any] = Depends(get_current_user),
    milvus_alias: str = Depends(get_milvus_connection),
) -> Dict[str, Any]:
    """Answer a question via RAG pipeline."""
    try:
        answer = call_rag().handle_question(data.question, data.use_faq, data.use_docs)
        return answer
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

# ──────────────────────────────
# HTML text retrieval
# ──────────────────────────────

@app.post("/html-text")
def get_html_by_path(payload: FilePathRequest) -> str:
    """Return HTML contents or 'FAQ' sentinel."""
    """Return plain text contents from HTML or 'FAQ' sentinel."""
    try:
        print(payload.path)
        path: str = payload.path.replace('"' , '').replace(',',"")
        print(path)
        # Handle FAQ case
        if path.lower() == "faq":
            return "FAQ"
        
        # Validate file extension
        if not path.lower().endswith((".html", ".htm")):
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        # Handle temporary files (cloud object storage)
        if path.startswith(("/tmp", "tmp/")):
            clean_path = path.replace("/tmp/", "").replace("tmp/", "")
            html_content = helper().get_file_from_cos(path=clean_path)
        else:
            # Security: Validate local file path
            file_path: str = Path(path).resolve()
            if not file_path.exists():
                raise HTTPException(status_code=404, detail="File not found")
            
            # Read local file
            with open(file_path, "r", encoding="utf-8") as file:
                html_content = file.read()
        return html_content
    except HTTPException:
        raise  # Re-raise HTTP exceptions
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"File not found: {path}")
    except PermissionError:
        raise HTTPException(status_code=403, detail=f"Permission denied: {path}")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File encoding error")
    except Exception as exc:
        raise HTTPException(
            status_code=500, detail=f"Error reading file: {exc}")

# ──────────────────────────────
# Upload & create collection
# ──────────────────────────────

@app.post("/create_collection")
async def create_html_collection(
    zip_file: UploadFile = File(...),
    datatype: str = Form(...),
    user: Dict[str, Any] = Depends(get_current_user),
    milvus_alias: str = Depends(get_milvus_connection),
) -> Dict[str, str]:
    """
    Upload a ZIP containing FAQ CSVs or HTML docs, push to COS,
    rebuild respective Milvus collection, and clean up.
    """
    try:
        if datatype not in ("faq", "html"):
            raise HTTPException(status_code=400, detail="datatype must be 'faq' or 'html'")

        temp_dir: str = f"/tmp/{datatype}"
        os.makedirs(temp_dir, exist_ok=True)
        zip_path: str = os.path.join(temp_dir, zip_file.filename)
        
        with open(zip_path, "wb") as fp:
            fp.write(await zip_file.read())

        try:
            with zipfile.ZipFile(zip_path, "r") as archive:
                archive.extractall(temp_dir)
        except zipfile.BadZipFile:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise HTTPException(status_code=400, detail="Invalid ZIP file")

        # Upload to COS
        helper().upload_to_cos(temp_dir, datatype)

        # Re-initialise the relevant Milvus collection
        if datatype == "faq":
            set_faq_folder_path(temp_dir)
            initialize_faq_collection(temp_dir, override=True)
            msg: str = f"FAQ コレクション「{FAQ_COLLECTION_NAME}」が正常に作成されました"
        else:
            set_html_folder_path(temp_dir)
            initialize_html_collection(temp_dir, override=True)
            msg = f"HTML コレクション「{HTML_COLLECTION_NAME}」が正常に作成されました"

        shutil.rmtree(temp_dir, ignore_errors=True)
        return {"message": msg}

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to create {datatype} collection: {exc}")

# ──────────────────────────────
# Entrypoint (dev only)
# ──────────────────────────────

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
