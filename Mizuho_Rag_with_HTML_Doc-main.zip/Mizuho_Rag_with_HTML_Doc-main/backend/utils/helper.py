from dotenv import load_dotenv
import ibm_boto3, os
from ibm_botocore.client import Config
from config import CERT_LOCAL_PATH
from typing import Optional, Dict, List, Any

load_dotenv()


class helper:
    credentials: Dict[str, Optional[str]]
    cos_client: Any

    def __init__(self) -> None:
        self.credentials = {
            'WATSONX_API_KEY':    os.getenv("WATSONX_APIKEY"),
            'IAM_SERVICE_ID':     os.getenv("IAM_SERVICE_ID"),
            'ENDPOINT':           os.getenv("ENDPOINT"),
            'IBM_AUTH_ENDPOINT':  os.getenv("IBM_AUTH_ENDPOINT"),
            'BUCKET':             os.getenv("BUCKET")
        }
        self.cos_client = ibm_boto3.client(
            service_name='s3',
            ibm_api_key_id=self.credentials['WATSONX_API_KEY'],
            ibm_service_instance_id=self.credentials['IAM_SERVICE_ID'],
            ibm_auth_endpoint=self.credentials['IBM_AUTH_ENDPOINT'],
            endpoint_url=self.credentials['ENDPOINT'],
            config=Config(signature_version='oauth')
        )

    def fetch_presto_cert(self) -> None:
        """
        Downloads the `presto.crt` certificate from IBM Cloud Object Storage
        to the specified local path. Raises an exception if download fails.
        """
        try:
            self.cos_client.download_file(
                Bucket=self.credentials["BUCKET"],
                Key=CERT_LOCAL_PATH,
                Filename=CERT_LOCAL_PATH
            )
            print(f"Certificate downloaded successfully to: {CERT_LOCAL_PATH}")
        except Exception as e:
            print(f"Error while downloading certificate: {e}")
            raise e

    def delete_cos_prefix(self, bucket: str, prefix: str) -> None:
        """
        Deletes all objects under the given prefix in the COS bucket,
        skipping the Presto certificate file.
        """
        try:
            print("Deleting old COS objects.....")
            response: Dict[str, Any] = self.cos_client.list_objects_v2(
                Bucket=bucket,
                Prefix=prefix
            )
            if 'Contents' in response:
                to_delete: List[Dict[str, str]] = []
                for obj in response['Contents']:
                    key: str = obj['Key']
                    if key == CERT_LOCAL_PATH:
                        continue
                    to_delete.append({'Key': key})
                print(f"Items to delete: {to_delete}")
                if to_delete:
                    self.cos_client.delete_objects(
                        Bucket=bucket,
                        Delete={'Objects': to_delete}
                    )
            print("Old COS Objects deleted")
        except Exception as e:
            print(f"Error while deleting files in IBM COS bucket: {e}")
            raise

    def upload_to_cos(self, local_dir: str, data_type: str) -> List[str]:
        """
        Mirrors the local_dir structure (excluding the '/tmp/' part) to COS under
        '<data_type>_<session_id>/' prefix, filters by extension, and skips hidden files.
        Deletes all existing objects under the base '<data_type>_' prefix first.
        """
        bucket: Optional[str] = self.credentials['BUCKET']
        # Remove old sessions
        base_prefix: str = f"{data_type}/"
        try:
            self.delete_cos_prefix(bucket, base_prefix)  # type: ignore
        except Exception as e:
            print(f"Warning: could not clear old sessions for '{base_prefix}': {e}")

        session_folder: str = os.path.basename(local_dir)
        session_prefix: str = f"{session_folder}/"
        print(f"session_prefix: {session_folder}")
        uploaded_paths: List[str] = []

        for root, _, files in os.walk(local_dir):
            for fname in files:
                if fname.startswith('.'):
                    continue
                lower: str = fname.lower()
                if data_type == 'faq' and not lower.endswith('.csv'):
                    continue
                if data_type == 'html' and not (lower.endswith('.html') or lower.endswith('.htm')):
                    continue
                full_path: str = os.path.join(root, fname)
                print(f"full path: {full_path}")
                if not os.path.isfile(full_path):
                    continue
                rel_path: str = os.path.relpath(full_path, local_dir).replace(os.sep, '/')
                print(f"relative path: {rel_path}")
                cos_key: str = f"{session_prefix}{rel_path}"
                print(f"cos key: {cos_key}")
                try:
                    self.cos_client.upload_file(
                        Filename=full_path,
                        Bucket=bucket,  # type: ignore
                        Key=cos_key
                    )
                    uploaded_paths.append(cos_key)
                except Exception as e:
                    print(f"Failed to upload '{full_path}' as '{cos_key}': {e}")
        print(f"Uploaded {len(uploaded_paths)} files under '{session_prefix}'")
        return uploaded_paths

    def get_file_from_cos(self, path: str) -> str:
        """
        Downloads the file at `path` from COS and returns its content as a string.
        """
        try:
            key: str = path.lower()
            obj: Dict[str, Any] = self.cos_client.get_object(
                Bucket=self.credentials["BUCKET"],
                Key=key
            )
            content: str = obj['Body'].read().decode('utf-8')
            print(content)
            return content
        except Exception as e:
            print(f"Error while downloading files from the ibm cos bucket: {e}")
            raise e
