# For vector database
from pymilvus import (
    Collection, CollectionSchema, utility, FieldSchema, DataType
)

from dotenv import load_dotenv

import pandas as pd
import jaconv, os, glob
from tqdm import tqdm
from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings
from config import (
    FAQ_EMBEDDING_MODEL_DIMENSION, FAQ_EMBEDDING_MODEL_NAME
)
from typing import List, Dict, Any, Optional

load_dotenv()


class milvus_db:
    """Initialize milvus db, create collection, ingest data & search query"""
    
    faq_embedding_model: str
    faq_embedding_dimensions: int
    
    def __init__(self) -> None:
        self.faq_embedding_model = FAQ_EMBEDDING_MODEL_NAME
        self.faq_embedding_dimensions = FAQ_EMBEDDING_MODEL_DIMENSION

    def create_milvus_html_collection(
            self,
            collection_name: str,
            dimension: int) -> Collection:
        """Setup Milvus collection for vector storage"""
        try:
            # Check if the collection exists and drop if it does
            if utility.has_collection(collection_name):
                utility.drop_collection(collection_name)

            # Define fields for the collection
            fields: List[FieldSchema] = [
                FieldSchema(name="id", dtype=DataType.INT64, is_primary=True,
                            auto_id=True),
                FieldSchema(name="text", dtype=DataType.VARCHAR,
                            max_length=65535),
                FieldSchema(name="heading", dtype=DataType.VARCHAR,
                            max_length=255),
                FieldSchema(name="source_id", dtype=DataType.VARCHAR,
                            max_length=255),
                FieldSchema(name="source_url", dtype=DataType.VARCHAR,
                            max_length=1024),
                FieldSchema(name="file_path", dtype=DataType.VARCHAR,
                            max_length=1024),
                FieldSchema(name="embeddings", dtype=DataType.FLOAT_VECTOR,
                            dim=dimension)
            ]
        
            # Create Collection schema
            schema: CollectionSchema = CollectionSchema(
                fields,
                description=f"""Mizuho html documents collection for RAG 
                with {dimension}-dimensional embeddings"""
            )

            # Create collection
            collection: Collection = Collection(name=collection_name,
                                                schema=schema)

            # create index for vector field
            index_params: Dict[str, Any] = {
                "metric_type": "L2",
                "index_type": "HNSW",
                "params": {"M": 8, "efConstruction": 64}
            }
            collection.create_index(field_name="embeddings",
                                    index_params=index_params)
            return collection
        except Exception as e:
            print(f"Error while creating collection: {e}")
            raise e

    def insert_into_html_milvus(self,
                                collection: Collection,
                                chunks: List[Dict[str, str]],
                                embeddings: List[List[float]]) -> int:
        """Insert chunks and embeddings into Milvus collection"""
        try:
            data_to_insert: List[List[Any]] = [
                [chunk["text"] for chunk in chunks],
                [chunk["heading"] for chunk in chunks],
                [chunk["source_id"] for chunk in chunks],
                [chunk["source_url"] for chunk in chunks],
                [chunk["file_path"] for chunk in chunks],
                embeddings
            ]
            collection.insert(data_to_insert)
            collection.flush()
            print('Data insertion successful in collection: ', collection)
            return len(chunks)
        except Exception as e:
            print(f"Error while inserting data into milvus: {e}")
            raise e
        
    def load_html_collection(self,
                             collection_name: str) -> Optional[Collection]:
        """Load HTML collection from Milvus"""
        try:
            if utility.has_collection(collection_name):
                collection: Collection = Collection(collection_name)
                collection.load()
                return collection
            return None
        except Exception as e:
            print(f"Error in loading collection: {e}")
            raise e
        
    def load_faq_collection(self,
                            collection_name: str) -> Optional[Collection]:
        """Load FAQ collection from Milvus"""
        try:
            if utility.has_collection(collection_name=collection_name):
                collection: Collection = Collection(collection_name)
                collection.load()
                return collection
            return None
        except Exception as e:
            print(f"Error while loading faq collection: {e}")
            raise e

    def create_milvus_faq_collection(self, coll_name: str) -> Collection:
        """Create FAQ collection in Milvus"""
        try:
            if utility.has_collection(coll_name):
                utility.drop_collection(coll_name)

            fields: List[FieldSchema] = [
                FieldSchema(name="question", dtype=DataType.VARCHAR,
                            max_length=1024, is_primary=True, auto_id=False),
                FieldSchema(name="answer", dtype=DataType.VARCHAR,
                            max_length=4096),
                FieldSchema(name="ques_vector", dtype=DataType.FLOAT_VECTOR,
                            dim=self.faq_embedding_dimensions)
            ]

            schema: CollectionSchema = CollectionSchema(
                fields,
                description="FAQ collection with cosine similarity")
            coll: Collection = Collection(coll_name, schema)

            index_params: Dict[str, Any] = {
                'metric_type': 'COSINE',
                'index_type': 'IVF_FLAT',
                'params': {"nlist": 128}
            }

            coll.create_index(field_name="ques_vector",
                              index_params=index_params)
            return coll
        except Exception as e:
            print(f"Error while creating FAQ collection: {e}")
            raise e

    def insert_in_faq_collection(self,
                                 coll_name: str, docs: List[Document]) -> None:
        """Insert FAQ documents into collection"""
        try:
            # Load the collection
            coll: Collection = Collection(coll_name)
            coll.load()

            model: HuggingFaceEmbeddings = HuggingFaceEmbeddings(
                model_name=self.faq_embedding_model)
            questions: List[str] = [doc.page_content for doc in docs]
            answers: List[str] = [doc.metadata.get("answer", "") for doc in docs]
            embeddings: List[List[float]] = model.embed_documents(questions)

            data: List[List[Any]] = [
                questions,     # corresponds to 'question' field
                answers,       # corresponds to 'answer' field
                embeddings     # corresponds to 'ques_vector'
            ]

            coll.insert(data)
            coll.flush()  # Ensures data persistence
            print('Data insertion successful in collection: ', coll_name)
        except Exception as e:
            print(f"Error while inserting data in FAQ collection: {e}")
            raise e

    def load_faq_csv(self, folder_path: str) -> Optional[List[Document]]:
        """
        Load FAQ documents from all CSV files in the specified folder
        
        Args:
            folder_path (str): Path to the folder containing CSV files
            
        Returns:
            list: List of Document objects or None if error occurs
        """
        try:
            # Get all CSV files in the folder
            csv_files: List[str] = glob.glob(os.path.join(
                folder_path, "**/*.csv"), recursive=True)
            print(f"Found {len(csv_files)} csv files")
            
            all_faq_docs: List[Document] = []
            
            # Process each CSV file
            for csv_file in tqdm(csv_files, desc="Processing FAQ Files"):
                print(f"Processing file: {os.path.basename(csv_file)}")
                try:
                    # Read CSV file
                    df: pd.DataFrame = pd.read_csv(csv_file,
                                                   encoding="utf-8",
                                                   skiprows=5)
                    # Clean column names
                    df.columns = [col.replace('\u3000', '').strip() for col in df.columns]
                    # Define required columns
                    question_col: str = "質問文（必須）"
                    answer_col: str = "回答文（必須）"
                    # Check if required columns exist
                    if question_col not in df.columns:
                        print(f"Column '{question_col}' not found in {os.path.basename(csv_file)}. Available columns: {list(df.columns)}")
                        continue
                    if answer_col not in df.columns:
                        print(f"Column '{answer_col}' not found in {os.path.basename(csv_file)}. Available columns: {list(df.columns)}")
                        continue
                    
                    file_faq_docs: List[Document] = []
                    # Process each row in the CSV
                    for i, row in df.iterrows():
                        try:
                            question: str = str(row[question_col]).strip() if pd.notna(row[question_col]) else ""
                            answer: str = str(row[answer_col]).strip() if pd.notna(row[answer_col]) else ""
                            
                            # Convert full-width characters to half-width
                            if question:
                                question = jaconv.z2h(question, kana=True, digit=True, ascii=True)
                            if answer:
                                answer = jaconv.z2h(answer, kana=True, digit=True, ascii=True)
                            
                            # Only add if both question and answer are not empty
                            if question and answer and question != "nan" and answer != "nan":
                                file_faq_docs.append(
                                    Document(
                                        page_content=question,
                                        metadata={
                                            "answer": answer,
                                            "source": "faq",
                                            "file_path": os.path.basename(csv_file)
                                        }
                                    )
                                )
                        except Exception as e:
                            print(f"Skipping row {i} in {os.path.basename(csv_file)} due to error: {e}")
                    
                    print(f"Loaded {len(file_faq_docs)} FAQ entries from {os.path.basename(csv_file)}")
                    all_faq_docs.extend(file_faq_docs)
                    
                except Exception as e:
                    print(f"Error processing file {os.path.basename(csv_file)}: {e}")
                    continue
            
            print(f"Total FAQ documents loaded: {len(all_faq_docs)}")
            return all_faq_docs if all_faq_docs else None
            
        except Exception as e:
            print(f"Error while loading FAQ CSVs from folder {folder_path}: {e}")
            raise e

    def query_faq_milvus(self, query: str, collection_name: str) -> List[Dict[str, Any]]:
        """
        Get FAQ chunks for combining with document chunks
        """
        try:
            top_k: int = 1
            embedding_model: HuggingFaceEmbeddings = HuggingFaceEmbeddings(model_name=self.faq_embedding_model)
            query_embedding: List[float] = embedding_model.embed_query(query)
            
            coll: Optional[Collection] = self.load_faq_collection(collection_name=collection_name)
            if not coll:
                return []
            
            search_params: Dict[str, Any] = {
                "metric_type": "COSINE",
                "params": {"nprobe": 10}
            }
            
            results = coll.search(
                data=[query_embedding],
                anns_field="ques_vector",
                param=search_params,
                limit=top_k,
                expr=None,
                output_fields=["question", "answer"]
            )
            coll.release()
            
            faq_chunks: List[Dict[str, Any]] = []
            if results and results[0]:
                for hit in results[0]:
                    if hit.distance >= 0.7:  # similarity threshold
                        faq_chunks.append({
                            "question": hit.entity.get("question"),
                            "answer": hit.entity.get("answer"),
                            "score": hit.distance,
                            "source": "FAQ"
                        })
            return faq_chunks
            
        except Exception as e:
            print(f"Error getting FAQ chunks: {e}")
            return []
