# Mizuho RAG Application
## Introduction
This project is a Retrieval-Augmented Generation (RAG) system designed to answer Japanese legal or business FAQs. It uses:
 - 🧠 IBM watsonx LLM for generating answers
 - 📄 Milvus for storing HTML and FAQ embeddings
 - 🔍🧲 Hybrid Retrieval for HTML documents using vector search & keyword-based search for more accurate answers
 -🧪 FastAPI for the backend
 - 💻 React with IBM Carbon Design System for the frontend
 - 💾 IBM Cloud Object Storage (COS) for persisting and retrieving uploaded HTML and FAQ files across sessions
 - 🧠 IBM watsonx LLM for generating answers
 - 📄 Milvus for storing HTML and FAQ embeddings
 - 🔍🧲 Hybrid Retrieval for HTML documents using vector search & keyword-based search for more accurate answers
 -🧪 FastAPI for the backend
 - 💻 React with IBM Carbon Design System for the frontend
 - 💾 IBM Cloud Object Storage (COS) for persisting and retrieving uploaded HTML and FAQ files across sessions

## Architecture
<details>
<summary>Architecture</summary>

![alt text](/assets/mizuho-rag-architecture.png)
</details>

## Project Directory Structure

<details>
<summary>Directory Structure</summary>

```plaintext
Mizuho_Rag_with_HTML_Doc/
├── Pipfile
├── Pipfile.lock
├── README.md
├── mizuho-rag-architecture.png
├── backend/
│   ├── auth.py
│   ├── config.py
│   ├── env_copy
│   ├── html_extraction.py
│   ├── hybrid_retriever.py
│   ├── main.py
│   ├── models.py
│   ├── qa_chain.py
│   ├── rag_chain.py
│   ├── requirements.txt
│   ├── reranker.py
│   └── utils/
│       ├── helper.py
│       └── milvus.py
├── data/
│   ├── faq_docs/
│   │   └── Faq_sample.csv
│   └── html_docs/
│       ├── 01.html
│       ├── 02.html
│       ├── 03.html
│       ├── .........
├── frontend/
│   ├── eslint.config.js
│   ├── index.html
│   ├── package-lock.json
│   ├── package.json
│   ├── public/
│   │   ├── bee.svg
│   │   └── vite.svg
│   ├── src/
│   │   ├── App.css
│   │   ├── App.tsx
│   │   ├── assets/
│   │   │   ├── ibm-logo.svg
│   │   │   └── react.svg
│   │   ├── components/
│   │   │   ├── LoginForm.css
│   │   │   ├── LoginForm.tsx
│   │   │   ├── RAGInterface.css
│   │   │   ├── RAGUploadPanel.css
│   │   │   ├── RAGUploadPanel.tsx
│   │   │   └── RagInterface.tsx
│   │   ├── index.css
│   │   ├── main.tsx
│   │   ├── services/
│   │   │   └── api.ts
│   │   └── vite-env.d.ts
│   ├── tsconfig.app.json
│   ├── tsconfig.json
│   ├── tsconfig.node.json
│   └── vite.config.ts
```
</details> 

## ⚙️ Setup Instructions
### 1. 🔧 Backend Setup
#### Step 1.1: Install Python Dependencies
- Open a terminal and execute below commands
    ```bash
    cd Mizuho_Rag_with_HTML_Doc

    pip install pipenv
    pipenv install
    ```

#### Step 1.2: Activate Virtualenv
1. To Activate the virtual environment
1. To Activate the virtual environment
    ```bash
    pipenv shell
    ```
2. Install requirements
    ```bash
    pipenv install -r backend/requirements.txt
    ```
    
2. Install requirements
    ```bash
    pipenv install -r backend/requirements.txt
    ```
    
#### Step 1.3: Create a .env File
1. Please refer to env_copy (location: backend/env_copy) to create the env file:
1. Please refer to env_copy (location: backend/env_copy) to create the env file:
    Here is the env setup:

    ```bash
    WATSONX_APIKEY='enter watsonx api key'
    PROJECT_ID='enter watsonx.ai project id'
    WATSONX_URL="enter watsonx.ai url"

    MILVUS_PORT='milvus port number'
    MILVUS_PEM_PATH='backend/presto.crt' # DO NOT CHANGE
    MILVUS_HOST="milvus host"
    MILVUS_USERNAME="Milvus username"
    MILVUS_PASSWORD="milvus password"

    IAM_SERVICE_ID="IBM COS Bucker CRN id"
    ENDPOINT='public endpoint of the bucket'
    IBM_AUTH_ENDPOINT='bucket authentication endpoint'
    BUCKET="bucket name"

    MILVUS_PORT='milvus port number'
    MILVUS_PEM_PATH='backend/presto.crt' # DO NOT CHANGE
    MILVUS_HOST="milvus host"
    MILVUS_USERNAME="Milvus username"
    MILVUS_PASSWORD="milvus password"

    IAM_SERVICE_ID="IBM COS Bucker CRN id"
    ENDPOINT='public endpoint of the bucket'
    IBM_AUTH_ENDPOINT='bucket authentication endpoint'
    BUCKET="bucket name"

    USERNAME="application username"
    PASSWORD="application password"
    ```
    - env location: 
    ```bash 
    backend\.env
    ```
2. NOTE: The presto.crt will be stored in the designated IBM COS Bucket and at the application startup will be automatically downloaded in the above mentioned location


#### Step 1.4: Other Configurations [OPTIONAL]
1. If you want to experiment with LLM, you can do so by changing the following configurations in the configuration file
    - env location: 
    ```bash 
    backend\.env
    ```
2. NOTE: The presto.crt will be stored in the designated IBM COS Bucket and at the application startup will be automatically downloaded in the above mentioned location


#### Step 1.4: Other Configurations [OPTIONAL]
1. If you want to experiment with LLM, you can do so by changing the following configurations in the configuration file
    - Open configuration file: `backend/config.py`
    - LLM settings:
    - LLM settings:
        ```bash
        WATSONX_LLM_MODEL="LLM model to generate final answer"

        HTML_EMBEDDING_MODEL_NAME="Embedding model for the html documents"
        HTML_EMBEDDING_MODEL_DIMENSION="Dimension of the html documents' embedding model"
        RERANKER_MODEL="Model for reranking"

        FAQ_EMBEDDING_MODEL_NAME="Embedding model for the FAQ documents"
        FAQ_EMBEDDING_MODEL_DIMENSION="Dimension of the FAQ documents' embedding model"
        ```
    - Default values are already placed in the file if you do not want to change anything.

2. To change the default names of the collections
    ```bash
    HTML_COLLECTION_NAME="html doc's milvus collection name"
    HTML_TOP_K='Number of html doc retrieved chunks from hybrid retriever'
    HTML_TOP_K='Number of html doc retrieved chunks from hybrid retriever'
    
    FAQ_COLLECTION_NAME="faq doc's milvus collection name"
    ```
    - Default values are already placed in the file if you do not want to change anything.

#### Step 1.5: Run FastAPI Server
1. To run the FASTAPI server, execute below command
#### Step 1.5: Run FastAPI Server
1. To run the FASTAPI server, execute below command
    ```bash
    cd backend/
    python main.py
    cd backend/
    python main.py
    ```
2. The backend will be running at: http://localhost:8000


### Step 2. Frontend Setup
#### Step 2.1: Install Node Modules
1. Open a Terminal, execute below command
    ```bash
    cd Mizuho_Rag_with_HTML_Doc
    ```
2. Activate the virtual environment
   ```bash
   pipenv shell
   ```
3. Swtich to frontend directory
   ```bash
   cd frontend
   ```
4. Install npm
   ```bash
    npm install --force
    ```
#### Step 2.2: Start the React Dev Server
1. To run the frontend react UI, execute below command
    ```bash
    npm run dev 
    ```
2. The frontend will be running at: http://localhost:5173
