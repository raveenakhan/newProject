import React, { useState } from 'react';
import {
  TextInput,
  Button,
  InlineNotification
} from 'carbon-components-react';
import api from '../services/api';
import './LoginForm.css';
import ibmLogo from '../assets/ibm-logo.svg';

interface LoginFormProps {
  onLogin: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    try {
      const res = await api.post('/login', { username, password });
      setMessage(res.data.message);
      onLogin();
    } catch {
      setMessage('ログインに失敗しました');
    }
  };

  return (
    <div className="login-layout">
      {/* Left branding panel */}
      <div className="login-left-panel">
        <div className="login-left-content">
          <h1 className="left-title">みずほ</h1>
          <h1 className="left-title">RAG</h1>
          <h1 className="left-title">アプリケーション</h1>
        </div>
        <img src={ibmLogo} alt="IBM Logo" className="login-logo-bottom" />
      </div>

      {/* Right form panel */}
      <div className="login-right-panel">
        <div className="login-form-panel">
          <h1 className="bx--type-expressive-heading-04"><b>ログイン</b></h1>
          <form onSubmit={handleLogin} className="bx--form login-form">
            <label>ユーザー名</label>
            <TextInput
              id="username"
              labelText=""
              onChange={(e) => setUsername(e.target.value)}
              className="login-input"
              type="text"
              style={{ width: '60%', height: '3rem'}}
            />
            <label>パスワード</label>
            <TextInput
              id="password"
              type="password"
              labelText=""
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="login-input"
              style={{ width: '60%', height: '3rem'}}
            />

            <Button type="submit" className="login-button" kind="primary">
              続行
            </Button>

            {message && (
              <InlineNotification
                kind="error"
                title="エラー"
                subtitle={message}
                onCloseButtonClick={() => setMessage('')}
                className="login-notification"
              />
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;