import React, { useState } from 'react';
import {
  Checkbox,
  TextArea,
  Button,
  InlineNotification,
} from 'carbon-components-react';
import api from '../services/api';
import RAGUploadPanel from './RAGUploadPanel';
import ibmLogo from '../assets/ibm-logo.svg';
import './RAGInterface.css';

interface RAGInterfaceProps {
  onLogout: () => void;
}

const RAGInterface: React.FC<RAGInterfaceProps> = ({ onLogout }) => {
  const [useFaq, setUseFaq] = useState(false);
  const [useDocs, setUseDocs] = useState(true);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [source, setSource] = useState('');
  const [htmlContent, setHtmlContent] = useState('');
  const [history, setHistory] = useState<[string, string][]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showUploadScreen, setShowUploadScreen] = useState(false);
  const [uploadNotification, setUploadNotification] = useState<string | null>(null);

  const handleAsk = async () => {
    const currentQuestion = question.trim();
    if (!currentQuestion) return;

    setIsLoading(true);
    setAnswer('');
    setHtmlContent('');
    setSource('');

    try {
      const res = await api.post('/question', {
        question: currentQuestion,
        use_faq: useFaq,
        use_docs: useDocs,
      });

      const actualAnswer = res.data.answer || '回答が見つかりませんでした。';
      const src = res.data.file_path || res.data.source || '';
      setAnswer(actualAnswer);
      setSource(src);

      // ✅ Use currentQuestion instead of question from closure
      setHistory((prevHistory) => [[currentQuestion, actualAnswer], ...prevHistory]);

      if (src) {
        const htmlRes = await api.post('/html-text', { path: src });
        setHtmlContent(htmlRes.data);
      }
    } catch {
      setAnswer('セッションが無効です。');
    } finally {
      setIsLoading(false);
    }
  };


  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  const clearHistory = () => {
    setHistory([]);
    setQuestion('');
    setAnswer('');
    setHtmlContent('');
    setSource('');
  };

  const handleUploadSuccess = (msg: string) => {
    setUploadNotification(msg);
    setTimeout(() => setUploadNotification(null), 5000);
  };

  return (
    <div className="rag-container">
      <header className="rag-header">
        <h2 className="rag-title">みずほRAGアシスタント</h2>
        <h2><img src={ibmLogo} alt="IBM Logo" className="ibm-logo" /></h2>
        <div className="rag-header-actions">
          {!showUploadScreen && (
            <>
              <Button
                kind="primary"
                size="sm"
                className="primary-button"
                onClick={() => setShowUploadScreen(true)}
              >
              コレクションを作成
              </Button>
              <Button
                kind="primary"
                size="sm"
                className="primary-button"
                onClick={onLogout}
              >
                ログアウト
              </Button>
            </>
          )}
        </div>
      </header>

      {uploadNotification && (
        <div className="notification-container">
          <InlineNotification
            kind="success"
            title="完了"
            subtitle={uploadNotification}
            onCloseButtonClick={() => setUploadNotification(null)}
            lowContrast
          />
        </div>
      )}

      {showUploadScreen ? (
        <RAGUploadPanel
          onBack={() => setShowUploadScreen(false)}
          onFaqUpload={handleUploadSuccess}
          onHtmlUpload={handleUploadSuccess}
        />
      ) : (
        <div className="rag-main-content">
          <div className="rag-left-panel">
            <section className="rag-filters">
              <label>ソースを選択：</label>
              <Checkbox
                id="use-faq"
                labelText="FAQ を使用"
                checked={useFaq}
                onChange={(checked: boolean) => setUseFaq(checked)}
              />
              <Checkbox
                id="use-docs"
                labelText="内部文書を使用"
                checked={useDocs}
                onChange={(checked: boolean) => setUseDocs(checked)}
              />
            </section>
            <label>質問 (Ctrl+Enter で送信)</label>
            <TextArea
              labelText=""
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={handleKeyPress}
              rows={2}
              placeholder="質問を入力してください…"
            />

            <div className="button-row">
              <Button
                kind="primary"
                className="primary-button"
                onClick={handleAsk}
                disabled={isLoading || !question.trim()}
              >
                {isLoading ? '処理中…' : '質問する'}
              </Button>
              {(answer || history.length > 0) && (
                <Button
                  kind="primary"
                  className="primary-button"
                  onClick={clearHistory}
                >
                  履歴をクリア
                </Button>
              )}
            </div>
            <label>回答</label>
            <TextArea
              readOnly
              labelText=""
              value={answer}
              rows={2}
              placeholder="ここに回答が表示されます…"
            />

            <section className="rag-history">
              <h4>質問履歴 ({history.length} 件)</h4>
              <div className="history-list">
                {history.length === 0 ? (
                  <p className="no-history">まだ質問はありません</p>
                ) : (
                  <ul>
                    {history
                      .slice()
                      .map(([q, a], i) => (
                        <li key={i} className="history-item" style={{ marginBottom: '1rem' }}>
                          <div style={{ marginBottom: '0.3rem' }}><strong>Q:</strong> {q}</div>
                          <div className="answer-snippet">
                            <strong>A:</strong>{' '}
                            {a.length > 100 ? `${a.slice(0, 100)}…` : a}
                          </div>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            </section>
          </div>

          <div className="rag-right-panel">
            <div className="rag-html-viewer">
              <div className="rag-html-viewer-header">
                <h4>参照文書</h4>
                {source && <span className="rag-source-file">ソース: {source}</span>}
              </div>
              <div className="rag-html-content">
                {htmlContent ? (
                  <div
                    dangerouslySetInnerHTML={{ __html: htmlContent }}
                  />
                ) : (
                  <p className="no-doc">質問を送信すると、関連する文書がここに表示されます。</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RAGInterface;
