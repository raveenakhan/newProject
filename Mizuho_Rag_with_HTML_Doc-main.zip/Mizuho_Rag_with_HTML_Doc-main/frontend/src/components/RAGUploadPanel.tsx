import React, { useState } from 'react';
import {
  FileUploader,
  FileUploaderDropContainer,
  Button,
  InlineLoading,
  InlineNotification,
} from 'carbon-components-react';
import api from '../services/api';
import './RAGUploadPanel.css';

interface RAGUploadPanelProps {
  onBack: () => void;
  onFaqUpload: (message: string, sessionId: string) => void;
  onHtmlUpload: (message: string, sessionId: string) => void;
}

const RAGUploadPanel: React.FC<RAGUploadPanelProps> = ({
  onBack,
  onFaqUpload,
  onHtmlUpload,
}) => {
  const [notification, setNotification] = useState<string | null>(null);
  const [notificationKind, setNotificationKind] = useState<'success' | 'error'>('success');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingType, setLoadingType] = useState<'faq' | 'html' | ''>('');
  const [faqFile, setFaqFile] = useState<File | null>(null);
  const [htmlFile, setHtmlFile] = useState<File | null>(null);
  const [sessionId] = useState<string>(() => crypto.randomUUID());

  const handleCreate = async (file: File | null, type: 'faq' | 'html') => {
    if (!file) {
      setNotification('ZIPファイルを選択してください。');
      setNotificationKind('error');
      return;
    }
    setIsLoading(true);
    setLoadingType(type);
    try {
      // const endpoint = '/create_html_collection';
      const formData = new FormData();
      formData.append('zip_file', file);
      formData.append('session_id', sessionId);
      formData.append('datatype', type);
      const res = await api.post('/create_collection', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      const msg = res.data.message ||
        `${type === 'faq' ? 'FAQ' : 'HTML'}コレクションが正常に作成されました。`;
      if (type === 'faq') onFaqUpload(msg, sessionId);
      else onHtmlUpload(msg, sessionId);
    } catch (e: any) {
      const err = e.response?.data?.detail ||
        `${type === 'faq' ? 'FAQ' : 'HTML'}コレクションの作成に失敗しました。`;
      setNotification(err);
      setNotificationKind('error');
    } finally {
      setIsLoading(false);
      setLoadingType('');
    }
  };

  return (
    <div className="rag-upload-panel">
      {notification && (
        <InlineNotification
          kind={notificationKind}
          title={notificationKind === 'error' ? 'エラー' : '完了'}
          subtitle={notification}
          onCloseButtonClick={() => setNotification(null)}
          lowContrast
        />
      )}

      <Button
        kind="tertiary"
        onClick={onBack}
        disabled={isLoading}
        className="back-button"
      >
        ← ホームに戻る
      </Button>

      <div className="rag-upload-panels">
        {/* FAQ Panel */}
        <div className="rag-upload-panel-item">
          <h4>FAQコレクションの作成</h4>
          <p className="panel-desc">CSVを含むZIPファイルをドラッグ＆ドロップ、または選択してください。</p>
          <div className="bx--file__container">
          <FileUploaderDropContainer
            labelText="ドラッグ アンド ドロップまたはクリックして .zip ファイルをアップロードします"
            multiple={false}
            accept={[".zip"]}
            name= ""
            onAddFiles={({ target }) => {
                const files = (target as HTMLInputElement).files;
                setFaqFile(files && files.length > 0 ? files[0] : null);
              }}
          />
          {faqFile && (<div className="selected-file">選択されたファイル: {faqFile.name}</div>)}
          </div>
          <div className="button-with-spinner">
            <Button
              kind="primary"
              className="create-button"
              onClick={() => handleCreate(faqFile, 'faq')}
              disabled={!faqFile || isLoading}
            >
              FAQコレクション作成
            </Button>
            {isLoading && loadingType === 'faq' && <InlineLoading description="作成中…" />}
          </div>
        </div>

        {/* HTML Panel */}
        <div className="rag-upload-panel-item">
          <h4>HTMLコレクションの作成</h4>
          <p className="panel-desc">HTMLを含むZIPファイルをドラッグ＆ドロップ、または選択してください。</p>
          <FileUploaderDropContainer
            labelText="ドラッグ アンド ドロップまたはクリックして .zip ファイルをアップロードします"
            multiple={false}
            accept={[".zip"]}
            name=""
            onAddFiles={({ target }) => {
              const files = (target as HTMLInputElement).files;
              setHtmlFile(files && files.length > 0 ? files[0] : null);
            }}
          />
          {htmlFile && (<div className="selected-file">選択されたファイル: {htmlFile.name}</div>)}
          <div className="button-with-spinner">
            <Button
              kind="primary"
              className="create-button"
              onClick={() => handleCreate(htmlFile, 'html')}
              disabled={!htmlFile || isLoading}
            >
              HTMLコレクション作成
            </Button>
            {isLoading && loadingType === 'html' && <InlineLoading description="作成中…" />}
          </div>
        </div>
      </div>

      <div className="upload-help">
        <h4>使用方法:</h4>
        <ul>
          <li><strong>FAQ:</strong> CSVを含むZIPをアップロード</li>
          <li><strong>HTML:</strong> HTMLを含むZIPをアップロード</li>
        </ul>
      </div>
    </div>
  );
};

export default RAGUploadPanel;
