
import React, { useState } from 'react';
import LoginForm from './components/LoginForm';
import RAGInterface from './components/RagInterface';


const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div>
      {isLoggedIn ? (
        <RAGInterface onLogout={() => setIsLoggedIn(false)} />
      ) : (
        <LoginForm onLogin={() => setIsLoggedIn(true)} />
      )}
    </div>
  );
};

export default App;





