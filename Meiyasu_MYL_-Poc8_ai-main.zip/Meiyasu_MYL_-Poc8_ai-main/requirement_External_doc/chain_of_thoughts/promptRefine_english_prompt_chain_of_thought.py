
from string import Template
import pandas as pd
import os
from dotenv import load_dotenv
from ibm_watsonx_ai.foundation_models import Model


# Load environment variables from .env file
load_dotenv()

# Get credentials from .env
API_KEY = os.getenv("API_KEY")
SERVICE_URL = os.getenv("SERVICE_URL")
PROJECT_ID = os.getenv("PROJECT_ID")

def get_credentials():
    return {
        "url" : SERVICE_URL,
        "apikey" : API_KEY
    }


def external_doc_check(system_requirements, external_design_document_csv):
    prompt = f"""You are an expert requirements coverage analyst specializing in Japanese insurance system requirements and technical specifications.

Your task: Determine if the given requirement has meaningful coverage in the external design document, considering both direct and indirect relationships.

---
🎯 **LEARNING FROM EXAMPLES:**

**Example 1 - POSITIVE CASE (Coverage: Yes)**
Requirement: 上皮内特約、がん先進特約の契約引受については、がん団信の導入を必須とし、取り外し不可とする
External Doc: チェック内容: 単独契約以外で上皮内特約の情報（団信制度区分、証券番号）を入力しようとしていないか
Analysis: The requirement mandates がん団信 for 上皮内特約, and the document implements a validation check that prevents 上皮内特約 input without proper conditions. This is INDIRECT but MEANINGFUL coverage.

**Example 2 - NEGATIVE CASE (Coverage: No)**  
Requirement: 上皮内特約、がん先進特約の契約引受については、がん団信の導入を必須とし、取り外し不可とする
External Doc: チェック内容: 一般団信で上皮内特約の情報を入力する場合、がん団信の証券番号が入力されているか
Analysis: While both mention がん団信 and 上皮内特約, the document focuses on input validation for existing contracts, NOT on the mandatory introduction requirement. Different functional scope.

**Example 3 - NEGATIVE CASE (Coverage: No)**
Requirement: 給付金額は、10万～50万の間で上限額を設定する（一般団信の保険金額と同様、給付金額は親子一律とする）
External Doc: チェック内容: 上皮内特約で指定された保険金額・Ｓ決定方法（給付金額１０万円単位）以外になっていないか  
Analysis: The requirement sets policy for amount ranges (10-50万), but document only validates unit increments (10万円単位). Related topic but insufficient coverage of the range requirement.

---
🔸 **REQUIREMENT TO ANALYZE:**
{system_requirements}

🔸 **EXTERNAL DESIGN DOCUMENT:**
{external_design_document_csv}

---
📋 **SYSTEMATIC ANALYSIS PROCESS:**

**STEP 1: REQUIREMENT DECOMPOSITION**
Break down the requirement into:
- Primary business rule/constraint
- Secondary conditions/exceptions  
- Key entities involved (特約, 団信, etc.)
- Quantitative limits/ranges if any
- Process flow implications

**STEP 2: DOCUMENT FUNCTION IDENTIFICATION**  
Classify the document content as:
- Validation rule (チェック内容)
- Data specification (改訂内容, 桁数)
- Business logic implementation  
- Configuration/setup instruction
- Process control mechanism

**STEP 3: FUNCTIONAL ALIGNMENT ANALYSIS**
For each requirement component, ask:
- Does the document implement this business rule?
- Does it provide validation/control for this constraint?
- Does it enable/prevent the required behavior?
- Is there implicit coverage through related functionality?

**STEP 4: COVERAGE DEPTH ASSESSMENT**
- **DIRECT (80-100%)**: Document explicitly implements the requirement
- **INDIRECT (40-79%)**: Document supports requirement through validation/control
- **TANGENTIAL (10-39%)**: Document relates to requirement domain but different purpose
- **UNRELATED (0-9%)**: No functional relationship

**STEP 5: IMPLEMENTATION VALUE TEST**
Final check: "If a developer used this document, would they be able to implement the requirement correctly?"

---
🧠 **CRITICAL SUCCESS FACTORS:**
- Distinguish between business rules vs. data specifications
- Focus on implementability rather than terminology overlap
- Consider Japanese domain context and implicit relationships
- Weight validation mechanisms as strong coverage indicators
- Evaluate functional intent alignment, not just keyword matching

---
📤 **REQUIRED OUTPUT FORMAT:**
```json
{{
  "requirement_breakdown": "<List the core business rule and key components>",
  "document_function": "<Classify what the document actually does>",
  "functional_alignment": "<Explain how document function relates to requirement>",
  "coverage_reasoning": "<Detailed analysis of coverage relationship>",
  "coverage_percent": <integer 0-100>,
  "answer": "<Yes or No>"
}}
```

⚠️ **VALIDATION CHECKLIST:**
✅ Completed all 5 analysis steps systematically
✅ Coverage percentage reflects implementation value
✅ Answer follows 30% threshold rule (≥30% = "Yes", <30% = "No")
✅ Reasoning references specific requirement and document elements"""

    # Optimized parameters
    model_id = "mistralai/mistral-large"
    
    parameters = {
        "decoding_method": "greedy",
        "max_new_tokens": 3000,
        "min_new_tokens": 200,
        "stop_sequences": [],
        "repetition_penalty": 1.1,
    }
    
    model = Model(
        model_id=model_id,
        params=parameters,
        credentials=get_credentials(),
        project_id=PROJECT_ID,
    )
    
    generated_response = model.generate_text(prompt=prompt, guardrails=True)
    return generated_response


# Load the Excel file (adjust sheet name if needed)
excel_path = "C002_Training_Data.xlsx"
df = pd.read_excel(excel_path, sheet_name="C002R-C002D")

for i in range(len(df)):
    row_excel_index = i + 2
    requirement = df.iloc[i, 4]  # E = column index 4
    external_content = df.iloc[i, 6]  # G = column index 6
    
    print(f"{row_excel_index}E: {repr(requirement)} (type: {type(requirement)})")
    print(f"{row_excel_index}G: {repr(external_content)} (type: {type(external_content)})")


# Strip column names of extra whitespace
df.columns = df.columns.str.strip()

# Ensure Output column is initialized
df['Output'] = ""

#Process each row
for idx, row in df.iterrows():

    input1 = str(row.get('requirement', '')).strip() if not pd.isna(row.get('requirement', '')) else ""
    input2 = str(row.get('external_design_document_content', '')).strip() if not pd.isna(row.get('external_design_document_content', '')) else ""

    if input1 and input2:
        print(f"Processing row {idx + 1}...")
        try:
            output = external_doc_check(input1, input2)
            df.at[idx, 'Output'] = output
        except Exception as e:
            print(f"Error at row {idx + 1}: {e}")
            df.at[idx, 'Output'] = f"Error: {e}"
    else:
        df.at[idx, 'Output'] = "Skipped due to missing input"

# Extract only required columns: E (requirement), G (external_design_document_content), H (is_valid), and Output
output_df = df[['requirement', 'external_design_document_content', 'is_valid', 'Output']]

# Save to a new Excel file
output_path = "C002_Training_Output_chain_of_thought.xlsx"
output_df.to_excel(output_path, index=False)
print(f"\n✅ Completed. Output written to {output_path}")

