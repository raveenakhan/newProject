

import pandas as pd
import json
import re
from sklearn.metrics import (
    matthews_corrcoef,
    average_precision_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    accuracy_score
)

# Load Excel file
df = pd.read_excel("C002_Training_Output_chain_of_thought.xlsx")

# Extract answer from JSON block inside triple backticks
def extract_answer(json_str):
    try:
        # Match ```json\n{...}\n``` or ```\n{...}\n```
        json_match = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", str(json_str))
        if json_match:
            parsed_json = json.loads(json_match.group(1))
            return parsed_json.get("answer", "").strip()
    except Exception as e:
        print(f"❌ Error extracting JSON: {e}")
    return None

# Normalize yes/no to 1/0
def normalize_answer(ans):
    if str(ans).strip().lower() in ["はい", "yes", "1", "1.0", "true"]:
        return 1
    elif str(ans).strip().lower() in ["いいえ", "no", "0", "0.0", "false"]:
        return 0
    return None

# Extract and normalize labels
df["pred_label"] = df["Output"].apply(extract_answer).apply(normalize_answer)
df["true_label"] = df["is_valid"].apply(normalize_answer)

# Count and display NaNs
nan_pred_count = df["pred_label"].isna().sum()
print(f"\n❗️Number of NaN predicted labels: {nan_pred_count}")

# Print lists for sanity check
print("🔍 Predicted Labels:", df["pred_label"].tolist())
print("🔍 True Labels:", df["true_label"].tolist())

# Filter valid predictions
valid = df["pred_label"].notnull() & df["true_label"].notnull()
y_true = df.loc[valid, "true_label"]
y_pred = df.loc[valid, "pred_label"]

# Compute evaluation metrics
mcc = matthews_corrcoef(y_true, y_pred)
prauc = average_precision_score(y_true, y_pred)
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)
accuracy = accuracy_score(y_true, y_pred)
conf_matrix = confusion_matrix(y_true, y_pred)

# Display metrics
print("\n📊 Evaluation Results")
print("========================")
print(f"✅ Accuracy: {accuracy:.4f}")
print(f"✅ Precision: {precision:.4f}")
print(f"✅ Recall: {recall:.4f}")
print(f"✅ F1 Score: {f1:.4f}")
print(f"✅ Matthews Correlation Coefficient (MCC): {mcc:.4f}")
print(f"✅ Precision-Recall AUC: {prauc:.4f}")
print("========================")
print(f"✅ Confusion Matrix:\n{conf_matrix}")
