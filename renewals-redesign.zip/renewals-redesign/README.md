# Renewal Intelligence Notebook Guide

This repository contains one end-to-end notebook, `renewal-intelligence.ipynb`, that:

- loads renewal data from `data/renewals_dummy_data_2.csv`
- engineers features for renewal prediction
- trains 3 models (Logistic Regression, LightGBM, CatBoost)
- evaluates model quality using business-focused metrics
- computes drift signals using SHAP + PSI
- saves scored outputs and best-model artifacts separately for:
  - non-SaaS products (`sns_sl`)
  - SaaS products (`saas_products`)

---

## Project Files

- `renewal-intelligence.ipynb`: main notebook (all logic)
- `data/renewals_dummy_data_2.csv`: input dataset used by the notebook
- `data/dummy_data_definition.pdf`: field definitions for the dummy dataset
- `requirements.txt`: Python dependencies
- `runs/`: generated artifacts from each execution (timestamped)

---

## Overall Strategy

The notebook follows the same modeling pipeline twice:

1. `PRODUCT_TYPE != "SaaS"` (saved under `runs/sns_sl/<timestamp>/`)
2. `PRODUCT_TYPE == "SaaS"` (saved under `runs/saas_products/<timestamp>/`)

For each product segment:

1. **Time-aware split**
   - Uses `EXPIRED_END_DATE` to create:
     - train window (historical lookback)
     - validation window (most recent months before run date)
     - 1-month gap buffer (excluded from model selection)
     - test/scoring population (future period after buffer)
2. **Feature engineering**
   - Drops leakage/ID/redundant/date text columns
   - Adds transformations and interaction features
3. **Train 3 models**
   - Logistic Regression with preprocessing + class weighting
   - LightGBM with native categorical handling + early stopping
   - CatBoost with categorical indices + early stopping
4. **Evaluate model performance**
   - Computes PR-AUC and threshold-based classification metrics
5. **Explainability + drift**
   - SHAP feature importance
   - PSI on top SHAP features
   - alert flags for performance drop / SHAP instability / prediction shift
6. **Model selection**
   - Chooses best model by validation PR-AUC, then test PR-AUC
7. **Persist artifacts**
   - metrics, drift reports, SHAP outputs, scored datasets, best model object

---

## Configuration Used in Notebook

Core parameters (defined in notebook configuration cell):

- `DATA_PATH = "data/renewals_dummy_data_2.csv"`
- `TARGET_COL = "RENEWED"`
- `OPERATING_THRESHOLD = 0.80` (used to convert probabilities to class labels)
- `HISTORY_YEARS = 3`
- `VALIDATION_MONTHS = 2`
- `RANDOM_STATE = 42`
- Drift controls:
  - `N_TOP_SHAP_FOR_DRIFT = 15`
  - `PSI_ALERT_THRESHOLD = 0.20`
  - `PERF_DROP_ALERT = 0.05`
  - `PREDICTION_SHIFT_ALERT = 0.10`

---

## Method-by-Method Explanation

### 1) Data split and feature prep helpers

- `split_train_validation_gap_test(df)`
  - converts `EXPIRED_END_DATE` to datetime
  - defines run date as the 1st day of current month
  - builds mutually exclusive train / validation / gap / test splits
  - validates splits are non-empty and prints split metadata

- `_build_qty_percentile_reference(train_frame)`
  - builds per-`PRODUCT_TYPE` sorted references for `TOTAL_SBSCRPTN_QTY`
  - used to compute quantity percentile features consistently

- `_lookup_percentile(product_type, value, ref)`
  - returns percentile position of quantity value within product-type reference
  - defaults to `0.5` if reference is missing

- `make_features(frame, qty_ref=None)`
  - drops leakage/redundant/ID/date columns and target column
  - creates engineered features:
    - `LOG_TOTAL_QTY`
    - `QTY_PERCENTILE`
    - `NEGATIVE_GROWTH_FLAG`
    - `HIGH_VOLATILITY_FLAG`
    - `ACV_X_RECENT_DOWNLOAD`
    - `UTIL_X_DAYS_TO_EXPIRY`
    - expiry bucket flags (`EXPIRY_30D_FLAG`, `EXPIRY_31_90D_FLAG`, `EXPIRY_GT_90D_FLAG`)
  - returns transformed frame + quantity reference dictionary

- `X_y_split_and_feature_engineering(train_df, validation_df, gap_df, test_df, target_col)`
  - applies `make_features` to each split
  - ensures non-train splits reuse training `qty_ref`
  - returns all `X_*`, `y_*`, and `qty_ref` in one dictionary

- `_prep_tree_frames(X_tr, X_te, X_va, X_gap)`
  - tree-model prep:
    - fills numeric missing values using train medians
    - fills categorical missing with `"<NA>"`
  - returns cleaned train/test/validation/gap matrices + categorical column list

### 2) Evaluation and drift helpers

- `evaluate(y_true, p_renew, threshold)`
  - computes threshold-dependent predictions
  - calculates precision, recall, F1, PR-AUC, confusion matrix
  - computes business lift (`lift_top_decile_risk`) by comparing non-renew rate in bottom-decile renewal probability contracts vs overall non-renew rate

- `select_best_model(lr_pipe, lgbm, cat, metrics_lr, metrics_lgb, metrics_cat)`
  - ranks models by:
    1. validation PR-AUC (higher is better)
    2. test PR-AUC (higher is better)
  - returns selected model object + metric summary

- `psi(expected, actual, bins=10)`
  - computes Population Stability Index between reference and current distributions

- `compute_feature_psi(train_x, test_x, features, bins=10)`
  - computes PSI per feature for selected feature list
  - supports both numeric and categorical inputs

---

## Evaluation Metrics Explained

The notebook’s model quality file (`metrics.json`) stores the following per split (`train`, `validation`, `test`):

- `pr_auc`: area under precision-recall curve; main ranking metric in this workflow
- `precision_at_0.80`: precision when renewal probability cutoff is `0.80`
- `recall_at_0.80`: recall at the same cutoff
- `f1_at_0.80`: harmonic mean of precision and recall at cutoff
- `tn`, `fp`, `fn`, `tp`: confusion matrix counts
- `lift_top_decile_risk`: non-renew concentration in the highest-risk decile (based on lowest renewal probabilities)

### Detailed definition of `lift_top_decile_risk`

`lift_top_decile_risk` measures how effectively the model ranks risky contracts (likely non-renewals) at the top of a priority queue.

In this notebook, the metric is computed as follows:

1. Sort records by predicted renewal probability (`p_renew`) in ascending order.
2. Take the bottom 10% by `p_renew` (lowest renewal probability = highest non-renewal risk).
3. Compute:
   - `nonrenew_rate_bottom`: non-renewal rate in that bottom-decile slice
   - `nonrenew_rate_overall`: non-renewal rate across all evaluated records
4. Compute lift ratio:
   - `lift_top_decile_risk = nonrenew_rate_bottom / nonrenew_rate_overall`

Interpretation:

- `1.0`: no concentration benefit vs random targeting.
- `> 1.0`: model successfully concentrates non-renewals into the highest-risk slice.
- `< 1.0`: ranking quality is weak or inverted for that slice.

Example:

- `lift_top_decile_risk = 2.4` means the prioritized 10% riskiest contracts have 2.4x the non-renewal rate of the overall population.

Why this matters:

- It directly quantifies how useful the model is for limited-capacity interventions (for example, when teams can only action a small fraction of accounts).

Practical caveats:

- Decile metrics can be noisy on small datasets.
- Always read alongside PR-AUC and threshold metrics (`precision_at_0.80`, `recall_at_0.80`, `f1_at_0.80`).

Why this metric mix:

- PR-AUC is better suited for imbalanced classification than plain accuracy.
- Threshold metrics reflect deploy-time decision behavior.
- Lift helps measure prioritization quality for retention actions.

---

## Files Saved by the Notebook

Each run creates a timestamp folder in both:

- `runs/sns_sl/<timestamp>/`
- `runs/saas_products/<timestamp>/`

### Artifact definitions (what each saved file does)

For each model folder (`logistic_regression`, `lightgbm`, `catboost`):

- `metrics.json`
  - performance snapshot for `train`, `validation`, and `test`
  - includes PR-AUC, threshold metrics, confusion counts, and lift
  - used for model comparison and monitoring

- `shap_importance.csv`
  - SHAP-based feature importance table
  - lists feature names and mean absolute SHAP contribution
  - used for explainability and top-driver analysis

- `top_shap_features.json`
  - selected top SHAP features for monitoring
  - used as the feature set for PSI/stability drift checks

- `drift_report.json`
  - drift and health diagnostics for the run
  - includes PSI alerts, performance-drop alert, SHAP instability alert, and prediction-shift alert
  - used for model-risk monitoring between runs

- `final_scored_dataset.csv`
  - original records joined with model outputs
  - contains `P_RENEW` and `PREDICTED_CLASS`
  - used for downstream review and operational actioning

For each segment’s `best_model/` folder:

- `best_model_summary.json`
  - summary of selected best model and its key metrics
  - used by reporting/automation flows

- `best_model_object.joblib`
  - serialized selected model object
  - used for reuse and production-style inference

At segment root (`runs/sns_sl/` and `runs/saas_products/`), the notebook also stores rolling baselines:

- `latest_metrics_snapshot_<model>.json`
  - latest PR-AUC baseline used to detect performance drop

- `latest_top_shap_features_<model>.json`
  - latest top SHAP list used for SHAP stability checks

- `latest_avg_prediction_<model>.json`
  - latest average test prediction used for prediction-shift checks

Inside each timestamp folder:

- `logistic_regression/`
  - `metrics.json`
  - `shap_importance.csv`
  - `top_shap_features.json`
  - `drift_report.json`
  - `final_scored_dataset.csv`
- `lightgbm/`
  - `metrics.json`
  - `shap_importance.csv`
  - `top_shap_features.json`
  - `drift_report.json`
  - `final_scored_dataset.csv`
- `catboost/`
  - `metrics.json`
  - `shap_importance.csv`
  - `top_shap_features.json`
  - `drift_report.json`
  - `final_scored_dataset.csv`
- `best_model/`
  - `best_model_summary.json`
  - `best_model_object.joblib`

Also written one level above each timestamp (used as baseline snapshots for next run):

- `runs/sns_sl/latest_metrics_snapshot_<model>.json`
- `runs/sns_sl/latest_top_shap_features_<model>.json`
- `runs/sns_sl/latest_avg_prediction_<model>.json`
- `runs/saas_products/latest_metrics_snapshot_<model>.json`
- `runs/saas_products/latest_top_shap_features_<model>.json`
- `runs/saas_products/latest_avg_prediction_<model>.json`

---

## How to Run the Code

### 1) Create and activate virtual environment

```bash
python -m venv .venv
source .venv/bin/activate
```

### 2) Install dependencies

```bash
pip install -U pip
pip install -r requirements.txt
```

### 3) Run notebook

Open `renewal-intelligence.ipynb` and run cells from top to bottom (`Run All`).

### 4) Verify outputs

After completion, verify new timestamp folders under:

- `runs/sns_sl/`
- `runs/saas_products/`

and confirm each contains model subfolders + `best_model/`.

---


