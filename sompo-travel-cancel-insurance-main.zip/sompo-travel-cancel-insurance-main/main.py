import gradio as gr
import requests, os, base64, easyocr, pillow_heif, cv2, pytesseract, re
import numpy as np
from PIL import Image, ImageDraw, UnidentifiedImageError
from dotenv import load_dotenv
load_dotenv()
reader = easyocr.Reader(['ja','en'])  # Load the OCR model
from collections import defaultdict

# AccessToken取得
def get_bearer_token(apikey):
    token_url = 'https://iam.cloud.ibm.com/identity/token'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
    }
    data = {
        "apikey":apikey,
        "grant_type": "urn:ibm:params:oauth:grant-type:apikey"
    }

    # トークンを取得
    response = requests.post(token_url, headers=headers, data=data)
    token = response.json()['access_token']
    return token

bearer_token = get_bearer_token(apikey=os.getenv('WATSONX_API_KEY'))

def convert_to_png(image_path):
    """ Converts any image to PNG format. """
    png_path = "uploaded_image.png"
    try:
        if image_path.lower().endswith(".heic"):
            heif_file = pillow_heif.open_heif(image_path)
            image = Image.frombytes(heif_file.mode, heif_file.size, heif_file.data)
        else:
            image = Image.open(image_path)
        image.save(png_path, format="PNG")
        return png_path
    except UnidentifiedImageError:
        raise ValueError("Unsupported image format. Please upload a valid image file.")


def preprocess_image():
    """ Corrects image orientation and skewness. """
    output_path = "processed_image.png"
    img = Image.open('uploaded_image.png')
    original_size = img.size  # Store the original size

    try:
        osd = pytesseract.image_to_osd(img)
        angle = int(re.search(r"Rotate:\s*(\d+)", osd).group(1) or 0)
        if angle in [90, 180,270]:
            img = img.rotate(360 - angle, expand=True)
    except:
        pass

    img.save(output_path)

    image = cv2.imread(output_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)

    if lines is not None:
        angles = [np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi for line in lines for x1, y1, x2, y2 in line]
        if angles:
            median_angle = np.median(angles)
            h, w = image.shape[:2]
            M = cv2.getRotationMatrix2D((w // 2, h // 2), median_angle, 1.0)
            # Calculate the new dimensions to avoid cropping
            cos = np.abs(M[0, 0])
            sin = np.abs(M[0, 1])
            new_w = int(h * sin + w * cos)
            new_h = int(h * cos + w * sin)
            M[0, 2] += (new_w / 2) - w // 2
            M[1, 2] += (new_h / 2) - h // 2
            image = cv2.warpAffine(image, M, (new_w, new_h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
            # Resize the image back to the original dimensions
            image = cv2.resize(image, original_size)

            cv2.imwrite(output_path, image)


def augment_api_request_body(user_query, image):
    system_prompt = f"""
あなたは高度なOCR（光学文字認識）および画像解析の専門家であり、病院の領収書や請求書から重要な情報を正確に抽出することに特化しています。

### **解析指示:**

1. **以下の重要情報を正確に抽出してください:**
   - **病院名**（請求書を発行した医療機関の名称）
   - **患者名**（請求書に記載された患者の氏名）
   - **請求日**（請求書の発行日）

2. **注意点:**
   - **名前（名前）:** 日本文化では名前は「姓 + 名」の順に記載されることが多いため、抽出後は「名 + 姓」の順に並べ替えてください。  
     例: 「姓: Mani」「名: Vikas」の場合 → 出力は「Vikas Mani」
   - **日付（日付）:** 日付の抽出においては、「発行日」と記載された日付を優先してください。**生年月日**など他の種類の日付と混同しないようにしてください。

3. **出力フォーマット:**

病院名: （抽出した病院名）
患者名: （抽出した患者名）
請求日: （抽出された請求日）
もし情報が不足している場合は、以下のように出力してください:

情報が不足しています。
上記のフォーマットのみを出力し、追加の説明やコメントは含めないでください。 出力は日本語のままにしてください。
"""
    body = {
        "messages": [{"role":"system","content":system_prompt}, {"role":"user","content":[{"type":"text","text":user_query},{"type":"image_url","image_url":{"url": f"data:image/jpeg;base64,{image}"}}]}],
        "project_id": os.getenv("WATSONX_PROJECT_ID"),
        "model_id": os.getenv("MODEL_ID"),
        "decoding_method": "greedy",
        "temperature": 0,
        "repetition_penalty": 1,
        "max_tokens": 1000,
    }
    return body

def read_image(image):
    user_query = """<|begin_of_text|><|start_header_id|>system<|end_header_id|> 
あなたは高度なOCR（光学文字認識）および画像解析の専門家であり、病院の領収書や請求書から重要な情報を正確に抽出することに特化しています。

### **解析指示:**

1. **以下の重要情報を正確に抽出してください:**
   - **病院名**（請求書を発行した医療機関の名称）
   - **患者名**（請求書に記載された患者の氏名）
   - **請求日**（請求書の発行日）

2. **注意点:**
   - **名前（名前）:** 日本文化では名前は「姓 + 名」の順に記載されることが多いため、抽出後は「名 + 姓」の順に並べ替えてください。  
     例: 「姓: Mani」「名: Vikas」の場合 → 出力は「Vikas Mani」
   - **日付（日付）:** 日付の抽出においては、「発行日」と記載された日付を優先してください。**生年月日**など他の種類の日付と混同しないようにしてください。

3. **出力フォーマット:**

病院名: （抽出した病院名）
患者名: （抽出した患者名）
請求日: （抽出された請求日）
もし情報が不足している場合は、以下のように出力してください:

情報が不足しています。
上記のフォーマットのみを出力し、追加の説明やコメントは含めないでください。 出力は日本語のままにしてください。
<|eot_id|><|start_header_id|>assistant<|end_header_id|>
"""

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }
    request_body = augment_api_request_body(user_query, image)
    response = requests.post(
        "https://us-south.ml.cloud.ibm.com/ml/v1/text/chat?version=2023-05-29",
        headers=headers,
        json=request_body
        )
    if response.status_code != 200:
        raise Exception("Non-200 response: " + str(response.text))
    # data = response.json()

    try:
        data = response.json()
        return data["choices"][0]["message"]["content"]
    except (KeyError, ValueError):
        return "Error parsing response: Ensure the API is returning the expected JSON structure."

def process_and_display(image_path):
    """Handles image processing and returns images with extracted text and response."""
    
    # Convert to PNG & display immediately
    convert_to_png(image_path)
    yield Image.open('uploaded_image.png'), None, "Processing..."  # Show uploaded image, keep others empty
    
    # Process the image & display immediately
    preprocess_image()

    yield Image.open('uploaded_image.png'), Image.open("processed_image.png"), "Processing..."  # Show processed image, keep text empty

    # Extract the necessary details
    with open('processed_image.png', "rb") as image_file:
        image = image_file.read()
    image = base64.b64encode(image).decode("utf-8")
    image_info = read_image(image)

    # Clean up
    os.remove(image_path)  # Clean up original image

    yield Image.open('uploaded_image.png'), Image.open("processed_image.png"), image_info  # Show all results

    os.remove('uploaded_image.png') # Clean up convert image
    os.remove('processed_image.png') # Clean up processed image


def main():
    with gr.Blocks(theme='shivi/calm_seafoam') as demo:
        gr.HTML("<h1 style='text-align: left; color: #000080;'>テキスト抽出AIアシスタント</h1>")
        
        with gr.Tab("🔍 画像から検索"):
            with gr.Row():
                upload_image = gr.File(label="Upload Image")
            
            with gr.Row():
                original_img = gr.Image(label="Uploaded Image")
                processed_img = gr.Image(label="Processed Image")
                extracted_text = gr.Textbox(label="📖 AIが画像から読み取った情報", placeholder="")
                
            upload_image.upload(process_and_display, inputs=upload_image, outputs=[original_img, processed_img, extracted_text])
    demo.launch(auth=["admin","test"])


if __name__ == "__main__":
    main()
    