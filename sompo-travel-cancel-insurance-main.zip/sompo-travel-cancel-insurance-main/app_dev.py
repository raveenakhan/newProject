import requests
import base64
import time
import os
from dotenv import load_dotenv
from PIL import Image
import gradio as gr
import json
import re
from PIL import Image, ImageDraw, ImageFont
import cv2
import easyocr
import numpy as np

import re

load_dotenv()
cloud_url = os.getenv("cloud_url")

current_credentials = {
    "apikey": os.getenv("API_KEY"),
    "project_id": os.getenv("PROJECT_ID"),
    "url": os.getenv("URL")
}

# AccessToken取得
def get_bearer_token(apikey):
    global current_credentials
    token_url = cloud_url
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
    }
    data = {
        "apikey":apikey,
        "grant_type": "urn:ibm:params:oauth:grant-type:apikey"
    }

    # トークンを取得
    response = requests.post(token_url, headers=headers, data=data)
    token = response.json()['access_token']
    return token

# トークンとその有効期限を保存する変数
bearer_token = get_bearer_token(current_credentials["apikey"])
token_expiry_time = time.time() + 3600  # トークンの有効期限は1時間


def augment_api_request_body(user_query, image):

    system_prompt = """
あなたは、医療保険請求のために病院領収書や明細書から必要な情報を抽出する専門AIです。

【目的】
以下の項目のみを、正確かつ網羅的に抽出してください：

- 顧客氏名（漢字）
- 顧客氏名（カタカナ）
- 診療日（必ず正確に読み取り、和暦の場合は西暦に変換してください。形式は「YYYY/MM/DD」としてください）
- 治療概要（一言または簡潔なフレーズで要約してください。例：風邪、検査、骨折、通院など）
- 請求金額（総額）
- 医療機関名
- 医療機関の種別（病院 または クリニック のいずれか）
- 医療機関の住所（可能な限り詳細に）

【前提】
- 入力にはOCRで抽出された日本語テキストと、病院発行の領収書や診療明細書画像の内容が含まれます。
- 書類の書式は統一されていないため、表現の揺れを吸収して意味を正しく理解し、該当情報を抽出してください。
- 和暦（例：令和7年5月26日）は必ず西暦（2025/05/26）に正しく変換してください。西暦表記（2025年など）はそのままで構いません。

【出力形式】
- 以下のように、各項目を「項目名: 値」の形式で1行ずつ出力してください。
- 項目の順序は以下に準拠してください。
- 情報が見つからない場合は「不明」と記載してください。
- 句読点や記号、JSON、マークダウン、改行装飾などは使用しないでください。

【出力テンプレート】
顧客氏名（漢字）:  
顧客氏名（カタカナ）:  
診療日:  
治療概要:  
請求金額:  
医療機関名:  
医療機関の種別:  
医療機関の住所:  

【厳守ルール】
- 指定された8項目**以外**は絶対に出力しないでください。
- 情報の補完や推測は可能ですが、不確実な場合は必ず「不明」としてください。
- 曖昧な表現（例：「おそらく」「と思われる」など）は一切使用しないこと。
- 出力の安定性を重視し、常に同じ形式で出力してください。
"""
    body = {
        "messages": [{"role":"system","content":system_prompt}, {"role":"user","content":[{"type":"text","text":user_query},{"type":"image_url","image_url":{"url": f"data:image/jpeg;base64,{image}"}}]}],
        "project_id": current_credentials["project_id"],
        "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
        "decoding_method": "greedy",
        # "repetition_penalty": 1,
        "temperature": 0,
        "seed": 42,
        "max_tokens": 1000,
    }
    return body

# def read_image(image, query):
def read_image(image):
    global bearer_token, token_expiry_time
    # トークンとその有効期限を保存する変数
    bearer_token = get_bearer_token(current_credentials["apikey"])
    token_expiry_time = time.time() + 3600  # トークンの有効期限は1時間
    user_query = """この画像から指定された情報を抽出してください。"""
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }
    request_body = augment_api_request_body(user_query, image)
    response = requests.post(
        "https://us-south.ml.cloud.ibm.com/ml/v1/text/chat?version=2023-05-29",
        headers=headers,
        json=request_body
        )
    if response.status_code != 200:
        raise Exception("Non-200 response: " + str(response.text))
    
    # data = response.json()
    # return data['choices'][0]['message']['content']
    
    try:
        data = response.json()
        return data["choices"][0]["message"]["content"]
    except (KeyError, ValueError):
        return "Error parsing response: Ensure the API is returning the expected JSON structure."


def rule_check(evidence):
    global bearer_token, token_expiry_time

    bearer_token = get_bearer_token(current_credentials["apikey"])
    token_expiry_time = time.time() + 3600  # トークンの有効期限は1時間
    system_prompt = system_prompt = '''
You are a professional assistant for an insurance company.

Your job is to determine whether the customer's situation qualifies for compensation under the Travel Cancellation Insurance plan.

You are provided with:
1. 【顧客の状況】– Real-world situation (identity, treatment type, date, etc.)
2. 【補償対象となるキャンセル事由】– Official list of valid compensation reasons
3. 【用語説明】– Definitions of domain-specific terms

Your task must follow **two strict steps** and produce output in **Japanese**, using the format defined below.

---

■ Step 1：最も該当しそうなキャンセル事由を特定する

- Read 【顧客の状況】 and compare with the list of valid reasons.
- Check:
  - Who received treatment?
  - Type of treatment: 通院 (outpatient) or 入院 (hospitalization)?
  - Their relationship to the 被保険者 (insured) or 同行者 (travel companion)?
  - Whether the treatment date fits the allowed window (◯日以内 from 旅行開始日)?

- From the official list (①〜⑯), pick the **most likely** matching reason and explain why.
- If none of the rules apply, say so clearly.

---

■ Step 2：選んだキャンセル事由が厳密に成立するか確認する

- Verify that the customer meets *all* required conditions of the chosen reason:
  - Treatment type matches?
  - Subject matches (本人, 同行者, 親族)?
  - Dates fall within rule-defined window?

- If a rule says "旅行開始日を含めて◯日以内", include the start date in your comparison (e.g. 7日以内 = from 旅行開始日 back to 6 days before).
- Raise any uncertainties or edge cases in the 補足 section.

---

【出力形式（日本語）】

【判定結果】  
理由：  
（満たした条件の説明／根拠／他に検討すべき番号があるか等）

結論：  
例1：補償対象となるキャンセル事由（番号）に該当する可能性が最も高い  
例2：すべての補償対象となるキャンセル事由に該当しない  

補足（不明点・懸念点）：  
（証拠の不一致／曖昧さ／判断困難な要素など）

---

【出力ルール】

- 必ず Step 1 → Step 2 の構成を守る  
- 条件を満たさない補償事由は絶対に含めない  
- 曖昧な推測は禁止。明確な根拠に基づいて判断する  
- 論理・構造・書き方は常に一貫させること  
- 出力は毎回ぶれず、**常に同じ構成と論理**で回答すること

---

【用語説明】

親族：６親等内の血族、配偶者または３親等内の姻族をいいます。  
通院：医師による治療が必要な場合において、病院または診療所に通い、または往診により、医師の治療を受けることをいいます。  
同行者：被保険者に同行して旅行等サービスの提供を受ける者で、契約内容確認証記載の者をいいます。同行者=旅行参加者本人  
入院：医師による治療が必要な場合において、自宅等での治療が困難なため、病院または診療所に入り、常に医師の管理下において治療に専念することをいいます。

---

【補償対象となるキャンセル事由】

① 被保険者または同行者が死亡した場合  
② 被保険者または同行者の配偶者または親族が旅行開始日を含め遡って31日以内に死亡した場合  
③ 被保険者または同行者が旅行開始日を含め遡って7日以内に入院する、または旅行開始日の前日までに旅行日程内に入院することが決まった場合  
④ 被保険者または同行者が旅行開始日を含め遡って4日以内に通院した場合。ただし、旅行開始日に被った傷害により旅行開始日の翌日に通院した場合は旅行開始日に通院したものとみなします  
⑤ 被保険者または同行者の配偶者または親族が旅行開始日を含め遡って7日以内に入院し、または旅行開始日の前日までに旅行日程内に入院することが決まり、被保険者または同行者が看護または介護を行う場合  
⑥ 被保険者または同行者の配偶者または親族が旅行開始日を含め遡って4日以内に通院し、被保険者または同行者が看護または介護を行った場合。ただし、旅行開始日に被った傷害により旅行開始日の翌日に通院した場合は旅行開始日に通院したものとみなします  
⑦ 被保険者または同行者が旅行開始日を含め遡って7日以内にインフルエンザ感染症または新型コロナウイルス感染症もしくは当社の指定する感染性胃腸炎を発病した場合  
⑧ 被保険者または同行者が常時居住している家屋が旅行開始日を含め遡って31日以内に、火災、落雷、破裂もしくは爆発、風災、雹災または雪災、水災、地震、噴火またはこれらによる津波により損害を受けた場合。ただし、家屋の機能の喪失または低下を伴わない損害を除きます  
⑨ 被保険者または同行者が、乗客として搭乗しているまたは搭乗予定の交通機関のうち、運行時刻が定められているものに運休、欠航または2時間以上の遅延が発生した場合  
⑩ 被保険者または同行者が、裁判員の参加する刑事裁判に関する法律に定める裁判員または補充裁判員に選任され裁判所へ出廷する場合  
⑪ 被保険者または同行者が、旅行開始日またはその前日に交通事故を起こした場合  
⑫ 被保険者または同行者が、旅行開始日またはその前日に第三者の葬儀に参列した場合  
⑬ 被保険者または同行者が、旅行開始日を含め遡って７日以内に、道路交通法に定める免許の取消し、停止等の処分を受けた場合  
⑭ 被保険者または同行者に、妊娠の事実が判明した場合。ただし、旅行契約等申込時に妊娠の事実が判明していた場合を除きます  
⑮ 被保険者または同行者が飼っている犬または猫が旅行開始日を含め遡って７日以内に死亡した場合  
⑯ 被保険者または同行者が、旅行日程内に参加することを予定していたイベントが中止または延期となった場合  
'''

    user_prompt = f"""
【顧客の状況】  
{evidence}
"""
    request_body = {
        "messages": [{"role":"system","content":system_prompt}, {"role":"user","content":[{"type":"text","text":user_prompt}]}],
        "project_id": current_credentials["project_id"],
        # "model_id": "meta-llama/llama-3-3-70b-instruct",
        "model_id": "meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
        "decoding_method": "greedy",
        # "repetition_penalty": 1,
        "temperature": 0,
        "seed": 42,
        "max_tokens": 1000
    }
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }
    response = requests.post(
        "https://us-south.ml.cloud.ibm.com/ml/v1/text/chat?version=2023-05-29",
        headers=headers,
        json=request_body
        )
    if response.status_code != 200:
        raise Exception("Non-200 response: " + str(response.text))
    data = response.json()

    return data['choices'][0]['message']['content']

def get_treatment_day_diffs(receipt_info: str, contract_info: str):
    # 1. 旅行開始日を抽出
    trip_start_match = re.search(r'旅行開始日：(\d{4}/\d{1,2}/\d{1,2})', contract_info)
    if not trip_start_match:
        return ""
    trip_start_str = trip_start_match.group(1)
    trip_start_date = datetime.strptime(trip_start_str, '%Y/%m/%d')

    # 2. 治療日（単一 or 範囲）を抽出
    treatment_date_strs = re.findall(r'治療日:\s*(\d{4}/\d{1,2}/\d{1,2}(?:-\d{4}/\d{1,2}/\d{1,2})?)', receipt_info)

    diffs = []
    for date_str in treatment_date_strs:
        if '-' in date_str:
            start_str, end_str = date_str.split('-')
            start_date = datetime.strptime(start_str, '%Y/%m/%d')
            end_date = datetime.strptime(end_str, '%Y/%m/%d')
            diff_start = (trip_start_date - end_date).days+1
            diff_end = (trip_start_date - start_date).days+1
            result_diff = f"{format_diff(diff_start)}〜{format_diff(diff_end)}"
        else:
            single_date = datetime.strptime(date_str, '%Y/%m/%d')
            diff = (trip_start_date - single_date).days+1
            result_diff = format_diff(diff)

        formatted_date = format_date_range(date_str)
        diffs.append({
            "治療日": formatted_date,
            "旅行開始日": trip_start_date.strftime('%Y/%m/%d'),
            "差分日数": result_diff
        })

    return diffs

def format_diff(diff: int) -> str:
    if diff == 0:
        return "当日"
    elif diff > 0:
        return f"{diff}日前"
    else:
        return f"{abs(diff)}日後"

def format_date_range(date_str: str) -> str:
    if '-' not in date_str:
        return datetime.strptime(date_str, '%Y/%m/%d').strftime('%Y/%m/%d')
    start_str, end_str = date_str.split('-')
    start_fmt = datetime.strptime(start_str, '%Y/%m/%d').strftime('%Y/%m/%d')
    end_fmt = datetime.strptime(end_str, '%Y/%m/%d').strftime('%Y/%m/%d')
    return f"{start_fmt}-{end_fmt}"

def LLM(receipt_info, contract_info, report_info):

    treatment_day_diffs = get_treatment_day_diffs(receipt_info, contract_info)
    diff = treatment_day_diffs[0]["差分日数"] if treatment_day_diffs else "不明"
    treatment_date = treatment_day_diffs[0]["治療日"] if treatment_day_diffs else "不明"
    trip_start = treatment_day_diffs[0]["旅行開始日"] if treatment_day_diffs else "不明"
    
    global bearer_token, token_expiry_time

    bearer_token = get_bearer_token(current_credentials["apikey"])
    token_expiry_time = time.time() + 3600  # トークンの有効期限は1時間
    system_prompt = f"""
You are a professional assistant for a Japanese insurance company specializing in Travel Cancellation Insurance verification.

Your job is to **verify customer-submitted hospital receipts** against:
1. The customer’s insurance contract (契約情報),
2. The reported reason for trip cancellation (キャンセル情報).

These receipts relate to cancellations due to medical treatment of the insured person, their companions, or close relatives.

---

【CHECKPOINT 1】Receipt vs Contract (契約情報とのクロスチェック)

1.1 >>> 本人確認 (Identity Verification)
- Identify whether the person named in the hospital receipt is:
  A. 契約者 (insured person),
  B. 同行者 (accompanying traveler),
  C. 同行者ではないが親族の可能性が高い,
  D. 同行者ではないが親族の可能性が低い.
- Consider all name variants (Kanji, Katakana, Hiragana, Romaji).
- Prefer Katakana-based comparison first. If it matches, assume identity confirmed.
- Be strict. Raise doubt clearly if identity is ambiguous.

1.2 >>> 日付確認 (Date Validation)
- Extract treatment date from receipt.
- Do NOT output anything here. This will be used in Checkpoint 2.

1.3 >>> 治療内容 (Treatment Verification)
- Classify the treatment: 入院 or 通院.
- Identify who received it: insured person / companion / family.
- 通院 = treated but not hospitalized.
- Clearly indicate if the treatment type aligns with the cancel reason.

---

【CHECKPOINT 2】Receipt vs Cancel Info (キャンセル情報とのクロスチェック)

2.1 >>> 情報整合性チェック (Information Consistency Check)
Compare receipt and cancel report for:
- 本人確認: Are both referring to the same person?
- 治療内容: Is treatment type consistent with cancel reason?
- 日付確認: Does treatment date match or partially overlap with 入通院開始日?

Use this rule for conclusion:
- If all 3 align → 結論: 一致している
- If any one is unclear or mismatched → 結論: 一致していない可能性あり
- If clearly inconsistent → 結論: 一致していない

Raise flags if identity or dates are unclear. Be transparent and always explain **why**.

---

【OUTPUT FORMAT】(すべて日本語で出力)

1. [提出エビデンスチェック]  
>>>本人確認<<<  
結論：契約者｜同行者(旅行参加者本人)｜同行者ではないが、親族の可能性が高い（要確認）｜同行者ではないが、親族の可能性が低い（要確認）  
根拠：名前の一致度、記載内容、その他の根拠を簡潔に

>>>日付確認<<<  
結論：leave blank  
根拠：leave blank

>>>治療内容<<<  
治療種別（入院／通院）、誰が受けたか、キャンセル理由と一致しているかどうかの評価と根拠

2. [提出エビデンスとTravelキャンセル情報のクロスチェック]  
>>>Travelキャンセル情報との一致性<<<  
根拠：  
- 本人確認：照合の根拠と一致／不一致理由  
- 治療内容：照合の根拠と一致／不一致理由  
- 日付確認：照合の根拠と一致／不一致理由  

結論：一致している｜一致していない可能性あり｜一致していない
"""
    user_query = f"""
Receipt information(レシート):  
{receipt_info}

Contract information(契約情報):  
{contract_info}

Reported cancel information(Travelキャンセル情報):  
{report_info}
"""

    request_body = {
        "messages": [{"role":"system","content":system_prompt}, {"role":"user","content":[{"type":"text","text":user_query}]}],
        "project_id": current_credentials["project_id"],
        "model_id": "meta-llama/llama-3-3-70b-instruct",
        # "model_id": "meta-llama/llama-3-405b-instruct",
        # "model_id": "mistralai/mistral-large",
        "decoding_method": "greedy",
        "temperature": 0,
        "seed": 42,
        "max_tokens": 1000
    }
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }
    response = requests.post(
        "https://us-south.ml.cloud.ibm.com/ml/v1/text/chat?version=2023-05-29",
        headers=headers,
        json=request_body
        )
    if response.status_code != 200:
        raise Exception("Non-200 response: " + str(response.text))
    data = response.json()

    def replace_date_section(text: str, new_diff: str, new_treatment_date: str, new_trip_start: str):
        # >>>日付確認<<< から次の >>> または文末までを対象とする
        def replace_in_date_section(match):
            section = match.group(0)
            section = re.sub(
                r'結論：',
                f'結論：治療日は旅行開始日の{new_diff}に行われた。',
                section
            )
            section = re.sub(
                r'根拠：',
                f'根拠：治療日({new_treatment_date})は旅行開始日（{new_trip_start}）の{new_diff}に行われた。',
                section
            )
            return section

        # 1. 「>>>日付確認<<<」セクションに限定して置換を適用
        text = re.sub(
            r'>>>日付確認<<<.*?(?=>>>|$)',
            replace_in_date_section,
            text,
            flags=re.DOTALL
        )

        # 2. 全体の治療日・旅行開始日を置換（形式維持のため）
        text = re.sub(r'治療日（\d{4}/\d{2}/\d{2}）', f'治療日（{new_treatment_date}）', text)
        text = re.sub(r'旅行開始日（\d{4}/\d{2}/\d{2}）', f'旅行開始日（{new_trip_start}）', text)
        return text

    return replace_date_section(data['choices'][0]['message']['content'], diff, treatment_date, trip_start)

def receipt_check(selected_case):

    target_image = update_output(selected_case)[2] # Getting the fixed image.
    print(target_image)

    output = ""

    for i in range(len(target_image)):
        # read and convert the image
        with open(target_image[i], "rb") as image_file:  # "rb"はバイナリモードで読み込む
            image = image_file.read()
        image = base64.b64encode(image).decode("utf-8")

        image_info = read_image(image)
        image_info_add = ">>>>>>>>領収書_" + str(i+1) + "<<<<<<<<<\n" + image_info + "\n\n"
        output = output + image_info_add

    return output

def update_output(selected_case):

    if selected_case == "事案1":
        image_path = ["事案１_病院領収書.png"]
        image_path_f = ["事案１_rotated.png"]
        cont = """被保険者情報	
氏名（漢字）：損保　一郎
氏名（カナ）：ソンポ　イチロウ
旅行開始日：2025/5/23
旅行終了日：2025/5/24
旅行者情報	
申込者（セイ）：ソンポ
申込者（メイ）：イチロウ
同行者情報	
番号	1
同行者（セイ）：ソンポ
同行者（メイ）：イチロウ
番号	2
同行者（セイ）：ソンポ
同行者（メイ）：タロウ
"""
        incid = """Travelキャンセル情報
キャンセル日：2025/5/22
キャンセル事由：旅行参加者もしくは親族の通院・入院
旅行参加者もしくは親族の通院・入院
入院通院対象者：旅行参加者の配偶者または親族
入院の有無：無
入通院開始日：2025/5/22
"""
    elif selected_case == "事案2":
        image_path = ["事案２_病院領収書.jpg", "事案２_病院領収書②.jpg"]
        image_path_f = ["事案2_rotated1.png", "事案2_rotated2.png"]
        cont = """被保険者情報	
氏名（漢字）：新宿　花子
氏名（カナ）：シンジュク　ハナコ
旅行開始日：2025/5/29
旅行終了日：2025/5/30
旅行者情報	
申込者（セイ）：シンジュク
申込者（メイ）：ハナコ
同行者情報：なし
"""
        incid = """Travelキャンセル情報
キャンセル日：2025/5/28
キャンセル事由：旅行参加者もしくは親族の通院・入院
旅行参加者もしくは親族の通院・入院
入院通院対象者：旅行参加者本人
入院の有無：無
入通院開始日：2025/5/26
"""
    elif selected_case == "事案3":
        image_path = ["事案３_病院領収書.png"]
        image_path_f = ["事案3_rotated.png"]
        cont = """被保険者情報	
氏名（漢字）：米主　亜嵐
氏名（カナ）：マイシュ　アラン
旅行開始日：2025/5/30
旅行終了日：2025/5/31
旅行者情報	
申込者（セイ）：マイシュ
申込者（メイ）：アラン
同行者情報：なし
"""
        incid = """Travelキャンセル情報
キャンセル日：2025/5/29
キャンセル事由：旅行参加者もしくは親族の通院・入院
旅行参加者もしくは親族の通院・入院
入院通院対象者：旅行参加者の配偶者または親族
入院の有無：無
入通院開始日：2025/5/27
"""
    elif selected_case == "事案4":
        image_path = ["事案４_病院領収書.png"]
        image_path_f = ["事案4_rotated.png"]
        cont = """被保険者情報	
氏名（漢字）：少額　保男
氏名（カナ）：少額　ヤスオ
旅行開始日：2025/5/31
旅行終了日：2025/6/2
旅行者情報	
申込者（セイ）：ショウガク
申込者（メイ）：ヤスオ
同行者情報	
番号	1
同行者（セイ）：ショウガク
同行者（メイ）：タンコ
"""
        incid = """Travelキャンセル情報
キャンセル日：2025/5/23
キャンセル事由：旅行参加者もしくは親族の通院・入院
旅行参加者もしくは親族の通院・入院
入院通院対象者：旅行参加者本人
入院の有無：無
入通院開始日：2025/5/23
"""
    else:
        image_path = ["事案５_病院領収書.png"]
        image_path_f = ["事案5_rotated.png"]
        cont = """被保険者情報	
氏名（漢字）：日本橋　浜子
氏名（カナ）：ニホンバシ　ハマコ
旅行開始日：2025/5/4
旅行終了日：2025/5/5
旅行者情報	
申込者（セイ）：ニホンバシ
申込者（メイ）：ハマコ
同行者情報	
番号	1
同行者（セイ）：トウキョウ
同行者（メイ）：ハルコ
番号	2
同行者（セイ）：サクラダモン
同行者（メイ）：ユウコ
番号	3
同行者（セイ）：オチャノミズ
同行者（メイ）：サブロウ
"""
        incid = """Travelキャンセル情報
キャンセル日：2025/4/28
キャンセル事由：感染症
旅行参加者もしくは親族の通院・入院
感染症
感染症の種類：インフルエンザ
診断日：2025/4/28
"""
    return image_path, image_path, image_path_f, cont, incid


import base64
with open("logo.png", "rb") as f:
    data = base64.b64encode(f.read()).decode("utf-8")
html = f"""<img src="data:image/png;base64,{data}" width="1500" height="500">"""


with gr.Blocks(theme='shivi/calm_seafoam') as demo:
    gr.HTML(html)
    with gr.Tab("🤖 トラベルキャンセル保険AI査定"):
        gr.Markdown("#### A) 入院エビデンス提出")
        with gr.Row():
            with gr.Column(scale = 1):
                gr.Markdown("##### ★ 検証の事案番号を選択")
                target = gr.Dropdown(["事案1", "事案2", "事案3", "事案4", "事案5"], label="事案を選択してください", info="事案を選択したら関連帳票がアップロードされます")
                target_btn = gr.Button("確定", variant="primary")
            with gr.Column(scale = 5):
                gr.Markdown("##### ★ アップロード済み帳票")
                upload_image = gr.Gallery(label="帳票", preview=True, visible=True)
            with gr.Column(scale = 5):
                gr.Markdown("##### ★ 関連契約内容")
                contract = gr.Textbox(label="", value="")
                incident = gr.Textbox(label="", value="")

        gr.Markdown("---")
        gr.Markdown("#### B) AIによるエビデンス理解")
        with gr.Accordion("★ STEP1：画像の前処理 (この処理は裏で自動で行います)", open = False):
            with gr.Row():
                with gr.Column(scale = 1):
                    gr.Markdown("##### ★ STEP1：画像の前処理")
                with gr.Column(scale=5):
                    gr.Markdown("##### ★ 処理前")
                    fix_image = gr.Gallery(label="帳票", preview=True, visible=True)
                with gr.Column(scale=5):
                    gr.Markdown("##### ★ 処理後")
                    fixed_image = gr.Gallery(label="帳票", preview=True, visible=True)

        with gr.Accordion("★ STEP2：生成AIで帳票を理解、契約情報と照らし合わせてエビデンス確認", open=True):
            with gr.Row():
                with gr.Column(scale=1):
                    with gr.Row():
                        with gr.Column():
                            gr.Markdown("##### ★ STEP2-1：生成AIで帳票を理解")
                            extract = gr.Button("情報抽出開始", variant="primary")
                        with gr.Column():
                            gr.Markdown("##### ★ STEP2-2：エビデンス確認")
                            check_evidence = gr.Button("エビデンス確認", variant="primary")
                with gr.Column(scale=5):
                    gr.Markdown("##### ★ 領収書から情報読み取り")
                    info = gr.Textbox(label="", value="")
                with gr.Column(scale=5):
                    gr.Markdown("##### ★ エビデンス確認")
                    report = gr.Textbox(label="", value="")
        gr.Markdown("---")
        gr.Markdown("#### C) AIによる有無責判定")
        with gr.Accordion("★ STEP3：査定マニュアルに沿って有無責判定", open=True):
            rule_check_btn = gr.Button("有無責判定", variant="primary")
            rule_check_result = gr.Textbox(label="", value="""""")
            # add a collapsible section to show a png file
            with gr.Accordion("★ STEP3-1：有無責判定マニュアル", open=False):
                gr.Image(value="rule_check.png", label="有無責判定マニュアル", visible=True)
        target_btn.click(fn=update_output, inputs=target, outputs=[upload_image, fix_image, fixed_image, contract, incident])
        extract.click(fn=receipt_check, inputs=target, outputs=info)
        check_evidence.click(fn=LLM, inputs=[info, contract, incident], outputs=report)
        rule_check_btn.click(fn=rule_check, inputs=[report], outputs=rule_check_result)

demo.launch(allowed_paths=["."])