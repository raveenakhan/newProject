# SOMPO TRAVEL  - CANCEL INSURANCE
This project leverages vision-capable large language models to extract structured information from uploaded images across various formats and orientations. The system employs a robust preprocessing pipeline that:

Normalizes images regardless of original format (JPG, PNG, PDF scans, etc.)
Corrects orientation issues using rotation detection algorithms
Enhances image quality through contrast adjustment and noise reduction
Segments relevant regions containing target information

Once preprocessed, our vision LLM analyzes the images to accurately extract key data points, converting unstructured visual information into structured, machine-readable formats. The system has demonstrated high accuracy across diverse document types, even with challenging inputs like skewed photographs, low-resolution scans, and variable lighting conditions.

## Code Setup:
1. Create a virtual environment.
    `python -m venv <virtual env name>` or `pipenv shell`
2. Activate the virtual environment.
3. Install the required libraries.
    `pip install -r requirements.txt` or `pipenv install -r requirements.txt`
4. Create the env file. Enter the api key, prject id & model name
5. Run the code.
    `python main.py`